import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.50.0'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

interface WebhookPayload {
  type: 'tier' | 'logbox';
  [key: string]: any;
}

interface SkinResponse {
  id: string;
  name: string;
  properties: Array<{
    name: string;
    value: string;
  }>;
}

interface EnhancedLogPayload {
  type: string;
  template: string;
  rawMessage: string;
  formattedData: {
    title: string;
    color: number;
    description: string;
    timestamp: string;
    fields: Array<{
      name: string;
      value: string;
      inline: boolean;
    }>;
  };
}

Deno.serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  const supabase = createClient(
    Deno.env.get('SUPABASE_URL')!,
    Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
  )

  try {
    console.log('Enhanced webhook management function called:', req.method)

    if (req.method === 'POST') {
      const { action, data } = await req.json()
      
      switch (action) {
        case 'process_queue':
          return await processWebhookQueue(supabase)
        case 'test_webhook':
          return await testWebhook(supabase, data)
        case 'get_skin_url':
          return await getSkinUrl(data.username)
        case 'validate_webhook_url':
          return await validateWebhookUrl(data.url)
        default:
          return new Response(
            JSON.stringify({ error: 'Invalid action' }),
            { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
          )
      }
    }

    return new Response(
      JSON.stringify({ error: 'Method not allowed' }),
      { status: 405, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )

  } catch (error) {
    console.error('Enhanced webhook management error:', error)
    return new Response(
      JSON.stringify({ error: 'Internal server error', details: error.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  }
})

async function validateWebhookUrl(url: string): Promise<Response> {
  try {
    const patterns = [
      /^https:\/\/discord\.com\/api\/webhooks\/\d+\/[\w-]+\/?$/,
      /^https:\/\/discordapp\.com\/api\/webhooks\/\d+\/[\w-]+\/?$/,
    ];
    
    const isValid = patterns.some(pattern => pattern.test(url));
    
    if (!isValid) {
      return new Response(
        JSON.stringify({ valid: false, message: 'Invalid Discord webhook URL format' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Test the webhook URL by sending a HEAD request
    try {
      const testResponse = await fetch(url, { method: 'HEAD' });
      return new Response(
        JSON.stringify({ 
          valid: true, 
          accessible: testResponse.ok,
          status: testResponse.status,
          message: testResponse.ok ? 'Webhook URL is valid and accessible' : 'Webhook URL format is valid but may not be accessible'
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    } catch (fetchError) {
      return new Response(
        JSON.stringify({ 
          valid: true, 
          accessible: false,
          message: 'Webhook URL format is valid but accessibility test failed'
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }
  } catch (error) {
    return new Response(
      JSON.stringify({ valid: false, message: error.message }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
}

async function processWebhookQueue(supabase: any) {
  console.log('Processing enhanced webhook queue...')
  
  // Get pending webhooks with better error handling
  const { data: pendingWebhooks, error } = await supabase
    .from('mcbe_webhook_queue')
    .select('*')
    .eq('status', 'pending')
    .lt('retry_count', 3)
    .lte('scheduled_at', new Date().toISOString())
    .order('created_at', { ascending: true })
    .limit(50)

  if (error) {
    console.error('Error fetching pending webhooks:', error)
    return new Response(
      JSON.stringify({ error: 'Failed to fetch pending webhooks', details: error.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  }

  let processedCount = 0
  let successCount = 0
  const errors = []

  for (const webhook of pendingWebhooks) {
    try {
      // Update status to processing
      await supabase
        .from('mcbe_webhook_queue')
        .update({ status: 'processing' })
        .eq('id', webhook.id)

      const result = await sendEnhancedWebhook(supabase, webhook)
      
      if (result.success) {
        // Mark as sent
        await supabase
          .from('mcbe_webhook_queue')
          .update({ 
            status: 'sent', 
            processed_at: new Date().toISOString() 
          })
          .eq('id', webhook.id)
        successCount++
      } else {
        // Increment retry count and schedule next attempt
        const newRetryCount = webhook.retry_count + 1
        const nextSchedule = new Date(Date.now() + Math.pow(2, newRetryCount) * 15000)
        
        if (newRetryCount >= 3) {
          await supabase
            .from('mcbe_webhook_queue')
            .update({ 
              status: 'failed', 
              retry_count: newRetryCount,
              processed_at: new Date().toISOString(),
              error_message: result.error || 'Max retries exceeded'
            })
            .eq('id', webhook.id)
        } else {
          await supabase
            .from('mcbe_webhook_queue')
            .update({ 
              status: 'pending', 
              retry_count: newRetryCount,
              scheduled_at: nextSchedule.toISOString()
            })
            .eq('id', webhook.id)
        }
        
        errors.push({ id: webhook.id, error: result.error })
      }
      
      processedCount++
    } catch (error) {
      console.error(`Error processing enhanced webhook ${webhook.id}:`, error)
      
      // Mark as failed
      await supabase
        .from('mcbe_webhook_queue')
        .update({ 
          status: 'failed', 
          processed_at: new Date().toISOString(),
          error_message: error.message 
        })
        .eq('id', webhook.id)
      
      errors.push({ id: webhook.id, error: error.message })
    }
  }

  console.log(`Processed ${processedCount} enhanced webhooks, ${successCount} successful`)
  
  return new Response(
    JSON.stringify({ 
      processed: processedCount, 
      successful: successCount,
      errors: errors.length > 0 ? errors : undefined
    }),
    { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
  )
}

async function sendEnhancedWebhook(supabase: any, webhook: any): Promise<{ success: boolean; error?: string }> {
  const startTime = Date.now()
  
  try {
    // Get webhook configuration with better error handling
    const { data: config, error: configError } = await supabase
      .from('mcbe_webhook_configs')
      .select('webhook_url, is_active')
      .eq('webhook_type', webhook.webhook_type)
      .eq('is_active', true)
      .single()

    if (configError || !config) {
      console.log(`No active webhook config for type: ${webhook.webhook_type}`, configError)
      return { success: false, error: `No active webhook config: ${configError?.message || 'Config not found'}` }
    }

    if (!config.webhook_url) {
      return { success: false, error: 'Webhook URL is empty' }
    }

    // Validate webhook URL
    const urlPatterns = [
      /^https:\/\/discord\.com\/api\/webhooks\/\d+\/[\w-]+\/?$/,
      /^https:\/\/discordapp\.com\/api\/webhooks\/\d+\/[\w-]+\/?$/,
    ];
    
    const isValidUrl = urlPatterns.some(pattern => pattern.test(config.webhook_url));
    if (!isValidUrl) {
      return { success: false, error: 'Invalid Discord webhook URL format' }
    }

    const payload = webhook.payload
    let discordPayload: any

    if (webhook.webhook_type === 'tier') {
      // Enhanced tier webhook with skin and better formatting
      const skinUrl = await getCachedSkinUrl(supabase, payload.player?.java_username || payload.player?.ign)
      
      discordPayload = {
        embeds: [{
          title: `🏆 ${payload.action || 'Tier Update'}`,
          description: `**${payload.player?.ign || 'Unknown Player'}** has ${payload.action === 'Result Posted' ? 'earned' : 'updated to'} **${payload.tier || 'Unknown Tier'}** tier in **${payload.gamemode || 'Unknown Mode'}**!`,
          color: getTierColor(payload.tier),
          thumbnail: skinUrl ? { url: skinUrl } : undefined,
          fields: [
            {
              name: '👤 Player',
              value: `**${payload.player?.ign || 'Unknown'}**`,
              inline: true
            },
            {
              name: '🎮 Gamemode',
              value: `**${payload.gamemode || 'Unknown'}**`,
              inline: true
            },
            {
              name: '🏅 Tier Result',
              value: `**${payload.tier || 'Unknown'}**`,
              inline: true
            }
          ],
          footer: {
            text: `MCBE Tiers System • ${new Date(payload.timestamp || Date.now()).toLocaleString()}`,
            icon_url: skinUrl || undefined
          },
          timestamp: payload.timestamp || new Date().toISOString()
        }]
      }
    } else if (webhook.webhook_type === 'logbox') {
      // Enhanced logbox webhook
      try {
        const enhancedLog: EnhancedLogPayload = typeof payload.message === 'string' 
          ? JSON.parse(payload.message) 
          : payload.message
        
        if (enhancedLog.formattedData && enhancedLog.template) {
          // Use enhanced formatting
          discordPayload = {
            embeds: [{
              title: enhancedLog.formattedData.title,
              description: enhancedLog.formattedData.description,
              color: enhancedLog.formattedData.color,
              fields: enhancedLog.formattedData.fields || [],
              timestamp: enhancedLog.formattedData.timestamp,
              footer: {
                text: `MCBE Autonomous System • ${enhancedLog.template.toUpperCase()}`
              }
            }]
          }
        } else {
          // Fallback to simple message
          const message = typeof payload.message === 'string' ? payload.message : JSON.stringify(payload.message)
          discordPayload = {
            embeds: [{
              title: '📋 System Log',
              description: `\`\`\`\n${message.substring(0, 1900)}\n\`\`\``,
              color: 0x808080,
              timestamp: new Date().toISOString(),
              footer: { text: 'MCBE System Log' }
            }]
          }
        }
      } catch (parseError) {
        // If parsing fails, send as simple text
        const message = typeof payload.message === 'string' ? payload.message : JSON.stringify(payload.message)
        discordPayload = {
          embeds: [{
            title: '📋 System Log',
            description: `\`\`\`\n${message.substring(0, 1900)}\n\`\`\``,
            color: 0x808080,
            timestamp: new Date().toISOString(),
            footer: { text: 'MCBE System Log' }
          }]
        }
      }
    }

    // Send to Discord with timeout
    const controller = new AbortController()
    const timeoutId = setTimeout(() => controller.abort(), 10000) // 10 second timeout

    const response = await fetch(config.webhook_url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(discordPayload),
      signal: controller.signal
    })

    clearTimeout(timeoutId)

    const deliveryTime = Date.now() - startTime
    const success = response.ok

    // Log the webhook attempt
    await supabase
      .from('mcbe_webhook_logs')
      .insert({
        webhook_type: webhook.webhook_type,
        payload_preview: JSON.stringify(payload).substring(0, 500),
        success,
        http_status: response.status,
        response_message: success ? 'OK' : await response.text().catch(() => 'Unknown error'),
        delivery_time_ms: deliveryTime
      })

    console.log(`Enhanced webhook ${webhook.webhook_type} sent: ${success ? 'SUCCESS' : 'FAILED'} (${response.status}) in ${deliveryTime}ms`)
    
    if (!success) {
      return { success: false, error: `HTTP ${response.status}: ${await response.text().catch(() => 'Unknown error')}` }
    }

    return { success: true }

  } catch (error) {
    const deliveryTime = Date.now() - startTime
    console.error('Enhanced webhook send error:', error)
    
    // Log the error
    await supabase
      .from('mcbe_webhook_logs')
      .insert({
        webhook_type: webhook.webhook_type,
        payload_preview: JSON.stringify(webhook.payload).substring(0, 500),
        success: false,
        http_status: 0,
        response_message: error.message,
        delivery_time_ms: deliveryTime
      })

    return { success: false, error: error.message }
  }
}

async function getCachedSkinUrl(supabase: any, username: string): Promise<string | null> {
  if (!username) return null
  
  try {
    // Check cache first
    const { data: cached } = await supabase
      .from('mcbe_skin_cache')
      .select('skin_url')
      .eq('java_username', username)
      .gt('expires_at', new Date().toISOString())
      .single()

    if (cached) {
      return cached.skin_url
    }

    // Fetch from Mojang API
    const skinUrl = await getSkinUrl(username)
    
    if (skinUrl) {
      // Cache the result
      await supabase
        .from('mcbe_skin_cache')
        .upsert({
          java_username: username,
          skin_url: skinUrl,
          cached_at: new Date().toISOString(),
          expires_at: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString()
        })
    }

    return skinUrl
  } catch (error) {
    console.error('Error getting cached skin URL:', error)
    return null
  }
}

async function getSkinUrl(username: string): Promise<string | null> {
  try {
    // Get UUID from username
    const uuidResponse = await fetch(`https://api.mojang.com/users/profiles/minecraft/${username}`)
    if (!uuidResponse.ok) return null
    
    const uuidData = await uuidResponse.json()
    if (!uuidData.id) return null

    // Get skin data
    const profileResponse = await fetch(`https://sessionserver.mojang.com/session/minecraft/profile/${uuidData.id}`)
    if (!profileResponse.ok) return null
    
    const profileData: SkinResponse = await profileResponse.json()
    
    const texturesProperty = profileData.properties?.find(p => p.name === 'textures')
    if (!texturesProperty) return null

    const texturesData = JSON.parse(atob(texturesProperty.value))
    const skinUrl = texturesData.textures?.SKIN?.url

    return skinUrl || null
  } catch (error) {
    console.error('Error fetching skin URL:', error)
    return null
  }
}

async function testWebhook(supabase: any, data: { type: string; url: string }) {
  const testPayload = data.type === 'tier' 
    ? {
        embeds: [{
          title: '🏆 Test Webhook - Tier Update',
          description: '**TestPlayer** has earned **HT1** tier in **Crystal**!',
          color: 0x00ff00,
          fields: [
            { name: '👤 Player', value: '**TestPlayer**', inline: true },
            { name: '🎮 Gamemode', value: '**Crystal**', inline: true },
            { name: '🏅 Tier Result', value: '**HT1**', inline: true }
          ],
          footer: { text: 'MCBE Tiers System • Test Message' },
          timestamp: new Date().toISOString()
        }]
      }
    : {
        embeds: [{
          title: '📋 Test Enhanced Logbox Message',
          description: 'System monitoring update - webhook test successful',
          color: 0x0099ff,
          fields: [
            {
              name: '📋 Test Status',
              value: '```\nTest log message from MCBE Tiers enhanced webhook system.\nAll systems operational.\n```',
              inline: false
            },
            {
              name: '⏰ Timestamp',
              value: new Date().toLocaleString(),
              inline: true
            },
            {
              name: '📊 Type',
              value: 'LOGBOX TEST',
              inline: true
            }
          ],
          footer: { text: 'MCBE Enhanced Webhook System • TEST' },
          timestamp: new Date().toISOString()
        }]
      }

  try {
    const response = await fetch(data.url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(testPayload)
    })

    const responseText = response.ok ? 'OK' : await response.text()

    return new Response(
      JSON.stringify({ 
        success: response.ok, 
        status: response.status,
        message: response.ok ? 'Enhanced test webhook sent successfully' : `Test webhook failed: ${responseText}`
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  } catch (error) {
    return new Response(
      JSON.stringify({ 
        success: false, 
        message: `Test webhook error: ${error.message}` 
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  }
}

function getTierColor(tier: string): number {
  const colors: { [key: string]: number } = {
    'HT1': 0xff0000, // Red
    'LT1': 0xff4500, // Orange Red
    'HT2': 0xff8c00, // Dark Orange
    'LT2': 0xffa500, // Orange
    'HT3': 0xffff00, // Yellow
    'LT3': 0x9aff9a, // Light Green
    'HT4': 0x00ff00, // Green
    'LT4': 0x00ffff, // Cyan
    'HT5': 0x0000ff, // Blue
    'LT5': 0x8a2be2, // Blue Violet
    'Retired': 0x808080 // Gray
  }
  return colors[tier] || 0x808080
}
