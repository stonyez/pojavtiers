
import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    console.log('Starting daily backup process...')

    // Create backup data
    const { data: backupResult, error: backupError } = await supabaseClient
      .rpc('create_daily_backup')

    if (backupError) {
      console.error('Error creating backup:', backupError)
      return new Response(
        JSON.stringify({ error: backupError.message }),
        { 
          status: 500,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        }
      )
    }

    if (!backupResult?.success) {
      return new Response(
        JSON.stringify({ error: 'Failed to generate backup data' }),
        { 
          status: 500,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        }
      )
    }

    // Delete old backup file (overwrites are handled by upsert, but this ensures clean state)
    await supabaseClient.storage
      .from('backups')
      .remove(['latest-backup.json'])

    console.log('Deleted old backup file')

    // Upload new backup
    const backupName = 'latest-backup.json'
    const backupData = JSON.stringify(backupResult.data, null, 2)
    
    const { error: uploadError } = await supabaseClient.storage
      .from('backups')
      .upload(backupName, new Blob([backupData], { type: 'application/json' }), {
        cacheControl: '3600',
        upsert: true
      })

    if (uploadError) {
      console.error('Error uploading backup:', uploadError)
      return new Response(
        JSON.stringify({ error: uploadError.message }),
        { 
          status: 500,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        }
      )
    }

    console.log('Daily backup completed successfully')

    return new Response(
      JSON.stringify({ 
        success: true, 
        message: 'Daily backup completed',
        filename: backupName
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    )
  } catch (error) {
    console.error('Daily backup function error:', error)
    return new Response(
      JSON.stringify({ error: error.message }),
      { 
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    )
  }
})
