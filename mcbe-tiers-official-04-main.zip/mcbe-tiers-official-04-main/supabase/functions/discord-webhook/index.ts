
import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface WebhookRequest {
  type: 'results' | 'logs' | 'monitoring' | 'updates' | 'actions';
  data: any;
  playerData?: {
    ign: string;
    device?: string;
    region?: string;
    gamemode?: string;
    previousTier?: string;
    newTier?: string;
    avatarUrl?: string;
  };
  adminUser?: string;
}

const supabase = createClient(
  Deno.env.get('SUPABASE_URL') ?? '',
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
);

const generateMinecraftSkinUrl = (ign: string): string => {
  return `https://mc-heads.net/avatar/${ign}/100`;
};

const createDiscordEmbed = (type: string, data: any, playerData?: any): any => {
  const timestamp = new Date().toISOString();
  
  switch (type) {
    case 'results':
      const isHighTier = playerData?.newTier && ['HT1', 'LT1', 'HT2', 'LT2', 'HT3'].includes(playerData.newTier);
      return {
        embeds: [{
          title: isHighTier ? "🏆 High Tier Result Updated" : "📈 Low Tier Result Updated",
          description: `**${playerData?.ign || 'Unknown Player'}** has achieved a new tier ranking!`,
          color: isHighTier ? 0xFFD700 : 0x00FF00,
          thumbnail: {
            url: playerData?.avatarUrl || generateMinecraftSkinUrl(playerData?.ign || 'Steve')
          },
          fields: [
            { 
              name: "📌 Player Information", 
              value: `**IGN:** ${playerData?.ign || 'Unknown'}\n**Device:** ${playerData?.device || 'Unknown'}\n**Region:** ${playerData?.region || 'Unknown'}`, 
              inline: true 
            },
            { 
              name: "🎮 Game Details", 
              value: `**Game Mode:** ${playerData?.gamemode || 'Unknown'}\n**Tier Updated:** ${playerData?.previousTier || 'N/A'} ➜ **${playerData?.newTier || 'N/A'}**`, 
              inline: true 
            },
            { 
              name: "📊 Achievement Level", 
              value: isHighTier ? "🌟 **High Tier Achievement**" : "⭐ **Tier Progression**", 
              inline: false 
            }
          ],
          timestamp: timestamp,
          footer: { 
            text: "MCBE Tiers • Results System", 
            icon_url: "https://mc-heads.net/avatar/notch/32"
          }
        }]
      };
      
    case 'logs':
      return {
        embeds: [{
          title: "📄 System Log Entry",
          description: `**Log Message:** ${data.message || 'System log entry'}`,
          color: 0x0099FF,
          fields: [
            { name: "🕒 Timestamp", value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true },
            { name: "👤 Staff Member", value: data.adminUser || 'System', inline: true },
            { name: "📊 Log Level", value: `\`${data.level || 'INFO'}\``, inline: true }
          ],
          timestamp: timestamp,
          footer: { text: "MCBE Tiers • Black Box Logs System" }
        }]
      };
      
    case 'monitoring':
      return {
        embeds: [{
          title: "🖥️ System Monitoring Alert",
          description: `**Alert:** ${data.message || 'System monitoring alert'}`,
          color: 0xFF6B00,
          fields: [
            { name: "🚨 Alert Type", value: `\`${data.alertType || 'General'}\``, inline: true },
            { name: "📊 System Status", value: data.status || 'Unknown', inline: true },
            { name: "⏰ Alert Time", value: `<t:${Math.floor(Date.now() / 1000)}:R>`, inline: true }
          ],
          timestamp: timestamp,
          footer: { text: "MCBE Tiers • System Monitoring" }
        }]
      };
      
    case 'updates':
      return {
        embeds: [{
          title: "🔁 Admin Data Update",
          description: `**${data.adminUser || 'Unknown Admin'}** has updated player data in the system.`,
          color: 0x9932CC,
          fields: [
            { name: "📌 Player Updated", value: `**${data.playerIgn || 'Unknown'}**`, inline: true },
            { name: "🎮 Game Mode", value: data.gamemode || 'Unknown', inline: true },
            { name: "📈 New Tier", value: `**${data.newTier || 'Unknown'}**`, inline: true },
            { name: "👤 Updated By", value: `**${data.adminUser || 'Unknown'}**`, inline: false }
          ],
          timestamp: timestamp,
          footer: { text: "MCBE Tiers • Admin Updates System" }
        }]
      };
      
    case 'actions':
      return {
        embeds: [{
          title: "⚙️ Admin Action Logged",
          description: `**Action Performed:** ${data.action || 'Admin action performed'}`,
          color: 0xFF4500,
          fields: [
            { name: "👤 Action By", value: `**${data.adminUser || 'Unknown'}**`, inline: true },
            { name: "🎯 Target", value: data.target || 'N/A', inline: true },
            { name: "📝 Action Type", value: `\`${data.actionType || 'Unknown'}\``, inline: true },
            { name: "⏰ Performed At", value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: false }
          ],
          timestamp: timestamp,
          footer: { text: "MCBE Tiers • Admin Actions Log" }
        }]
      };
      
    default:
      return {
        embeds: [{
          title: "📨 System Notification",
          description: data.message || 'System notification',
          color: 0x808080,
          timestamp: timestamp,
          footer: { text: "MCBE Tiers • System" }
        }]
      };
  }
};

const sendWebhook = async (webhookUrl: string, payload: any): Promise<Response> => {
  const response = await fetch(webhookUrl, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });
  
  return response;
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { type, data, playerData, adminUser }: WebhookRequest = await req.json();
    
    console.log(`Processing webhook: ${type}`, { data, playerData });

    // Get webhook configuration
    const { data: webhookConfig, error: configError } = await supabase
      .from('webhook_configs')
      .select('webhook_url, is_active')
      .eq('webhook_type', type)
      .eq('is_active', true)
      .single();

    if (configError || !webhookConfig) {
      console.log(`No active webhook configured for type: ${type}`);
      return new Response(JSON.stringify({ success: false, error: 'No webhook configured' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    // Create Discord embed
    const discordPayload = createDiscordEmbed(type, { ...data, adminUser }, playerData);
    
    // Send webhook
    const webhookResponse = await sendWebhook(webhookConfig.webhook_url, discordPayload);
    const success = webhookResponse.ok;
    
    // Log the webhook attempt
    await supabase.from('webhook_logs').insert({
      webhook_type: type,
      message_content: discordPayload,
      success: success,
      response_status: webhookResponse.status,
      error_message: success ? null : await webhookResponse.text()
    });

    // Update analytics
    await supabase.rpc('increment_webhook_stats', {
      w_type: type,
      increment_api_calls: 1,
      increment_messages: success ? 1 : 0
    });

    return new Response(JSON.stringify({ 
      success: success,
      status: webhookResponse.status 
    }), {
      status: success ? 200 : 400,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Webhook error:', error);
    return new Response(JSON.stringify({ 
      success: false, 
      error: error.message 
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
});
