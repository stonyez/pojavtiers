
-- Create the backups storage bucket
INSERT INTO storage.buckets (id, name, public, allowed_mime_types)
VALUES ('backups', 'backups', false, ARRAY['application/json']);

-- Create RLS policies for the backups bucket
CREATE POLICY "Admin can upload backups" ON storage.objects
FOR INSERT WITH CHECK (
  bucket_id = 'backups' AND
  EXISTS (
    SELECT 1 FROM public.admin_users 
    WHERE ip_address = coalesce(
      current_setting('request.headers', true)::json->>'x-forwarded-for',
      current_setting('request.headers', true)::json->>'x-real-ip',
      inet_client_addr()::text,
      'unknown'
    ) AND role = 'owner'
  )
);

CREATE POLICY "Admin can delete backups" ON storage.objects
FOR DELETE USING (
  bucket_id = 'backups' AND
  EXISTS (
    SELECT 1 FROM public.admin_users 
    WHERE ip_address = coalesce(
      current_setting('request.headers', true)::json->>'x-forwarded-for',
      current_setting('request.headers', true)::json->>'x-real-ip',
      inet_client_addr()::text,
      'unknown'
    ) AND role = 'owner'
  )
);

CREATE POLICY "Admin can view backups" ON storage.objects
FOR SELECT USING (
  bucket_id = 'backups' AND
  EXISTS (
    SELECT 1 FROM public.admin_users 
    WHERE ip_address = coalesce(
      current_setting('request.headers', true)::json->>'x-forwarded-for',
      current_setting('request.headers', true)::json->>'x-real-ip',
      inet_client_addr()::text,
      'unknown'
    )
  )
);
