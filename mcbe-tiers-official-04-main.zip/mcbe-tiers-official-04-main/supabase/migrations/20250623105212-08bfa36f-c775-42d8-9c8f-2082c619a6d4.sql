
-- Update the auth_config table with new passwords
UPDATE public.auth_config 
SET config_value = '$$devil2018,zestycpvp$$', updated_at = now()
WHERE config_key = 'owner_password';

UPDATE public.auth_config 
SET config_value = '-$$Mcbetlstaff20$$-', updated_at = now()
WHERE config_key = 'staff_password';

-- Ensure we have the staff_password entry if it doesn't exist
INSERT INTO public.auth_config (config_key, config_value) 
VALUES ('staff_password', '-$$Mcbetlstaff20$$-')
ON CONFLICT (config_key) DO UPDATE SET 
  config_value = EXCLUDED.config_value,
  updated_at = now();
