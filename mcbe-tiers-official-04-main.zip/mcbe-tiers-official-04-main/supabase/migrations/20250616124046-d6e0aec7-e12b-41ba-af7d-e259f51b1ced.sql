
-- Create webhook types enum
CREATE TYPE webhook_type AS ENUM ('results', 'logs', 'monitoring', 'updates', 'actions');

-- Create webhook configurations table
CREATE TABLE webhook_configs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    webhook_type webhook_type NOT NULL UNIQUE,
    webhook_url TEXT NOT NULL,
    is_active BOOLEAN DEFAULT true,
    test_message_sent BOOLEAN DEFAULT false,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create webhook analytics table
CREATE TABLE webhook_analytics (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    webhook_type webhook_type NOT NULL,
    api_calls_sent INTEGER DEFAULT 0,
    messages_sent INTEGER DEFAULT 0,
    last_sent_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
    UNIQUE(webhook_type)
);

-- Create webhook logs table for tracking all webhook activity
CREATE TABLE webhook_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    webhook_type webhook_type NOT NULL,
    message_content JSONB NOT NULL,
    success BOOLEAN NOT NULL,
    response_status INTEGER,
    error_message TEXT,
    sent_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Initialize analytics rows for each webhook type
INSERT INTO webhook_analytics (webhook_type, api_calls_sent, messages_sent)
VALUES 
    ('results', 0, 0),
    ('logs', 0, 0),
    ('monitoring', 0, 0),
    ('updates', 0, 0),
    ('actions', 0, 0);

-- Enable RLS on all tables
ALTER TABLE webhook_configs ENABLE ROW LEVEL SECURITY;
ALTER TABLE webhook_analytics ENABLE ROW LEVEL SECURITY;
ALTER TABLE webhook_logs ENABLE ROW LEVEL SECURITY;

-- Create policies (admin only access)
CREATE POLICY "Admin access to webhook configs" ON webhook_configs FOR ALL USING (true);
CREATE POLICY "Admin access to webhook analytics" ON webhook_analytics FOR ALL USING (true);
CREATE POLICY "Admin access to webhook logs" ON webhook_logs FOR ALL USING (true);

-- Function to increment webhook analytics
CREATE OR REPLACE FUNCTION increment_webhook_stats(
    w_type webhook_type,
    increment_api_calls INTEGER DEFAULT 1,
    increment_messages INTEGER DEFAULT 0
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    INSERT INTO webhook_analytics (webhook_type, api_calls_sent, messages_sent, last_sent_at)
    VALUES (w_type, increment_api_calls, increment_messages, now())
    ON CONFLICT (webhook_type)
    DO UPDATE SET
        api_calls_sent = webhook_analytics.api_calls_sent + increment_api_calls,
        messages_sent = webhook_analytics.messages_sent + increment_messages,
        last_sent_at = now(),
        updated_at = now();
END;
$$;
