
-- Add missing tier levels to the tier_level enum
ALTER TYPE tier_level ADD VALUE IF NOT EXISTS 'RHT1';
ALTER TYPE tier_level ADD VALUE IF NOT EXISTS 'RLT1';
ALTER TYPE tier_level ADD VALUE IF NOT EXISTS 'RHT2';
ALTER TYPE tier_level ADD VALUE IF NOT EXISTS 'RLT2';

-- Ensure we have all the tier levels that the application expects
-- Standard tiers should already exist, but let's make sure
DO $$
BEGIN
    -- Add standard tiers if they don't exist
    IF NOT EXISTS (SELECT 1 FROM pg_enum WHERE enumlabel = 'HT1' AND enumtypid = 'tier_level'::regtype) THEN
        ALTER TYPE tier_level ADD VALUE 'HT1';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_enum WHERE enumlabel = 'LT1' AND enumtypid = 'tier_level'::regtype) THEN
        ALTER TYPE tier_level ADD VALUE 'LT1';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_enum WHERE enumlabel = 'HT2' AND enumtypid = 'tier_level'::regtype) THEN
        ALTER TYPE tier_level ADD VALUE 'HT2';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_enum WHERE enumlabel = 'LT2' AND enumtypid = 'tier_level'::regtype) THEN
        ALTER TYPE tier_level ADD VALUE 'LT2';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_enum WHERE enumlabel = 'HT3' AND enumtypid = 'tier_level'::regtype) THEN
        ALTER TYPE tier_level ADD VALUE 'HT3';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_enum WHERE enumlabel = 'LT3' AND enumtypid = 'tier_level'::regtype) THEN
        ALTER TYPE tier_level ADD VALUE 'LT3';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_enum WHERE enumlabel = 'HT4' AND enumtypid = 'tier_level'::regtype) THEN
        ALTER TYPE tier_level ADD VALUE 'HT4';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_enum WHERE enumlabel = 'LT4' AND enumtypid = 'tier_level'::regtype) THEN
        ALTER TYPE tier_level ADD VALUE 'LT4';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_enum WHERE enumlabel = 'HT5' AND enumtypid = 'tier_level'::regtype) THEN
        ALTER TYPE tier_level ADD VALUE 'HT5';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_enum WHERE enumlabel = 'LT5' AND enumtypid = 'tier_level'::regtype) THEN
        ALTER TYPE tier_level ADD VALUE 'LT5';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM pg_enum WHERE enumlabel = 'Retired' AND enumtypid = 'tier_level'::regtype) THEN
        ALTER TYPE tier_level ADD VALUE 'Retired';
    END IF;
END $$;
