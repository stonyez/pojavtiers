
-- Fix staff logs table structure and add proper constraints
ALTER TABLE public.staff_logs DROP CONSTRAINT IF EXISTS staff_logs_status_check;
ALTER TABLE public.staff_logs ADD CONSTRAINT staff_logs_status_check 
CHECK (status IN ('pending', 'approved', 'denied', 'error'));

-- Create function to execute approved staff operations
CREATE OR REPLACE FUNCTION public.execute_approved_staff_operation(log_id_param UUID)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    log_record public.staff_logs%ROWTYPE;
    result JSONB := '{"success": false}';
BEGIN
    -- Get the log record
    SELECT * INTO log_record FROM public.staff_logs WHERE log_id = log_id_param AND status = 'approved';
    
    IF NOT FOUND THEN
        RETURN '{"success": false, "error": "Log not found or not approved"}';
    END IF;
    
    -- Execute operation based on type
    CASE log_record.operation_type
        WHEN 'Tier Updated' THEN
            -- Update gamemode_scores if the operation was a tier update
            UPDATE public.gamemode_scores 
            SET internal_tier = (log_record.operation_details->>'new_tier')::public.tier_enum,
                updated_at = now()
            WHERE player_id = (
                SELECT id FROM public.players 
                WHERE ign = (log_record.operation_details->>'player')
            ) AND gamemode = (log_record.operation_details->>'gamemode')::public.gamemode_enum;
            
        WHEN 'Player Result Submitted' THEN
            -- Insert or update gamemode score
            INSERT INTO public.gamemode_scores (player_id, gamemode, internal_tier, points, score)
            VALUES (
                (SELECT id FROM public.players WHERE ign = (log_record.operation_details->>'player')),
                (log_record.operation_details->>'gamemode')::public.gamemode_enum,
                (log_record.operation_details->>'tier')::public.tier_enum,
                (log_record.operation_details->>'points')::INTEGER,
                (log_record.operation_details->>'score')::INTEGER
            )
            ON CONFLICT (player_id, gamemode) 
            DO UPDATE SET 
                internal_tier = EXCLUDED.internal_tier,
                points = EXCLUDED.points,
                score = EXCLUDED.score,
                updated_at = now();
                
        ELSE
            -- Log other operations but don't execute
            NULL;
    END CASE;
    
    -- Update the log as executed
    UPDATE public.staff_logs 
    SET executed_at = now(),
        status = 'approved'
    WHERE log_id = log_id_param;
    
    RETURN '{"success": true}';
END;
$$;

-- Create backup management functions
CREATE OR REPLACE FUNCTION public.create_daily_backup()
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    backup_data JSONB;
    backup_timestamp TEXT;
BEGIN
    backup_timestamp := to_char(now(), 'YYYY-MM-DD_HH24-MI-SS');
    
    -- Create comprehensive backup data
    SELECT jsonb_build_object(
        'timestamp', now(),
        'players', (SELECT jsonb_agg(to_jsonb(p.*)) FROM public.players p),
        'gamemode_scores', (SELECT jsonb_agg(to_jsonb(gs.*)) FROM public.gamemode_scores gs),
        'staff', (SELECT jsonb_agg(to_jsonb(s.*)) FROM public.staff s),
        'staff_logs', (SELECT jsonb_agg(to_jsonb(sl.*)) FROM public.staff_logs sl WHERE created_at >= now() - interval '30 days'),
        'admin_users', (SELECT jsonb_agg(to_jsonb(au.*)) FROM public.admin_users au),
        'webhook_configs', (SELECT jsonb_agg(to_jsonb(wc.*)) FROM public.mcbe_webhook_configs wc)
    ) INTO backup_data;
    
    RETURN jsonb_build_object(
        'success', true,
        'backup_name', 'daily_backup_' || backup_timestamp || '.json',
        'data', backup_data
    );
END;
$$;

-- Add indexes for better performance
CREATE INDEX IF NOT EXISTS idx_staff_logs_created_at ON public.staff_logs(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_staff_logs_operation_type ON public.staff_logs(operation_type);
CREATE INDEX IF NOT EXISTS idx_gamemode_scores_updated_at ON public.gamemode_scores(updated_at DESC);

-- Create storage bucket for backups
INSERT INTO storage.buckets (id, name, public) 
VALUES ('admin-backups', 'admin-backups', false)
ON CONFLICT (id) DO NOTHING;

-- RLS policies for backup bucket
DROP POLICY IF EXISTS "Admin backup access" ON storage.objects;
CREATE POLICY "Admin backup access" ON storage.objects
FOR ALL USING (bucket_id = 'admin-backups');
