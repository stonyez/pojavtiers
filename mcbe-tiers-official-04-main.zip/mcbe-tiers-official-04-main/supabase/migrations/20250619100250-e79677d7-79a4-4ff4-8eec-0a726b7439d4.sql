
-- Create admin_applications table for staff onboarding
CREATE TABLE public.admin_applications (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    discord TEXT NOT NULL,
    secret_key TEXT NOT NULL,
    requested_role TEXT NOT NULL CHECK (requested_role IN ('admin', 'publisher')),
    application_statement TEXT,
    ip_address TEXT NOT NULL,
    status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
    submitted_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
    reviewed_at TIMESTAMP WITH TIME ZONE,
    reviewed_by TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create admin_users table for approved staff with IP-based auth
CREATE TABLE public.admin_users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    application_id UUID REFERENCES public.admin_applications(id),
    ip_address TEXT UNIQUE NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('owner', 'admin', 'publisher')),
    approved_by TEXT NOT NULL,
    approved_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
    last_access TIMESTAMP WITH TIME ZONE,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create lockbox_queue table for task approval workflow
CREATE TABLE public.lockbox_queue (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    task_type TEXT NOT NULL CHECK (task_type IN ('result_submission', 'mass_submission', 'player_update')),
    submitter_ip TEXT NOT NULL,
    submitter_role TEXT NOT NULL,
    task_data JSONB NOT NULL,
    status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
    submitted_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
    reviewed_at TIMESTAMP WITH TIME ZONE,
    reviewed_by TEXT,
    execution_result JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create auth_config table for password management
CREATE TABLE public.auth_config (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    config_key TEXT UNIQUE NOT NULL,
    config_value TEXT NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Insert default passwords
INSERT INTO public.auth_config (config_key, config_value) VALUES 
('owner_password', '$$nullnox911$$'),
('staff_password', '-ratlabsmcbetiers911-');

-- Enable RLS on all new tables
ALTER TABLE public.admin_applications ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.admin_users ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.lockbox_queue ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.auth_config ENABLE ROW LEVEL SECURITY;

-- Create RLS policies (allow all for now, can be refined later)
CREATE POLICY "Allow all operations on admin_applications" ON public.admin_applications FOR ALL USING (true);
CREATE POLICY "Allow all operations on admin_users" ON public.admin_users FOR ALL USING (true);
CREATE POLICY "Allow all operations on lockbox_queue" ON public.lockbox_queue FOR ALL USING (true);
CREATE POLICY "Allow all operations on auth_config" ON public.auth_config FOR ALL USING (true);

-- Create indexes for better performance
CREATE INDEX idx_admin_applications_status ON public.admin_applications(status);
CREATE INDEX idx_admin_applications_ip ON public.admin_applications(ip_address);
CREATE INDEX idx_admin_users_ip ON public.admin_users(ip_address);
CREATE INDEX idx_admin_users_role ON public.admin_users(role);
CREATE INDEX idx_lockbox_queue_status ON public.lockbox_queue(status);
CREATE INDEX idx_lockbox_queue_submitter ON public.lockbox_queue(submitter_ip);
