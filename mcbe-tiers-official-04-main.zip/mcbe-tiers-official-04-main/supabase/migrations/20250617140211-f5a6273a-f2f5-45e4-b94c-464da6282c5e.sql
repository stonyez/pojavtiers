
-- Create enum for webhook types (only tier and logbox)
CREATE TYPE mcbe_webhook_type AS ENUM ('tier', 'logbox');

-- Create webhook configurations table
CREATE TABLE mcbe_webhook_configs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    webhook_type mcbe_webhook_type NOT NULL UNIQUE,
    webhook_url TEXT NOT NULL,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
    created_by TEXT,
    last_tested_at TIMESTAMP WITH TIME ZONE,
    test_status TEXT
);

-- Create webhook queue table for reliable delivery
CREATE TABLE mcbe_webhook_queue (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    webhook_type mcbe_webhook_type NOT NULL,
    payload JSONB NOT NULL,
    status TEXT DEFAULT 'pending', -- pending, processing, sent, failed
    retry_count INTEGER DEFAULT 0,
    max_retries INTEGER DEFAULT 3,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
    scheduled_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
    processed_at TIMESTAMP WITH TIME ZONE,
    error_message TEXT
);

-- Create webhook delivery logs table
CREATE TABLE mcbe_webhook_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    webhook_type mcbe_webhook_type NOT NULL,
    payload_preview TEXT,
    success BOOLEAN NOT NULL,
    http_status INTEGER,
    response_message TEXT,
    delivery_time_ms INTEGER,
    sent_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create skin cache table for tier logs
CREATE TABLE mcbe_skin_cache (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    java_username TEXT NOT NULL UNIQUE,
    skin_url TEXT NOT NULL,
    cached_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
    expires_at TIMESTAMP WITH TIME ZONE DEFAULT now() + INTERVAL '24 hours'
);

-- Enable RLS on all tables
ALTER TABLE mcbe_webhook_configs ENABLE ROW LEVEL SECURITY;
ALTER TABLE mcbe_webhook_queue ENABLE ROW LEVEL SECURITY;
ALTER TABLE mcbe_webhook_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE mcbe_skin_cache ENABLE ROW LEVEL SECURITY;

-- Create policies (admin only access)
CREATE POLICY "Admin access to webhook configs" ON mcbe_webhook_configs FOR ALL USING (true);
CREATE POLICY "Admin access to webhook queue" ON mcbe_webhook_queue FOR ALL USING (true);
CREATE POLICY "Admin access to webhook logs" ON mcbe_webhook_logs FOR ALL USING (true);
CREATE POLICY "Admin access to skin cache" ON mcbe_skin_cache FOR ALL USING (true);

-- Function to queue tier log webhook (fixed parameter ordering)
CREATE OR REPLACE FUNCTION queue_tier_log_webhook(
    player_ign TEXT,
    gamemode TEXT,
    tier TEXT,
    java_username TEXT DEFAULT NULL,
    player_uuid TEXT DEFAULT NULL,
    action_type TEXT DEFAULT 'Result Posted',
    event_timestamp TIMESTAMP WITH TIME ZONE DEFAULT now()
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    webhook_payload JSONB;
BEGIN
    -- Check if tier webhook is configured and active
    IF NOT EXISTS (
        SELECT 1 FROM mcbe_webhook_configs 
        WHERE webhook_type = 'tier' AND is_active = true
    ) THEN
        RETURN;
    END IF;

    -- Prepare webhook payload
    webhook_payload := jsonb_build_object(
        'type', 'tier',
        'action', action_type,
        'player', jsonb_build_object(
            'ign', player_ign,
            'java_username', COALESCE(java_username, player_ign),
            'uuid', player_uuid
        ),
        'gamemode', gamemode,
        'tier', tier,
        'timestamp', event_timestamp,
        'created_at', now()
    );

    -- Queue the webhook
    INSERT INTO mcbe_webhook_queue (webhook_type, payload)
    VALUES ('tier', webhook_payload);
END;
$$;

-- Function to queue logbox log webhook (fixed parameter ordering)
CREATE OR REPLACE FUNCTION queue_logbox_log_webhook(
    log_message TEXT,
    log_level TEXT DEFAULT 'info'
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    webhook_payload JSONB;
BEGIN
    -- Check if logbox webhook is configured and active
    IF NOT EXISTS (
        SELECT 1 FROM mcbe_webhook_configs 
        WHERE webhook_type = 'logbox' AND is_active = true
    ) THEN
        RETURN;
    END IF;

    -- Prepare webhook payload
    webhook_payload := jsonb_build_object(
        'type', 'logbox',
        'message', log_message,
        'level', log_level,
        'timestamp', now()
    );

    -- Queue the webhook
    INSERT INTO mcbe_webhook_queue (webhook_type, payload)
    VALUES ('logbox', webhook_payload);
END;
$$;

-- Trigger function for tier logs on gamemode_scores changes
CREATE OR REPLACE FUNCTION trigger_tier_webhook()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    player_data RECORD;
    action_type TEXT;
BEGIN
    -- Get player data
    SELECT p.ign, p.java_username, p.uuid, gs.gamemode, gs.internal_tier
    INTO player_data
    FROM players p
    JOIN gamemode_scores gs ON p.id = gs.player_id
    WHERE gs.id = COALESCE(NEW.id, OLD.id);
    
    -- Determine action type
    IF TG_OP = 'INSERT' THEN
        action_type := 'Result Posted';
    ELSIF TG_OP = 'UPDATE' AND OLD.internal_tier != NEW.internal_tier THEN
        action_type := 'Result Updated';
    ELSE
        RETURN COALESCE(NEW, OLD);
    END IF;
    
    -- Queue the webhook
    PERFORM queue_tier_log_webhook(
        player_data.ign,
        player_data.gamemode,
        player_data.internal_tier,
        player_data.java_username,
        player_data.uuid,
        action_type,
        now()
    );
    
    RETURN COALESCE(NEW, OLD);
END;
$$;

-- Create trigger for tier webhooks
DROP TRIGGER IF EXISTS tier_webhook_trigger ON gamemode_scores;
CREATE TRIGGER tier_webhook_trigger
    AFTER INSERT OR UPDATE ON gamemode_scores
    FOR EACH ROW
    EXECUTE FUNCTION trigger_tier_webhook();

-- Create indexes for performance
CREATE INDEX idx_webhook_queue_status ON mcbe_webhook_queue(status, scheduled_at);
CREATE INDEX idx_webhook_queue_type ON mcbe_webhook_queue(webhook_type);
CREATE INDEX idx_skin_cache_username ON mcbe_skin_cache(java_username);
CREATE INDEX idx_skin_cache_expires ON mcbe_skin_cache(expires_at);
