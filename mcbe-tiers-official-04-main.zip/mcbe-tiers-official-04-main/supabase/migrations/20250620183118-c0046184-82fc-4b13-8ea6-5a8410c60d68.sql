
-- Create the staff_logs table for tracking staff operations
CREATE TABLE public.staff_logs (
  log_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  staff_id UUID REFERENCES public.staff(id) ON DELETE CASCADE,
  device_id TEXT NOT NULL,
  username TEXT NOT NULL,
  operation_type TEXT NOT NULL,
  operation_details JSONB DEFAULT '{}',
  timestamp TIMESTAMP WITH TIME ZONE DEFAULT now(),
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'denied', 'error')),
  executed_at TIMESTAMP WITH TIME ZONE,
  owner_remarks TEXT,
  error_flag BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Enable RLS on staff_logs table
ALTER TABLE public.staff_logs ENABLE ROW LEVEL SECURITY;

-- Create policies for staff_logs table
CREATE POLICY "Staff can view their own logs" ON public.staff_logs
  FOR SELECT USING (true); -- Allow all authenticated users to read logs for admin purposes

CREATE POLICY "System can insert staff logs" ON public.staff_logs
  FOR INSERT WITH CHECK (true); -- Allow system to insert logs

CREATE POLICY "Owners can update staff logs" ON public.staff_logs
  FOR UPDATE USING (true); -- Allow owners to update logs for approval/denial

-- Create indexes for better performance
CREATE INDEX idx_staff_logs_staff_id ON public.staff_logs(staff_id);
CREATE INDEX idx_staff_logs_status ON public.staff_logs(status);
CREATE INDEX idx_staff_logs_timestamp ON public.staff_logs(timestamp DESC);
