
-- Create staff table for authentication system
CREATE TABLE public.staff (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    username TEXT UNIQUE NOT NULL,
    email TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'analyst',
    permissions JSONB DEFAULT '{}',
    last_login TIMESTAMP WITH TIME ZONE,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create staff sessions table for session management
CREATE TABLE public.staff_sessions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    staff_id UUID REFERENCES public.staff(id) ON DELETE CASCADE,
    session_token TEXT UNIQUE NOT NULL,
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
    last_accessed TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create audit log table for tracking admin actions
CREATE TABLE public.admin_audit_log (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    staff_id UUID REFERENCES public.staff(id),
    action TEXT NOT NULL,
    target_type TEXT, -- 'user', 'staff', 'mass_submission'
    target_id UUID,
    details JSONB,
    ip_address TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Enable RLS on all tables
ALTER TABLE public.staff ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.staff_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.admin_audit_log ENABLE ROW LEVEL SECURITY;

-- Create RLS policies for staff table
CREATE POLICY "Staff can view their own record" ON public.staff
    FOR SELECT USING (id = auth.uid() OR EXISTS (
        SELECT 1 FROM public.staff_sessions ss 
        WHERE ss.staff_id = auth.uid() AND ss.expires_at > now()
    ));

CREATE POLICY "Admins can view all staff" ON public.staff
    FOR SELECT USING (EXISTS (
        SELECT 1 FROM public.staff s 
        JOIN public.staff_sessions ss ON s.id = ss.staff_id
        WHERE ss.staff_id = auth.uid() AND s.role = 'admin' AND ss.expires_at > now()
    ));

CREATE POLICY "Admins can manage staff" ON public.staff
    FOR ALL USING (EXISTS (
        SELECT 1 FROM public.staff s 
        JOIN public.staff_sessions ss ON s.id = ss.staff_id
        WHERE ss.staff_id = auth.uid() AND s.role = 'admin' AND ss.expires_at > now()
    ));

-- Create RLS policies for staff sessions
CREATE POLICY "Staff can manage their own sessions" ON public.staff_sessions
    FOR ALL USING (staff_id = auth.uid());

-- Create RLS policies for audit log
CREATE POLICY "Staff can view audit log based on role" ON public.admin_audit_log
    FOR SELECT USING (EXISTS (
        SELECT 1 FROM public.staff s 
        JOIN public.staff_sessions ss ON s.id = ss.staff_id
        WHERE ss.staff_id = auth.uid() AND s.role IN ('admin', 'moderator') AND ss.expires_at > now()
    ));

-- Create function to hash passwords (using pgcrypto extension)
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- Create function to validate staff session
CREATE OR REPLACE FUNCTION public.validate_staff_session(session_token TEXT)
RETURNS TABLE(staff_id UUID, username TEXT, role TEXT, permissions JSONB)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    RETURN QUERY
    SELECT s.id, s.username, s.role, s.permissions
    FROM public.staff s
    JOIN public.staff_sessions ss ON s.id = ss.staff_id
    WHERE ss.session_token = $1 
    AND ss.expires_at > now()
    AND s.is_active = true;
    
    -- Update last accessed
    UPDATE public.staff_sessions 
    SET last_accessed = now()
    WHERE session_token = $1;
END;
$$;

-- Create function to create staff session
CREATE OR REPLACE FUNCTION public.create_staff_session(p_username TEXT, p_password TEXT)
RETURNS TABLE(success BOOLEAN, session_token TEXT, staff_data JSONB, error_message TEXT)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    staff_record public.staff%ROWTYPE;
    new_session_token TEXT;
    session_expires TIMESTAMP WITH TIME ZONE;
BEGIN
    -- Validate credentials
    SELECT * INTO staff_record
    FROM public.staff
    WHERE username = p_username 
    AND password_hash = crypt(p_password, password_hash)
    AND is_active = true;
    
    IF NOT FOUND THEN
        RETURN QUERY SELECT false, ''::TEXT, '{}'::JSONB, 'Invalid credentials'::TEXT;
        RETURN;
    END IF;
    
    -- Generate session token
    new_session_token := encode(gen_random_bytes(32), 'hex');
    session_expires := now() + interval '24 hours';
    
    -- Insert session
    INSERT INTO public.staff_sessions (staff_id, session_token, expires_at)
    VALUES (staff_record.id, new_session_token, session_expires);
    
    -- Update last login
    UPDATE public.staff 
    SET last_login = now()
    WHERE id = staff_record.id;
    
    -- Return success
    RETURN QUERY SELECT 
        true,
        new_session_token,
        jsonb_build_object(
            'id', staff_record.id,
            'username', staff_record.username,
            'email', staff_record.email,
            'role', staff_record.role,
            'permissions', staff_record.permissions
        ),
        ''::TEXT;
END;
$$;

-- Insert default admin user (password: admin123)
INSERT INTO public.staff (username, email, password_hash, role, permissions)
VALUES (
    'admin',
    'admin@mcbetiers.com',
    crypt('admin123', gen_salt('bf')),
    'admin',
    '{"can_manage_staff": true, "can_manage_users": true, "can_mass_submit": true, "can_view_audit": true}'
);
