
-- Create staff onboarding table for device binding
CREATE TABLE IF NOT EXISTS public.staff_device_bindings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  device_fingerprint TEXT NOT NULL UNIQUE,
  custom_username TEXT NOT NULL,
  staff_role TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.staff_device_bindings ENABLE ROW LEVEL SECURITY;

-- Create policy for staff to manage their own bindings
CREATE POLICY "Staff can manage own device bindings" ON public.staff_device_bindings
  FOR ALL USING (true);

-- Create index for faster lookups
CREATE INDEX IF NOT EXISTS idx_staff_device_bindings_fingerprint 
  ON public.staff_device_bindings(device_fingerprint);
