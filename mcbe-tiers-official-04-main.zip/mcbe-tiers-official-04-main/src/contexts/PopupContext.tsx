
import React, { createContext, useContext, useState } from 'react';
import { GameMode, TierLevel, Player } from '@/services/playerService';
import { isMobileDevice } from '@/utils/deviceUtils';

interface TierAssignment {
  gamemode: string;
  tier: string;
  score: number;
}

interface ResultPopupData {
  player: Player;
  tierAssignments: TierAssignment[];
  combatRank: {
    title: string;
    points: number;
    color: string;
    effectType: string;
    rankNumber: number;
    borderColor: string;
  };
  timestamp: string;
}

interface PopupContextType {
  showPopup: boolean;
  popupData: ResultPopupData | null;
  isMobile: boolean;
  openPopup: (data: ResultPopupData) => void;
  closePopup: () => void;
}

const PopupContext = createContext<PopupContextType | undefined>(undefined);

export function PopupProvider({ children }: { children: React.ReactNode }) {
  const [showPopup, setShowPopup] = useState(false);
  const [popupData, setPopupData] = useState<ResultPopupData | null>(null);
  const [isMobile] = useState(() => isMobileDevice());

  const openPopup = (data: ResultPopupData) => {
    console.log('PopupContext: Opening popup with data:', data);
    
    // Ensure we have valid player data
    if (!data.player || !data.player.ign) {
      console.error('PopupContext: Invalid player data provided:', data.player);
      return;
    }
    
    // Mobile: instant popup with no animations or delays
    if (isMobile) {
      setPopupData(data);
      setShowPopup(true);
    } else {
      // Desktop: smooth transitions with minimal delay
      setShowPopup(false);
      setPopupData(null);
      
      setTimeout(() => {
        setPopupData(data);
        setShowPopup(true);
        console.log('PopupContext: Popup state set - showPopup:', true, 'data:', data);
      }, 10);
    }
  };

  const closePopup = () => {
    console.log('PopupContext: Closing popup');
    
    // Mobile: instant cleanup with no delays
    if (isMobile) {
      setShowPopup(false);
      setPopupData(null);
    } else {
      // Desktop: animated close with delayed cleanup
      setShowPopup(false);
      setTimeout(() => {
        setPopupData(null);
        console.log('PopupContext: Popup data cleared');
      }, 300);
    }
  };

  return (
    <PopupContext.Provider value={{ showPopup, popupData, isMobile, openPopup, closePopup }}>
      {children}
    </PopupContext.Provider>
  );
}

export function usePopup() {
  const context = useContext(PopupContext);
  if (context === undefined) {
    throw new Error('usePopup must be used within a PopupProvider');
  }
  return context;
}
