
import React from 'react';
import { Navbar } from '../components/Navbar';
import { TierGrid } from '../components/TierGrid';
import { Footer } from '../components/Footer';
import { useNavigate, useParams } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { GameMode, Player } from '@/services/playerService';
import { toDatabaseGameMode } from '@/utils/gamemodeCasing';
import { usePopup } from '@/contexts/PopupContext';
import { getPlayerRank } from '@/utils/rankUtils';
import { ModernResultPopup } from '../components/ModernResultPopup';

const SubcategoryPage = () => {
  const { gameMode: gameModeParam } = useParams<{ gameMode: string }>();
  const gameMode = toDatabaseGameMode(gameModeParam || 'Crystal');
  const navigate = useNavigate();
  const { openPopup } = usePopup();
  
  const handleModeChange = (mode: string) => {
    if (mode === 'overall') {
      navigate('/');
    } else {
      navigate(`/${mode.toLowerCase()}`);
    }
  };
  
  const handlePlayerClick = (player: Player, event?: React.MouseEvent) => {
    console.log('SubcategoryPage: Player clicked:', player.ign, 'at:', new Date().toISOString());
    
    if (event) {
      event.preventDefault();
      event.stopPropagation();
    }
    
    // Validate player data
    if (!player || !player.ign) {
      console.error('SubcategoryPage: Invalid player data:', player);
      return;
    }
    
    const rankInfo = getPlayerRank(player.global_points || 0);
    
    const tierAssignments = (player.tierAssignments || []).map(assignment => ({
      gamemode: assignment.gamemode,
      tier: assignment.tier,
      score: assignment.score
    }));
    
    console.log('SubcategoryPage: Opening popup for player:', player.ign);
    
    // Use setTimeout to ensure state updates properly
    setTimeout(() => {
      openPopup({
        player,
        tierAssignments,
        combatRank: {
          title: rankInfo.title,
          points: player.global_points || 0,
          color: rankInfo.color,
          effectType: 'general',
          rankNumber: player.overall_rank || 1,
          borderColor: rankInfo.borderColor
        },
        timestamp: new Date().toISOString()
      });
    }, 50);
  };
  
  return (
    <div className="flex flex-col min-h-screen bg-gradient-dark">
      <Navbar 
        selectedMode={gameModeParam?.toLowerCase() || 'crystal'} 
        onSelectMode={handleModeChange} 
        navigate={navigate}
      />
      
      <main className="flex-grow">
        <div className="content-container py-4 md:py-6">
          <AnimatePresence mode="wait">
            <motion.div
              key={gameMode.toLowerCase()}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3 }}
            >
              <TierGrid selectedMode={gameMode} onPlayerClick={handlePlayerClick} />
            </motion.div>
          </AnimatePresence>
        </div>
      </main>
      
      <Footer />
      
      {/* Main Result Popup */}
      <ModernResultPopup />
    </div>
  );
};

export default SubcategoryPage;
