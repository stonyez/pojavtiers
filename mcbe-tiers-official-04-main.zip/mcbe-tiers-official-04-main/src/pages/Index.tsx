
import React, { useEffect } from 'react';
import { Navbar } from '../components/Navbar';
import { MinecraftLeaderboardTable } from '../components/MinecraftLeaderboardTable';
import { Footer } from '../components/Footer';
import { useLeaderboard } from '../hooks/useLeaderboard';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ModernResultPopup } from '../components/ModernResultPopup';
import { shouldDisableEffects } from '@/utils/mobileOptimization';

const Index = () => {
  const { players, loading, error } = useLeaderboard();
  const navigate = useNavigate();
  const disableEffects = shouldDisableEffects();
  
  const handleModeChange = (mode: string) => {
    if (mode === 'overall') {
      navigate('/');
    } else {
      navigate(`/${mode.toLowerCase()}`);
    }
  };

  if (loading) {
    return (
      <div className="flex flex-col min-h-screen bg-gradient-dark">
        <Navbar selectedMode="overall" onSelectMode={handleModeChange} navigate={navigate} />
        <main className="flex-grow flex items-center justify-center">
          <div className="text-center">
            <motion.div
              className="w-8 h-8 border-4 border-blue-500 border-t-transparent rounded-full mx-auto mb-4"
              animate={!disableEffects ? { rotate: 360 } : {}}
              transition={!disableEffects ? { duration: 1, repeat: Infinity, ease: "linear" } : {}}
            />
            <p className="text-white text-lg">Loading MCBE Tiers leaderboard...</p>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex flex-col min-h-screen bg-gradient-dark">
        <Navbar selectedMode="overall"onSelectMode={handleModeChange} navigate={navigate} />
        <main className="flex-grow flex items-center justify-center">
          <div className="text-center text-red-400">
            <h2 className="text-xl font-bold mb-2">Error Loading Leaderboard</h2>
            <p>{error}</p>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="flex flex-col min-h-screen bg-gradient-dark">
      <header>
        <h1 className="sr-only">MCBE Tiers - Official Minecraft Bedrock PvP Tier List & Rankings 2025</h1>
        <Navbar selectedMode="overall" onSelectMode={handleModeChange} navigate={navigate} />
      </header>
      
      <main className="flex-grow">
        <div className="content-container py-6">
          <motion.div
            initial={!disableEffects ? { opacity: 0, y: 20 } : {}}
            animate={!disableEffects ? { opacity: 1, y: 0 } : {}}
            transition={!disableEffects ? { duration: 0.5 } : {}}
          >
            <section aria-label="Overall leaderboard rankings">
              <h2 className="sr-only">Top Minecraft Bedrock PvP Players - Overall Rankings 2025</h2>
              <MinecraftLeaderboardTable players={players} />
            </section>
          </motion.div>
        </div>
      </main>
      
      <Footer />
      <ModernResultPopup />
    </div>
  );
};

export default Index;
