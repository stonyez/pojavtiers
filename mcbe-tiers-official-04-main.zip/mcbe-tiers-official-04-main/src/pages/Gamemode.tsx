
import React, { useEffect } from 'react';
import { Navbar } from '../components/Navbar';
import { TierGrid } from '../components/TierGrid';
import { Footer } from '../components/Footer';
import { useNavigate, useParams } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { GameMode, Player } from '@/services/playerService';
import { toDatabaseGameMode } from '@/utils/gamemodeCasing';
import { usePopup } from '@/contexts/PopupContext';
import { getPlayerRank } from '@/utils/rankUtils';
import { ModernResultPopup } from '../components/ModernResultPopup';
import { shouldDisableEffects } from '@/utils/mobileOptimization';

const Gamemode = () => {
  const { gamemode: gameModeParam } = useParams<{ gamemode: string }>();
  const gameMode = toDatabaseGameMode(gameModeParam || 'Crystal');
  const navigate = useNavigate();
  const { openPopup } = usePopup();
  const disableEffects = shouldDisableEffects();
  
  const handleModeChange = (mode: string) => {
    if (mode === 'overall') {
      navigate('/');
    } else {
      navigate(`/${mode.toLowerCase()}`);
    }
  };
  
  const handlePlayerClick = (player: Player, event?: React.MouseEvent) => {
    console.log('Gamemode: Player clicked:', player.ign, 'at:', new Date().toISOString());
    
    if (event) {
      event.preventDefault();
      event.stopPropagation();
    }
    
    // Validate player data
    if (!player || !player.ign) {
      console.error('Gamemode: Invalid player data:', player);
      return;
    }
    
    const rankInfo = getPlayerRank(player.global_points || 0);
    
    const tierAssignments = (player.tierAssignments || []).map(assignment => ({
      gamemode: assignment.gamemode,
      tier: assignment.tier,
      score: assignment.score
    }));
    
    console.log('Gamemode: Opening popup for player:', player.ign);
    
    // Use setTimeout to ensure state updates properly
    setTimeout(() => {
      openPopup({
        player,
        tierAssignments,
        combatRank: {
          title: rankInfo.title,
          points: player.global_points || 0,
          color: rankInfo.color,
          effectType: 'general',
          rankNumber: player.overall_rank || 1,
          borderColor: rankInfo.borderColor
        },
        timestamp: new Date().toISOString()
      });
    }, 50);
  };
  
  return (
    <div className="flex flex-col min-h-screen bg-gradient-dark">
      <header>
        <h1 className="sr-only">
          {gameModeParam ? `${gameModeParam.charAt(0).toUpperCase() + gameModeParam.slice(1)} PvP Rankings - MCBE Tiers 2025` : 'MCBE Tiers - Minecraft Bedrock PvP Rankings 2025'}
        </h1>
        <Navbar 
          selectedMode={gameModeParam?.toLowerCase() || 'crystal'} 
          onSelectMode={handleModeChange} 
          navigate={navigate}
        />
      </header>
      
      <main className="flex-grow">
        <div className="content-container py-4 md:py-6">
          <AnimatePresence mode="wait">
            <motion.div
              key={gameMode.toLowerCase()}
              initial={!disableEffects ? { opacity: 0 } : {}}
              animate={!disableEffects ? { opacity: 1 } : {}}
              exit={!disableEffects ? { opacity: 0 } : {}}
              transition={!disableEffects ? { duration: 0.3 } : {}}
            >
              <section aria-label={`${gameModeParam || 'Crystal'} tier rankings`}>
                <h2 className="sr-only">
                  Top {gameModeParam || 'Crystal'} Players - Minecraft Bedrock PvP Tier List 2025
                </h2>
                <TierGrid selectedMode={gameMode} onPlayerClick={handlePlayerClick} />
              </section>
            </motion.div>
          </AnimatePresence>
        </div>
      </main>
      
      <Footer />
      
      {/* Main Result Popup */}
      <ModernResultPopup />
    </div>
  );
};

export default Gamemode;
