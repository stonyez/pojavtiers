import React from 'react';
import { Navbar } from '@/components/Navbar';
import { Footer } from '@/components/Footer';
import { BookOpen, Users, ShoppingCart, LockOpen, Gem, Ban, Rocket, Ticket, HelpCircle, MessageCircle, ArrowRight, Star, Shield, Zap } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { motion } from 'framer-motion';

export default function About() {
  const handleDiscordClick = () => {
    window.open('https://discord.gg/YOUR_SERVER_LINK', '_blank');
  };

  const fadeInUp = {
    initial: { opacity: 0, y: 20 },
    animate: { opacity: 1, y: 0 },
    transition: { duration: 0.6 }
  };

  const staggerContainer = {
    animate: {
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  return (
    <div className="min-h-screen bg-[#1C2526]">
      <Navbar 
        selectedMode=""
        onSelectMode={() => {}}
        navigate={() => {}}
      />
      
      <div className="container mx-auto px-4 py-12 max-w-6xl">
        {/* Hero Section */}
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          <div className="flex justify-center mb-6">
            <div className="bg-gradient-to-r from-blue-500 to-purple-600 p-3 rounded-2xl">
              <BookOpen className="w-8 h-8 text-white" />
            </div>
          </div>
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-6 bg-gradient-to-r from-white via-blue-100 to-purple-100 bg-clip-text text-transparent">
            About MCBE-Tiers
          </h1>
          <p className="text-xl text-white/70 max-w-3xl mx-auto leading-relaxed">
            The most advanced testing and ranking system made exclusively for Minecraft Bedrock Edition
          </p>
        </motion.div>

        {/* Introduction Section */}
        <motion.div 
          className="bg-gradient-to-br from-[#2a3441] to-[#1f2937] rounded-2xl border border-white/10 p-8 mb-12 relative overflow-hidden"
          {...fadeInUp}
        >
          <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-blue-500/10 to-purple-500/10 rounded-full blur-xl"></div>
          <div className="relative">
            <div className="flex items-center gap-4 mb-6">
              <div className="bg-blue-500/20 p-3 rounded-xl">
                <Shield className="w-6 h-6 text-blue-400" />
              </div>
              <h2 className="text-2xl md:text-3xl font-bold text-white">Our Mission</h2>
            </div>
            <div className="grid md:grid-cols-2 gap-8 items-center">
              <div>
                <p className="text-white/80 leading-relaxed mb-4 text-lg">
                  MCBE-Tiers is the most advanced testing and ranking system made exclusively for Minecraft Bedrock Edition.
                </p>
                <p className="text-white/80 leading-relaxed mb-4">
                  Founded by <strong className="text-white">Jamal Hussain (Nednoxx)</strong>, we offer a competitive structure with automated scoring, strict anti-abuse tools, and weekly player evaluations.
                </p>
                <p className="text-white/70">
                  We are <strong className="text-white">not affiliated with Mojang</strong>, but we aim to bring pro-tier standards to the Bedrock community.
                </p>
              </div>
              <div className="space-y-4">
                <div className="flex items-center gap-3 p-3 bg-white/5 rounded-lg">
                  <Star className="w-5 h-5 text-yellow-400" />
                  <span className="text-white/80">Pro-tier Standards</span>
                </div>
                <div className="flex items-center gap-3 p-3 bg-white/5 rounded-lg">
                  <Zap className="w-5 h-5 text-blue-400" />
                  <span className="text-white/80">Automated Scoring</span>
                </div>
                <div className="flex items-center gap-3 p-3 bg-white/5 rounded-lg">
                  <Shield className="w-5 h-5 text-green-400" />
                  <span className="text-white/80">Anti-abuse Protection</span>
                </div>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Discord CTA Section */}
        <motion.div 
          className="bg-gradient-to-r from-indigo-600 to-purple-600 rounded-2xl p-8 mb-12 relative overflow-hidden"
          {...fadeInUp}
        >
          <div className="absolute inset-0 bg-gradient-to-r from-indigo-600/20 to-purple-600/20"></div>
          <div className="relative">
            <div className="flex flex-col md:flex-row items-center justify-between gap-6">
              <div className="text-center md:text-left">
                <div className="flex items-center justify-center md:justify-start gap-3 mb-4">
                  <Users className="w-6 h-6 text-white" />
                  <h2 className="text-2xl font-bold text-white">Join Our Discord Community</h2>
                </div>
                <p className="text-white/90 mb-4 max-w-lg">
                  Join our Discord server to request tests, appeal bans, chat with other players, and access exclusive events. Our moderators are active 24/7 to help.
                </p>
                <Button 
                  onClick={handleDiscordClick}
                  className="bg-white text-indigo-600 hover:bg-white/90 font-semibold flex items-center gap-2 px-6 py-3"
                >
                  <MessageCircle className="w-5 h-5" />
                  Join Discord
                  <ArrowRight className="w-4 h-4" />
                </Button>
              </div>
              <div className="flex-shrink-0">
                <div className="w-24 h-24 bg-white/10 rounded-full flex items-center justify-center">
                  <MessageCircle className="w-12 h-12 text-white" />
                </div>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Shop & Membership Section */}
        <motion.div 
          className="mb-12"
          variants={staggerContainer}
          initial="initial"
          animate="animate"
        >
          <motion.div className="text-center mb-8" variants={fadeInUp}>
            <div className="flex justify-center mb-4">
              <div className="bg-gradient-to-r from-yellow-500 to-orange-500 p-3 rounded-2xl">
                <ShoppingCart className="w-6 h-6 text-white" />
              </div>
            </div>
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Shop & Membership</h2>
            <p className="text-white/70 max-w-2xl mx-auto">
              Choose the tier that fits your competitive needs
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {/* Free Tier */}
            <motion.div 
              className="bg-[#2a3441] rounded-xl border border-white/10 p-6 hover:border-white/20 transition-all duration-300"
              variants={fadeInUp}
            >
              <div className="text-center mb-4">
                <div className="bg-gray-500/20 p-3 rounded-xl inline-block mb-3">
                  <LockOpen className="w-6 h-6 text-gray-400" />
                </div>
                <h3 className="text-xl font-semibold text-white mb-2">Free Tier</h3>
                <div className="text-2xl font-bold text-white">$0</div>
              </div>
              <ul className="text-white/70 space-y-2 text-sm">
                <li className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 bg-gray-400 rounded-full"></div>
                  Free to join
                </li>
                <li className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 bg-gray-400 rounded-full"></div>
                  1 game mode test only
                </li>
                <li className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 bg-gray-400 rounded-full"></div>
                  2-week wait for any retest
                </li>
                <li className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 bg-gray-400 rounded-full"></div>
                  No tournament access
                </li>
              </ul>
            </motion.div>

            {/* Premium Tier */}
            <motion.div 
              className="bg-gradient-to-br from-purple-600/20 to-pink-600/20 rounded-xl border border-purple-500/30 p-6 relative overflow-hidden hover:border-purple-400/50 transition-all duration-300"
              variants={fadeInUp}
            >
              <div className="absolute top-0 right-0 bg-gradient-to-br from-purple-500 to-pink-500 text-white text-xs px-2 py-1 rounded-bl-lg">
                Popular
              </div>
              <div className="text-center mb-4">
                <div className="bg-purple-500/20 p-3 rounded-xl inline-block mb-3">
                  <Gem className="w-6 h-6 text-purple-400" />
                </div>
                <h3 className="text-xl font-semibold text-white mb-2">Premium Tier</h3>
                <div className="text-2xl font-bold text-white">$10</div>
              </div>
              <ul className="text-white/80 space-y-2 text-sm">
                <li className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 bg-purple-400 rounded-full"></div>
                  Multiple game modes
                </li>
                <li className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 bg-purple-400 rounded-full"></div>
                  2-week cooldown per mode
                </li>
                <li className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 bg-purple-400 rounded-full"></div>
                  Private tournaments
                </li>
                <li className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 bg-purple-400 rounded-full"></div>
                  Training servers
                </li>
              </ul>
            </motion.div>

            {/* Tier Unban */}
            <motion.div 
              className="bg-[#2a3441] rounded-xl border border-white/10 p-6 hover:border-white/20 transition-all duration-300"
              variants={fadeInUp}
            >
              <div className="text-center mb-4">
                <div className="bg-red-500/20 p-3 rounded-xl inline-block mb-3">
                  <Ban className="w-6 h-6 text-red-400" />
                </div>
                <h3 className="text-xl font-semibold text-white mb-2">Tier Unban</h3>
                <div className="text-2xl font-bold text-white">$5</div>
              </div>
              <ul className="text-white/70 space-y-2 text-sm">
                <li className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 bg-red-400 rounded-full"></div>
                  Instant ban lift
                </li>
                <li className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 bg-red-400 rounded-full"></div>
                  One-time payment
                </li>
                <li className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 bg-red-400 rounded-full"></div>
                  Discord ticket process
                </li>
              </ul>
            </motion.div>

            {/* Discord Boost */}
            <motion.div 
              className="bg-gradient-to-br from-orange-500/20 to-red-500/20 rounded-xl border border-orange-500/30 p-6 hover:border-orange-400/50 transition-all duration-300"
              variants={fadeInUp}
            >
              <div className="text-center mb-4">
                <div className="bg-orange-500/20 p-3 rounded-xl inline-block mb-3">
                  <Rocket className="w-6 h-6 text-orange-400" />
                </div>
                <h3 className="text-xl font-semibold text-white mb-2">Boost Perk</h3>
                <div className="text-lg font-bold text-orange-400">Server Boost</div>
              </div>
              <ul className="text-white/80 space-y-2 text-sm">
                <li className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 bg-orange-400 rounded-full"></div>
                  Skip 2-week cooldown
                </li>
                <li className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 bg-orange-400 rounded-full"></div>
                  VIP events access
                </li>
                <li className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 bg-orange-400 rounded-full"></div>
                  Behind-the-scenes
                </li>
              </ul>
            </motion.div>
          </div>
        </motion.div>

        {/* How to Buy */}
        <motion.div 
          className="bg-[#2a3441] rounded-2xl border border-white/10 p-8 mb-12"
          {...fadeInUp}
        >
          <div className="flex items-center gap-4 mb-6">
            <div className="bg-pink-500/20 p-3 rounded-xl">
              <Ticket className="w-6 h-6 text-pink-400" />
            </div>
            <h2 className="text-2xl font-bold text-white">How to Purchase</h2>
          </div>
          <div className="bg-white/5 rounded-xl p-6">
            <p className="text-white/80 text-lg leading-relaxed">
              To buy anything listed, open a ticket in our Discord server. 
              Select category: <code className="bg-gray-700 px-2 py-1 rounded text-sm font-mono">Membership</code> or <code className="bg-gray-700 px-2 py-1 rounded text-sm font-mono">Unban</code>. 
              After paying, our staff will verify and activate your item.
            </p>
            <Button 
              onClick={handleDiscordClick}
              className="mt-4 bg-pink-600 hover:bg-pink-700 text-white flex items-center gap-2"
            >
              <Ticket className="w-4 h-4" />
              Open Ticket
            </Button>
          </div>
        </motion.div>

        {/* FAQ Section */}
        <motion.div 
          className="bg-[#2a3441] rounded-2xl border border-white/10 p-8"
          {...fadeInUp}
        >
          <div className="flex items-center gap-4 mb-8">
            <div className="bg-cyan-500/20 p-3 rounded-xl">
              <HelpCircle className="w-6 h-6 text-cyan-400" />
            </div>
            <h2 className="text-2xl font-bold text-white">Frequently Asked Questions</h2>
          </div>
          
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-6">
              <div className="bg-white/5 rounded-xl p-6">
                <h3 className="font-semibold text-white mb-3 text-lg">Who is the owner of MCBE-Tiers?</h3>
                <p className="text-white/80">Jamal Hussain (Nednoxx), expert in AI and backend systems.</p>
              </div>
              
              <div className="bg-white/5 rounded-xl p-6">
                <h3 className="font-semibold text-white mb-3 text-lg">Is this the official tier list?</h3>
                <p className="text-white/80">Yes, this is the official MCBE-Tiers platform. We are not affiliated with Mojang.</p>
              </div>
            </div>
            
            <div className="space-y-6">
              <div className="bg-white/5 rounded-xl p-6">
                <h3 className="font-semibold text-white mb-3 text-lg">Is my data safe?</h3>
                <p className="text-white/80">100%. All data is stored on <strong>Supabase</strong>, encrypted with <strong>PostgreSQL</strong>, and no sensitive user info is saved.</p>
              </div>
              
              <div className="bg-white/5 rounded-xl p-6">
                <h3 className="font-semibold text-white mb-3 text-lg">How do I purchase tiers or unbans?</h3>
                <p className="text-white/80">Create a ticket in Discord and follow the steps provided by our staff.</p>
              </div>
            </div>
          </div>
        </motion.div>
      </div>

      <Footer />
    </div>
  );
}
