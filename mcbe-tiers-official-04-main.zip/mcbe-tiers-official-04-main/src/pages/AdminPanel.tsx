
import React, { useEffect, useState } from 'react';
import { AdminProtectedRoute } from '@/components/admin/AdminProtectedRoute';
import AdminNavigation, { AdminTab } from '@/components/admin/AdminNavigation';
import AnalyticsDashboard from '@/components/admin/AnalyticsDashboard';
import { ModernSubmissionForm } from '@/components/admin/ModernSubmissionForm';
import UnifiedUserPlayerManagement from '@/components/admin/UnifiedUserPlayerManagement';
import DatabaseTools from '@/components/admin/DatabaseTools';
import StaffLogs from '@/components/admin/StaffLogs';
import StaffManagement from '@/components/admin/StaffManagement';
import { StaffProfile } from '@/components/admin/StaffProfile';
import { AdminThemeProvider, useAdminTheme } from '@/contexts/AdminThemeContext';
import { backupService } from '@/services/backupService';
import { useIsMobile } from '@/hooks/use-mobile';
import { Button } from '@/components/ui/button';
import { Menu, X, Moon, Sun, User, Shield } from 'lucide-react';
import { staffAuthService } from '@/services/staffAuthService';
import { EnhancedStaffManagement } from '@/components/admin/EnhancedStaffManagement';
import { staffOnboardingService } from '@/services/staffOnboardingService';
import { newAdminService } from '@/services/newAdminService';

const AdminPanelContent = () => {
  const [activeTab, setActiveTab] = useState<AdminTab>('player-single');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [staffUser, setStaffUser] = useState(staffOnboardingService.getStaffData());
  const isMobile = useIsMobile();
  const { theme, toggleTheme } = useAdminTheme();

  useEffect(() => {
    const checkBackup = () => {
      backupService.checkAndCreateBackup();
    };
    
    checkBackup();
    const interval = setInterval(checkBackup, 24 * 60 * 60 * 1000);
    
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const staffData = staffOnboardingService.getStaffData();
    setStaffUser(staffData);
    
    const interval = setInterval(() => {
      const updatedStaffData = staffOnboardingService.getStaffData();
      setStaffUser(updatedStaffData);
      if (updatedStaffData) {
        staffOnboardingService.updateLastActive();
      }
    }, 30000);
    
    return () => clearInterval(interval);
  }, []);

  const handleLogout = () => {
    staffOnboardingService.resetAllSessions();
    localStorage.removeItem('admin_role');
    localStorage.removeItem('admin_session_active');
    localStorage.removeItem('staff_username');
    staffAuthService.logout();
    window.location.href = '/admin';
  };

  const handleResetSessions = () => {
    staffOnboardingService.resetAllSessions();
    setStaffUser(null);
    window.location.reload();
  };

  const renderAccessDenied = (feature: string) => (
    <div className="text-center py-12">
      <div className="max-w-md mx-auto space-y-4">
        <div className="w-16 h-16 mx-auto rounded-full bg-red-500/20 flex items-center justify-center">
          <Shield className="h-8 w-8 text-red-400" />
        </div>
        <h3 className="text-xl font-semibold text-foreground">Access Denied</h3>
        <p className="text-muted-foreground">Staff role cannot access {feature}</p>
        <p className="text-sm text-muted-foreground">Only Owner has access to this section</p>
      </div>
    </div>
  );

  const renderContent = (userRole: string) => {
    switch (activeTab) {
      case 'player-single':
        // Both owner and staff can access single submission
        if (newAdminService.canAccessSingleSubmission()) {
          return <ModernSubmissionForm />;
        }
        return renderAccessDenied('Single Submission');
      
      case 'player-manage':
        // Both owner and staff can access user management
        if (newAdminService.canAccessUserManagement()) {
          return <UnifiedUserPlayerManagement mode="management" />;
        }
        return renderAccessDenied('User Management');
      
      case 'player-mass':
        // Only owner can access mass submission
        if (newAdminService.canMassSubmit()) {
          return <UnifiedUserPlayerManagement mode="mass-submission" />;
        }
        return renderAccessDenied('Mass Submission');
      
      case 'db-analytics':
        // Only owner can access analytics
        if (newAdminService.canAccessAnalytics()) {
          return <AnalyticsDashboard />;
        }
        return renderAccessDenied('Analytics Dashboard');
      
      case 'db-player-database':
        // Only owner can access database
        if (newAdminService.canAccessDatabaseTools()) {
          return <UnifiedUserPlayerManagement mode="database" />;
        }
        return renderAccessDenied('Player Database');
      
      case 'db-refresh':
      case 'db-backup':
      case 'db-download':
      case 'db-maintenance':
        // Only owner can access database tools
        if (newAdminService.canAccessDatabaseTools()) {
          return <DatabaseTools activeOperation={activeTab} />;
        }
        return renderAccessDenied('Database Operations');
      
      case 'staff-logs':
        // Only owner can view staff logs
        if (newAdminService.canViewStaffLogs()) {
          return <StaffLogs />;
        }
        return renderAccessDenied('Staff Logs');
      
      case 'staff-active':
        // Only owner can view active staff
        if (newAdminService.canManageStaff()) {
          return <EnhancedStaffManagement />;
        }
        return renderAccessDenied('Active Staff Management');
      
      case 'staff-applications':
        // Only owner can view applications
        if (newAdminService.canManageStaff()) {
          return <StaffManagement mode="applications" />;
        }
        return renderAccessDenied('Staff Applications');
      
      case 'staff-approval':
        // Only owner can access approval
        if (newAdminService.canManageStaff()) {
          return <StaffManagement mode="approval" />;
        }
        return renderAccessDenied('Operation Approval');
      
      default:
        return <ModernSubmissionForm />;
    }
  };

  const getRoleIcon = (role: string) => {
    switch (role) {
      case 'owner': return <Shield className="h-4 w-4 text-red-400" />;
      case 'staff': return <Shield className="h-4 w-4 text-blue-400" />;
      case 'admin': return <Shield className="h-4 w-4 text-purple-400" />;
      case 'moderator': return <Shield className="h-4 w-4 text-green-400" />;
      default: return <User className="h-4 w-4 text-muted-foreground" />;
    }
  };

  const getRoleColor = (role: string) => {
    switch (role) {
      case 'owner': return 'text-red-400';
      case 'staff': return 'text-blue-400';
      case 'admin': return 'text-purple-400';
      case 'moderator': return 'text-green-400';
      default: return 'text-muted-foreground';
    }
  };

  const headerCardClass = theme === 'dark' ? 'admin-card-dark' : 'admin-card-light';
  const contentCardClass = theme === 'dark' ? 'admin-card-dark' : 'admin-card-light';

  return (
    <div className="min-h-screen transition-all duration-300">
      <div className="container mx-auto px-2 sm:px-4 py-4 sm:py-8">
        <AdminProtectedRoute>
          {(userRole) => (
            <div className="space-y-6">
              <div className={`${headerCardClass} admin-card p-6`}>
                <div className="flex justify-between items-center">
                  <div className="flex items-center space-x-4">
                    {isMobile && (
                      <Button
                        onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                        variant="ghost"
                        size="sm"
                        className="hover:bg-primary/10"
                      >
                        {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
                      </Button>
                    )}
                    <div className="space-y-1">
                      <h1 className="text-foreground text-2xl font-bold bg-gradient-to-r from-primary via-primary/80 to-primary/60 bg-clip-text text-transparent">
                        Admin Control Panel
                      </h1>
                      <p className="text-muted-foreground text-sm">
                        {userRole === 'staff' ? 'Limited Staff Access - User Management & Single Submission Only' : 'Comprehensive system management dashboard'}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center space-x-4">
                    <Button
                      onClick={toggleTheme}
                      variant="ghost"
                      size="sm"
                      className="admin-button h-10 w-10 p-0 rounded-lg hover:bg-primary/10"
                    >
                      {theme === 'dark' ? 
                        <Sun className="h-4 w-4 text-yellow-500" /> : 
                        <Moon className="h-4 w-4 text-indigo-500" />
                      }
                    </Button>
                    
                    <StaffProfile 
                      onLogout={handleLogout}
                      onResetSessions={handleResetSessions}
                    />
                  </div>
                </div>
              </div>

              <AdminNavigation
                activeTab={activeTab}
                setActiveTab={setActiveTab}
                userRole={userRole}
                isMobile={isMobile}
                mobileMenuOpen={mobileMenuOpen}
                setMobileMenuOpen={setMobileMenuOpen}
              />
              
              <div className={`${contentCardClass} admin-card p-6`}>
                {renderContent(userRole)}
              </div>
            </div>
          )}
        </AdminProtectedRoute>
      </div>
    </div>
  );
};

const AdminPanel = () => {
  return (
    <AdminThemeProvider>
      <AdminPanelContent />
    </AdminThemeProvider>
  );
};

export default AdminPanel;
