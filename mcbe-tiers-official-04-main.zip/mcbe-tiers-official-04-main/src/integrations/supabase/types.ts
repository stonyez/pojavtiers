export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  public: {
    Tables: {
      admin_applications: {
        Row: {
          application_statement: string | null
          created_at: string | null
          discord: string
          id: string
          ip_address: string
          requested_role: string
          reviewed_at: string | null
          reviewed_by: string | null
          secret_key: string
          status: string | null
          submitted_at: string | null
        }
        Insert: {
          application_statement?: string | null
          created_at?: string | null
          discord: string
          id?: string
          ip_address: string
          requested_role: string
          reviewed_at?: string | null
          reviewed_by?: string | null
          secret_key: string
          status?: string | null
          submitted_at?: string | null
        }
        Update: {
          application_statement?: string | null
          created_at?: string | null
          discord?: string
          id?: string
          ip_address?: string
          requested_role?: string
          reviewed_at?: string | null
          reviewed_by?: string | null
          secret_key?: string
          status?: string | null
          submitted_at?: string | null
        }
        Relationships: []
      }
      admin_users: {
        Row: {
          application_id: string | null
          approved_at: string | null
          approved_by: string
          created_at: string | null
          id: string
          ip_address: string
          is_active: boolean | null
          last_access: string | null
          role: string
        }
        Insert: {
          application_id?: string | null
          approved_at?: string | null
          approved_by: string
          created_at?: string | null
          id?: string
          ip_address: string
          is_active?: boolean | null
          last_access?: string | null
          role: string
        }
        Update: {
          application_id?: string | null
          approved_at?: string | null
          approved_by?: string
          created_at?: string | null
          id?: string
          ip_address?: string
          is_active?: boolean | null
          last_access?: string | null
          role?: string
        }
        Relationships: [
          {
            foreignKeyName: "admin_users_application_id_fkey"
            columns: ["application_id"]
            isOneToOne: false
            referencedRelation: "admin_applications"
            referencedColumns: ["id"]
          },
        ]
      }
      auth_config: {
        Row: {
          config_key: string
          config_value: string
          created_at: string | null
          id: string
          updated_at: string | null
        }
        Insert: {
          config_key: string
          config_value: string
          created_at?: string | null
          id?: string
          updated_at?: string | null
        }
        Update: {
          config_key?: string
          config_value?: string
          created_at?: string | null
          id?: string
          updated_at?: string | null
        }
        Relationships: []
      }
      gamemode_scores: {
        Row: {
          created_at: string | null
          display_tier: Database["public"]["Enums"]["tier_level"]
          gamemode: Database["public"]["Enums"]["gamemode_type"]
          id: string
          internal_tier: Database["public"]["Enums"]["tier_level"]
          is_retired: boolean | null
          player_id: string | null
          points: number | null
          score: number | null
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          display_tier: Database["public"]["Enums"]["tier_level"]
          gamemode: Database["public"]["Enums"]["gamemode_type"]
          id?: string
          internal_tier: Database["public"]["Enums"]["tier_level"]
          is_retired?: boolean | null
          player_id?: string | null
          points?: number | null
          score?: number | null
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          display_tier?: Database["public"]["Enums"]["tier_level"]
          gamemode?: Database["public"]["Enums"]["gamemode_type"]
          id?: string
          internal_tier?: Database["public"]["Enums"]["tier_level"]
          is_retired?: boolean | null
          player_id?: string | null
          points?: number | null
          score?: number | null
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "gamemode_scores_player_id_fkey"
            columns: ["player_id"]
            isOneToOne: false
            referencedRelation: "players"
            referencedColumns: ["id"]
          },
        ]
      }
      lockbox_queue: {
        Row: {
          created_at: string | null
          execution_result: Json | null
          id: string
          reviewed_at: string | null
          reviewed_by: string | null
          status: string | null
          submitted_at: string | null
          submitter_ip: string
          submitter_role: string
          task_data: Json
          task_type: string
        }
        Insert: {
          created_at?: string | null
          execution_result?: Json | null
          id?: string
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: string | null
          submitted_at?: string | null
          submitter_ip: string
          submitter_role: string
          task_data: Json
          task_type: string
        }
        Update: {
          created_at?: string | null
          execution_result?: Json | null
          id?: string
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: string | null
          submitted_at?: string | null
          submitter_ip?: string
          submitter_role?: string
          task_data?: Json
          task_type?: string
        }
        Relationships: []
      }
      mcbe_skin_cache: {
        Row: {
          cached_at: string | null
          expires_at: string | null
          id: string
          java_username: string
          skin_url: string
        }
        Insert: {
          cached_at?: string | null
          expires_at?: string | null
          id?: string
          java_username: string
          skin_url: string
        }
        Update: {
          cached_at?: string | null
          expires_at?: string | null
          id?: string
          java_username?: string
          skin_url?: string
        }
        Relationships: []
      }
      mcbe_webhook_configs: {
        Row: {
          created_at: string | null
          created_by: string | null
          id: string
          is_active: boolean | null
          last_tested_at: string | null
          test_status: string | null
          updated_at: string | null
          webhook_type: Database["public"]["Enums"]["mcbe_webhook_type"]
          webhook_url: string
        }
        Insert: {
          created_at?: string | null
          created_by?: string | null
          id?: string
          is_active?: boolean | null
          last_tested_at?: string | null
          test_status?: string | null
          updated_at?: string | null
          webhook_type: Database["public"]["Enums"]["mcbe_webhook_type"]
          webhook_url: string
        }
        Update: {
          created_at?: string | null
          created_by?: string | null
          id?: string
          is_active?: boolean | null
          last_tested_at?: string | null
          test_status?: string | null
          updated_at?: string | null
          webhook_type?: Database["public"]["Enums"]["mcbe_webhook_type"]
          webhook_url?: string
        }
        Relationships: []
      }
      mcbe_webhook_logs: {
        Row: {
          delivery_time_ms: number | null
          http_status: number | null
          id: string
          payload_preview: string | null
          response_message: string | null
          sent_at: string | null
          success: boolean
          webhook_type: Database["public"]["Enums"]["mcbe_webhook_type"]
        }
        Insert: {
          delivery_time_ms?: number | null
          http_status?: number | null
          id?: string
          payload_preview?: string | null
          response_message?: string | null
          sent_at?: string | null
          success: boolean
          webhook_type: Database["public"]["Enums"]["mcbe_webhook_type"]
        }
        Update: {
          delivery_time_ms?: number | null
          http_status?: number | null
          id?: string
          payload_preview?: string | null
          response_message?: string | null
          sent_at?: string | null
          success?: boolean
          webhook_type?: Database["public"]["Enums"]["mcbe_webhook_type"]
        }
        Relationships: []
      }
      mcbe_webhook_queue: {
        Row: {
          created_at: string | null
          error_message: string | null
          id: string
          max_retries: number | null
          payload: Json
          processed_at: string | null
          retry_count: number | null
          scheduled_at: string | null
          status: string | null
          webhook_type: Database["public"]["Enums"]["mcbe_webhook_type"]
        }
        Insert: {
          created_at?: string | null
          error_message?: string | null
          id?: string
          max_retries?: number | null
          payload: Json
          processed_at?: string | null
          retry_count?: number | null
          scheduled_at?: string | null
          status?: string | null
          webhook_type: Database["public"]["Enums"]["mcbe_webhook_type"]
        }
        Update: {
          created_at?: string | null
          error_message?: string | null
          id?: string
          max_retries?: number | null
          payload?: Json
          processed_at?: string | null
          retry_count?: number | null
          scheduled_at?: string | null
          status?: string | null
          webhook_type?: Database["public"]["Enums"]["mcbe_webhook_type"]
        }
        Relationships: []
      }
      players: {
        Row: {
          avatar_url: string | null
          ban_reason: string | null
          banned: boolean | null
          created_at: string | null
          device: Database["public"]["Enums"]["device_type"] | null
          global_points: number | null
          id: string
          ign: string
          java_username: string | null
          overall_rank: number | null
          region: Database["public"]["Enums"]["region_type"] | null
          updated_at: string | null
          user_id: string | null
          uuid: string | null
        }
        Insert: {
          avatar_url?: string | null
          ban_reason?: string | null
          banned?: boolean | null
          created_at?: string | null
          device?: Database["public"]["Enums"]["device_type"] | null
          global_points?: number | null
          id?: string
          ign: string
          java_username?: string | null
          overall_rank?: number | null
          region?: Database["public"]["Enums"]["region_type"] | null
          updated_at?: string | null
          user_id?: string | null
          uuid?: string | null
        }
        Update: {
          avatar_url?: string | null
          ban_reason?: string | null
          banned?: boolean | null
          created_at?: string | null
          device?: Database["public"]["Enums"]["device_type"] | null
          global_points?: number | null
          id?: string
          ign?: string
          java_username?: string | null
          overall_rank?: number | null
          region?: Database["public"]["Enums"]["region_type"] | null
          updated_at?: string | null
          user_id?: string | null
          uuid?: string | null
        }
        Relationships: []
      }
      staff: {
        Row: {
          created_at: string | null
          email: string
          id: string
          is_active: boolean | null
          last_login: string | null
          password_hash: string
          permissions: Json | null
          role: string
          updated_at: string | null
          username: string
        }
        Insert: {
          created_at?: string | null
          email: string
          id?: string
          is_active?: boolean | null
          last_login?: string | null
          password_hash: string
          permissions?: Json | null
          role?: string
          updated_at?: string | null
          username: string
        }
        Update: {
          created_at?: string | null
          email?: string
          id?: string
          is_active?: boolean | null
          last_login?: string | null
          password_hash?: string
          permissions?: Json | null
          role?: string
          updated_at?: string | null
          username?: string
        }
        Relationships: []
      }
      staff_device_bindings: {
        Row: {
          created_at: string | null
          custom_username: string
          device_fingerprint: string
          id: string
          staff_role: string
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          custom_username: string
          device_fingerprint: string
          id?: string
          staff_role: string
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          custom_username?: string
          device_fingerprint?: string
          id?: string
          staff_role?: string
          updated_at?: string | null
        }
        Relationships: []
      }
      staff_logs: {
        Row: {
          created_at: string | null
          device_id: string
          error_flag: boolean | null
          executed_at: string | null
          log_id: string
          operation_details: Json | null
          operation_type: string
          owner_remarks: string | null
          staff_id: string | null
          status: string | null
          timestamp: string | null
          updated_at: string | null
          username: string
        }
        Insert: {
          created_at?: string | null
          device_id: string
          error_flag?: boolean | null
          executed_at?: string | null
          log_id?: string
          operation_details?: Json | null
          operation_type: string
          owner_remarks?: string | null
          staff_id?: string | null
          status?: string | null
          timestamp?: string | null
          updated_at?: string | null
          username: string
        }
        Update: {
          created_at?: string | null
          device_id?: string
          error_flag?: boolean | null
          executed_at?: string | null
          log_id?: string
          operation_details?: Json | null
          operation_type?: string
          owner_remarks?: string | null
          staff_id?: string | null
          status?: string | null
          timestamp?: string | null
          updated_at?: string | null
          username?: string
        }
        Relationships: [
          {
            foreignKeyName: "staff_logs_staff_id_fkey"
            columns: ["staff_id"]
            isOneToOne: false
            referencedRelation: "staff"
            referencedColumns: ["id"]
          },
        ]
      }
      staff_sessions: {
        Row: {
          created_at: string | null
          expires_at: string
          id: string
          last_accessed: string | null
          session_token: string
          staff_id: string | null
        }
        Insert: {
          created_at?: string | null
          expires_at: string
          id?: string
          last_accessed?: string | null
          session_token: string
          staff_id?: string | null
        }
        Update: {
          created_at?: string | null
          expires_at?: string
          id?: string
          last_accessed?: string | null
          session_token?: string
          staff_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "staff_sessions_staff_id_fkey"
            columns: ["staff_id"]
            isOneToOne: false
            referencedRelation: "staff"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      check_admin_access: {
        Args: Record<PropertyKey, never>
        Returns: {
          has_access: boolean
          user_role: Database["public"]["Enums"]["admin_role"]
        }[]
      }
      create_daily_backup: {
        Args: Record<PropertyKey, never>
        Returns: Json
      }
      create_staff_session: {
        Args: { p_username: string; p_password: string }
        Returns: {
          success: boolean
          session_token: string
          staff_data: Json
          error_message: string
        }[]
      }
      execute_approved_staff_operation: {
        Args: { log_id_param: string }
        Returns: Json
      }
      queue_logbox_log_webhook: {
        Args: { log_message: string; log_level?: string }
        Returns: undefined
      }
      queue_tier_log_webhook: {
        Args:
          | Record<PropertyKey, never>
          | {
              player_ign: string
              gamemode: string
              tier: string
              java_username?: string
              player_uuid?: string
              action_type?: string
              event_timestamp?: string
            }
        Returns: undefined
      }
      update_player_global_points: {
        Args: { player_uuid: string }
        Returns: undefined
      }
      validate_staff_session: {
        Args: { session_token: string }
        Returns: {
          staff_id: string
          username: string
          role: string
          permissions: Json
        }[]
      }
    }
    Enums: {
      admin_role: "owner" | "admin" | "moderator" | "tester"
      application_status: "pending" | "approved" | "denied"
      device_type: "PC" | "Console" | "Mobile"
      gamemode_type:
        | "Crystal"
        | "Sword"
        | "Axe"
        | "Mace"
        | "SMP"
        | "NethPot"
        | "Bedwars"
        | "UHC"
      mcbe_webhook_type: "tier" | "logbox"
      region_type: "AF" | "AS" | "OCE" | "NA" | "SA" | "EU"
      tier_level:
        | "HT1"
        | "LT1"
        | "HT2"
        | "LT2"
        | "HT3"
        | "LT3"
        | "HT4"
        | "LT4"
        | "HT5"
        | "LT5"
        | "Retired"
        | "RHT1"
        | "RLT1"
        | "RHT2"
        | "RLT2"
      user_role: "user" | "staff" | "admin" | "superadmin"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DefaultSchema = Database[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof Database },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof (Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        Database[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends { schema: keyof Database }
  ? (Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      Database[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof Database },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends { schema: keyof Database }
  ? Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof Database },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends { schema: keyof Database }
  ? Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof Database },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends { schema: keyof Database }
  ? Database[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof Database },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends { schema: keyof Database }
  ? Database[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      admin_role: ["owner", "admin", "moderator", "tester"],
      application_status: ["pending", "approved", "denied"],
      device_type: ["PC", "Console", "Mobile"],
      gamemode_type: [
        "Crystal",
        "Sword",
        "Axe",
        "Mace",
        "SMP",
        "NethPot",
        "Bedwars",
        "UHC",
      ],
      mcbe_webhook_type: ["tier", "logbox"],
      region_type: ["AF", "AS", "OCE", "NA", "SA", "EU"],
      tier_level: [
        "HT1",
        "LT1",
        "HT2",
        "LT2",
        "HT3",
        "LT3",
        "HT4",
        "LT4",
        "HT5",
        "LT5",
        "Retired",
        "RHT1",
        "RLT1",
        "RHT2",
        "RLT2",
      ],
      user_role: ["user", "staff", "admin", "superadmin"],
    },
  },
} as const
