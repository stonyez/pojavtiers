
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { useToast } from '@/hooks/use-toast';
import { usePlayerManagement } from '@/hooks/usePlayerManagement';
import { GAME_MODES } from '@/lib/constants';
import { GameModeIcon } from '@/components/GameModeIcon';
import { calculatePoints } from '@/lib/pointsCalculation';
import { supabase } from '@/integrations/supabase/client';
import { Shield, ShieldOff } from 'lucide-react';

interface Player {
  id: string;
  ign: string;
  java_username?: string;
  region?: string;
  device?: string;
  banned?: boolean;
  ban_reason?: string;
}

interface SubmitResultsFormProps {
  editMode?: boolean;
  playerToEdit?: Player;
  onSuccess?: () => void;
  onCancel?: () => void;
}

export const SubmitResultsForm: React.FC<SubmitResultsFormProps> = ({
  editMode = false,
  playerToEdit,
  onSuccess,
  onCancel
}) => {
  const [ign, setIgn] = useState('');
  const [gamemode, setGamemode] = useState<string | undefined>(undefined);
  const [tier, setTier] = useState<string | undefined>(undefined);
  const [region, setRegion] = useState<string | undefined>(undefined);
  const [device, setDevice] = useState<string | undefined>(undefined);
  const [javaUsername, setJavaUsername] = useState('');
  const [banned, setBanned] = useState(false);
  const [banReason, setBanReason] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const { toast } = useToast();
  const { submitPlayerResults } = usePlayerManagement();

  const validGameModes = GAME_MODES.filter(mode => 
    mode !== null && 
    mode !== undefined && 
    typeof mode === 'string' && 
    mode.trim().length > 0
  );

  const validTierLevels = ['RHT1', 'RLT1', 'RHT2', 'RLT2', 'HT1', 'LT1', 'HT2', 'LT2', 'HT3', 'LT3', 'HT4', 'LT4', 'HT5', 'LT5', 'Retired'];
  const regions = ['NA', 'EU', 'AS'];
  const devices = ['Mobile', 'PC', 'Console'];

  // Pre-populate form in edit mode
  useEffect(() => {
    if (editMode && playerToEdit) {
      setIgn(playerToEdit.ign || '');
      setJavaUsername(playerToEdit.java_username || '');
      setRegion(playerToEdit.region || undefined);
      setDevice(playerToEdit.device || undefined);
      setBanned(playerToEdit.banned || false);
      setBanReason(playerToEdit.ban_reason || '');
    }
  }, [editMode, playerToEdit]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!ign || (!editMode && (!gamemode || !tier)) || !region || !device) {
      toast({
        title: "Missing Required Information",
        description: editMode 
          ? "IGN, Region, and Device are all required fields"
          : "IGN, Gamemode, Tier, Region, and Device are all required fields",
        variant: "destructive"
      });
      return;
    }

    // Validate ban reason if player is being banned
    if (banned && !banReason.trim()) {
      toast({
        title: "Ban Reason Required",
        description: "A ban reason is required when banning a player",
        variant: "destructive"
      });
      return;
    }

    setIsSubmitting(true);
    try {
      if (editMode && playerToEdit) {
        // Update existing player
        const { error: updateError } = await supabase
          .from('players')
          .update({
            ign,
            java_username: javaUsername || null,
            region: region as "NA" | "EU" | "AS",
            device: device as "Mobile" | "PC" | "Console",
            banned,
            ban_reason: banned ? banReason : null,
            updated_at: new Date().toISOString()
          })
          .eq('id', playerToEdit.id);

        if (updateError) throw updateError;

        toast({
          title: "Success",
          description: `Player ${ign} has been updated successfully`,
        });
      } else {
        // Normal submission flow
        const algorithmicScore = calculatePoints(tier!);
        
        const result = await submitPlayerResults([{
          ign,
          gamemode: gamemode!,
          tier: tier!,
          score: algorithmicScore,
          javaUsername: javaUsername || undefined,
          region: region!,
          device: device!
        }]);

        if (result.success) {
          toast({
            title: "Success",
            description: `Player result submitted successfully with ${algorithmicScore} points`,
          });
        } else {
          toast({
            title: "Error",
            description: result.error || "Failed to submit result",
            variant: "destructive"
          });
          return;
        }
      }

      // Reset form if not in edit mode
      if (!editMode) {
        setIgn('');
        setGamemode(undefined);
        setTier(undefined);
        setRegion(undefined);
        setDevice(undefined);
        setJavaUsername('');
        setBanned(false);
        setBanReason('');
      }

      if (onSuccess) {
        onSuccess();
      }
    } catch (error) {
      console.error('Submission error:', error);
      toast({
        title: "Error",
        description: "An unexpected error occurred",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Card className="bg-gray-900/40 backdrop-blur-xl border-gray-700/50">
      <CardHeader>
        <CardTitle className="text-white">
          {editMode ? `Edit Player: ${playerToEdit?.ign}` : 'Submit Player Results'}
        </CardTitle>
        <CardDescription className="text-gray-400">
          {editMode 
            ? 'Update player information and ban status'
            : 'Add individual player results to the leaderboard (all fields required)'
          }
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="ign" className="text-gray-300">Player IGN *</Label>
              <Input
                id="ign"
                value={ign}
                onChange={(e) => setIgn(e.target.value)}
                placeholder="Enter player IGN"
                className="bg-gray-800/60 border-gray-600/50 text-white"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="javaUsername" className="text-gray-300">Java Username (Optional)</Label>
              <Input
                id="javaUsername"
                value={javaUsername}
                onChange={(e) => setJavaUsername(e.target.value)}
                placeholder="Enter Java username"
                className="bg-gray-800/60 border-gray-600/50 text-white"
              />
            </div>
          </div>

          {!editMode && (
            <>
              <div className="space-y-2">
                <Label htmlFor="gamemode" className="text-gray-300">Gamemode *</Label>
                <Select value={gamemode} onValueChange={setGamemode} required>
                  <SelectTrigger className="bg-gray-800/60 border-gray-600/50 text-white">
                    <SelectValue placeholder="Select gamemode" />
                  </SelectTrigger>
                  <SelectContent className="bg-gray-800 border-gray-600">
                    {validGameModes.map((mode) => (
                      <SelectItem key={mode} value={mode} className="text-white">
                        <div className="flex items-center space-x-2">
                          <GameModeIcon mode={mode} className="h-4 w-4" />
                          <span>{mode}</span>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="tier" className="text-gray-300">Tier *</Label>
                <Select value={tier} onValueChange={setTier} required>
                  <SelectTrigger className="bg-gray-800/60 border-gray-600/50 text-white">
                    <SelectValue placeholder="Select tier" />
                  </SelectTrigger>
                  <SelectContent className="bg-gray-800 border-gray-600">
                    {validTierLevels.map((tierLevel) => (
                      <SelectItem key={tierLevel} value={tierLevel} className="text-white">
                        <div className="flex items-center justify-between w-full">
                          <span>{tierLevel}</span>
                          <span className="text-xs text-gray-400 ml-2">
                            {calculatePoints(tierLevel)} pts
                          </span>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="region" className="text-gray-300">Region *</Label>
              <Select value={region} onValueChange={setRegion} required>
                <SelectTrigger className="bg-gray-800/60 border-gray-600/50 text-white">
                  <SelectValue placeholder="Select region" />
                </SelectTrigger>
                <SelectContent className="bg-gray-800 border-gray-600">
                  {regions.map((reg) => (
                    <SelectItem key={reg} value={reg} className="text-white">{reg}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="device" className="text-gray-300">Device *</Label>
              <Select value={device} onValueChange={setDevice} required>
                <SelectTrigger className="bg-gray-800/60 border-gray-600/50 text-white">
                  <SelectValue placeholder="Select device" />
                </SelectTrigger>
                <SelectContent className="bg-gray-800 border-gray-600">
                  {devices.map((dev) => (
                    <SelectItem key={dev} value={dev} className="text-white">{dev}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {editMode && (
            <div className="space-y-4 p-4 bg-red-900/20 border border-red-500/30 rounded-lg">
              <div className="flex items-center justify-between">
                <Label className="flex items-center space-x-2">
                  {banned ? <ShieldOff className="h-4 w-4 text-red-400" /> : <Shield className="h-4 w-4 text-green-400" />}
                  <span>Ban Status</span>
                </Label>
                <Switch
                  checked={banned}
                  onCheckedChange={setBanned}
                />
              </div>
              
              {banned && (
                <div className="space-y-2">
                  <Label>Ban Reason *</Label>
                  <Textarea
                    value={banReason}
                    onChange={(e) => setBanReason(e.target.value)}
                    placeholder="Enter reason for ban..."
                    className="bg-gray-800/60 border-gray-600/50 text-white"
                    required={banned}
                  />
                </div>
              )}
            </div>
          )}

          {!editMode && tier && (
            <div className="p-3 bg-blue-600/10 border border-blue-500/30 rounded-lg">
              <div className="text-sm text-blue-400">
                <strong>Automatic Points:</strong> {calculatePoints(tier)} points will be assigned for {tier} tier
              </div>
            </div>
          )}

          <div className="flex space-x-3">
            {editMode && onCancel && (
              <Button 
                type="button"
                onClick={onCancel}
                variant="outline"
                className="flex-1 border-gray-600/50 text-gray-300 hover:bg-gray-800/60"
              >
                Cancel
              </Button>
            )}
            <Button 
              type="submit" 
              disabled={isSubmitting} 
              className={`${editMode ? 'flex-1' : 'w-full'} bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white`}
            >
              {isSubmitting ? 'Submitting...' : (editMode ? 'Update Player' : 'Submit Result')}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
};

export default SubmitResultsForm;
