
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { MessageSquare, AlertCircle } from 'lucide-react';

const DiscordWebhookManager = () => {
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <MessageSquare className="h-5 w-5 text-gray-500" />
          <h4 className="text-lg font-bold text-white">Discord Webhooks</h4>
          <Badge variant="outline" className="border-orange-600 text-orange-400">
            <AlertCircle className="h-3 w-3 mr-1" />
            Disabled
          </Badge>
        </div>
      </div>

      <Card className="bg-gray-800/50 border-gray-600/50">
        <CardHeader>
          <CardTitle className="text-white text-center flex items-center justify-center space-x-2">
            <AlertCircle className="h-5 w-5 text-orange-400" />
            <span>Webhook Feature Disabled</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="text-center py-8">
          <div className="space-y-3">
            <div className="text-gray-400">
              The Discord webhook functionality has been temporarily disabled.
            </div>
            <div className="text-sm text-gray-500">
              Database structure and backend functions remain intact for future use.
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default DiscordWebhookManager;
