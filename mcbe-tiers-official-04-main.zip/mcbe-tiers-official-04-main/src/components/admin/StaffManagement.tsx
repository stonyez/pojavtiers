import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { staffService, StaffMember, StaffApplication } from '@/services/staffService';
import { 
  Users, 
  UserCheck, 
  Clock, 
  CheckCircle, 
  XCircle,
  Shield,
  Crown,
  User
} from 'lucide-react';

interface StaffManagementProps {
  mode?: 'management' | 'applications' | 'approval';
}

const StaffManagement: React.FC<StaffManagementProps> = ({ mode = 'management' }) => {
  const [staffMembers, setStaffMembers] = useState<StaffMember[]>([]);
  const [applications, setApplications] = useState<StaffApplication[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const fetchStaffData = async () => {
    setIsLoading(true);
    try {
      const [staffData, applicationData] = await Promise.all([
        staffService.getStaffMembers(),
        staffService.getStaffApplications()
      ]);
      
      setStaffMembers(staffData);
      setApplications(applicationData);
    } catch (error: any) {
      toast({
        title: "Error",
        description: "Failed to fetch staff data",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleReviewApplication = async (applicationId: string, action: 'approve' | 'deny') => {
    setIsLoading(true);
    try {
      const result = await staffService.reviewApplication(applicationId, action, 'owner');
      
      if (result.success) {
        toast({
          title: "Application Reviewed",
          description: `Application has been ${action}d successfully`,
        });
        await fetchStaffData();
      } else {
        throw new Error(result.error);
      }
    } catch (error: any) {
      toast({
        title: "Review Failed",
        description: error.message,
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchStaffData();
  }, []);

  const getRoleIcon = (role: string) => {
    switch (role) {
      case 'owner':
        return <Crown className="h-4 w-4 text-yellow-400" />;
      case 'admin':
        return <Shield className="h-4 w-4 text-blue-400" />;
      default:
        return <User className="h-4 w-4 text-gray-400" />;
    }
  };

  const getRoleColor = (role: string) => {
    switch (role) {
      case 'owner':
        return 'text-yellow-400 bg-yellow-400/10 border-yellow-400/30';
      case 'admin':
        return 'text-blue-400 bg-blue-400/10 border-blue-400/30';
      default:
        return 'text-gray-400 bg-gray-400/10 border-gray-400/30';
    }
  };

  if (mode === 'approval') {
    return (
      <Card className="bg-gray-900/40 backdrop-blur-xl border-gray-700/50">
        <CardHeader className="pb-3">
          <CardTitle className="text-white text-lg flex items-center space-x-2">
            <CheckCircle className="h-5 w-5" />
            <span>Operation Approval Panel</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="text-center text-gray-400 py-6">
              <CheckCircle className="h-12 w-12 mx-auto mb-3 opacity-50" />
              <p>No pending operations require approval</p>
              <p className="text-sm mt-2">All staff actions are being logged and monitored</p>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (mode === 'applications') {
    return (
      <Card className="bg-gray-900/40 backdrop-blur-xl border-gray-700/50">
        <CardHeader className="pb-3">
          <CardTitle className="text-white text-lg flex items-center space-x-2">
            <UserCheck className="h-5 w-5" />
            <span>Staff Applications</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {isLoading ? (
              <div className="text-center text-gray-400 py-6">Loading applications...</div>
            ) : applications.length === 0 ? (
              <div className="text-center text-gray-400 py-6">
                <UserCheck className="h-12 w-12 mx-auto mb-3 opacity-50" />
                <p>No pending applications</p>
              </div>
            ) : (
              <div className="space-y-3">
                {applications.map((application) => (
                  <div key={application.id} className="bg-gray-800/30 p-4 rounded-lg border border-gray-700/40">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center space-x-3 mb-2">
                          <div className="flex items-center space-x-2">
                            <span className="text-white font-medium">{application.discord}</span>
                            <span className={`px-2 py-1 rounded text-xs border ${getRoleColor(application.requested_role)}`}>
                              {application.requested_role.toUpperCase()}
                            </span>
                          </div>
                          <span className="flex items-center space-x-1 text-xs text-gray-400">
                            <Clock className="h-3 w-3" />
                            <span>{new Date(application.submitted_at).toLocaleDateString()}</span>
                          </span>
                        </div>
                        
                        {application.application_statement && (
                          <p className="text-gray-300 text-sm mb-3 italic">
                            "{application.application_statement}"
                          </p>
                        )}
                        
                        <p className="text-xs text-gray-500">Application ID: {application.id}</p>
                      </div>
                      
                      <div className="flex items-center space-x-2 ml-4">
                        <Button
                          onClick={() => handleReviewApplication(application.id, 'approve')}
                          disabled={isLoading}
                          size="sm"
                          className="bg-green-600/20 border border-green-500/50 text-green-400 hover:bg-green-600/30"
                        >
                          <CheckCircle className="h-4 w-4 mr-1" />
                          Approve
                        </Button>
                        <Button
                          onClick={() => handleReviewApplication(application.id, 'deny')}
                          disabled={isLoading}
                          size="sm"
                          className="bg-red-600/20 border border-red-500/50 text-red-400 hover:bg-red-600/30"
                        >
                          <XCircle className="h-4 w-4 mr-1" />
                          Deny
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-gray-900/40 backdrop-blur-xl border-gray-700/50">
      <CardHeader className="pb-3">
        <CardTitle className="text-white text-lg flex items-center space-x-2">
          <Users className="h-5 w-5" />
          <span>Active Staff Members</span>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {isLoading ? (
            <div className="text-center text-gray-400 py-6">Loading staff...</div>
          ) : staffMembers.length === 0 ? (
            <div className="text-center text-gray-400 py-6">
              <Users className="h-12 w-12 mx-auto mb-3 opacity-50" />
              <p>No staff members found</p>
            </div>
          ) : (
            <div className="grid gap-3">
              {staffMembers.map((member) => (
                <div key={member.id} className="bg-gray-800/30 p-4 rounded-lg border border-gray-700/40">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="p-2 bg-gray-700/50 rounded-lg">
                        {getRoleIcon(member.role)}
                      </div>
                      <div>
                        <p className="text-white font-medium">{member.username}</p>
                        <div className="flex items-center space-x-2 mt-1">
                          <span className={`px-2 py-1 rounded text-xs border ${getRoleColor(member.role)}`}>
                            {member.role.toUpperCase()}
                          </span>
                          {member.last_login && (
                            <span className="text-xs text-gray-400">
                              Last login: {new Date(member.last_login).toLocaleDateString()}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <div className={`w-2 h-2 rounded-full ${member.is_active ? 'bg-green-400' : 'bg-red-400'}`} />
                      <span className="text-xs text-gray-400">
                        {member.is_active ? 'Active' : 'Inactive'}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
          
          <div className="pt-4 border-t border-gray-700/50">
            <Button
              onClick={fetchStaffData}
              disabled={isLoading}
              className="w-full bg-blue-600/20 border border-blue-500/50 text-blue-400 hover:bg-blue-600/30"
            >
              <Users className="h-4 w-4 mr-2" />
              Refresh Staff List
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default StaffManagement;
