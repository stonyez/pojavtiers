
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { usePopup } from '@/contexts/PopupContext';
import { authService } from '@/services/authService';
import { supabase } from '@/integrations/supabase/client';
import { getPlayerRank } from '@/utils/rankUtils';
import { ModernSubmissionForm } from './ModernSubmissionForm';
import EnhancedMassSubmissionForm from './EnhancedMassSubmissionForm';
import { 
  Users, 
  Upload, 
  FileSpreadsheet, 
  Search, 
  User,
  Crown,
  Trash2,
  Shield,
  ShieldOff,
  Eye
} from 'lucide-react';

interface Player {
  id: string;
  ign: string;
  java_username?: string;
  uuid?: string;
  avatar_url?: string;
  region?: string;
  device?: string;
  global_points: number;
  overall_rank?: number;
  banned: boolean;
  ban_reason?: string;
  created_at: string;
  updated_at: string;
}

const SubmissionControl = () => {
  const [players, setPlayers] = useState<Player[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();
  const { openPopup } = usePopup();

  const fetchPlayers = async () => {
    setIsLoading(true);
    try {
      console.log('Fetching players for admin panel...');
      const { data, error } = await supabase
        .from('players')
        .select('*')
        .order('global_points', { ascending: false })
        .limit(100);

      if (error) throw error;
      console.log('Fetched players:', data);
      setPlayers(data || []);
    } catch (error: any) {
      console.error('Error fetching players:', error);
      toast({
        title: "Fetch Failed",
        description: `Failed to fetch players: ${error.message}`,
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handlePlayerClick = async (player: Player, event?: React.MouseEvent) => {
    try {
      console.log('Admin player click triggered:', player.ign, 'at:', new Date().toISOString());
      
      // Prevent any default behavior or propagation
      if (event) {
        event.preventDefault();
        event.stopPropagation();
      }
      
      // Fetch player's gamemode scores for the popup
      const { data: gamemodeScores, error } = await supabase
        .from('gamemode_scores')
        .select('gamemode, internal_tier, score, points')
        .eq('player_id', player.id);

      if (error) {
        console.error('Error fetching gamemode scores:', error);
        toast({
          title: "Error",
          description: "Failed to load player details",
          variant: "destructive"
        });
        return;
      }

      const rankInfo = getPlayerRank(player.global_points || 0);
      
      const tierAssignments = (gamemodeScores || []).map(score => ({
        gamemode: score.gamemode,
        tier: score.internal_tier,
        score: score.score || 0
      }));

      console.log('Opening popup with data:', {
        player: {
          ...player,
          region: player.region || 'NA',
          device: player.device || 'PC'
        },
        tierAssignments,
        rankInfo
      });

      // Force a small delay to ensure state updates properly
      setTimeout(() => {
        openPopup({
          player: {
            ...player,
            region: player.region || 'NA',
            device: player.device || 'PC',
            overall_rank: player.overall_rank || 0
          },
          tierAssignments,
          combatRank: {
            title: rankInfo.title,
            points: player.global_points || 0,
            color: rankInfo.color,
            effectType: 'general',
            rankNumber: player.overall_rank || 0,
            borderColor: rankInfo.borderColor || 'border-gray-400'
          },
          timestamp: new Date().toISOString()
        });
      }, 50);
    } catch (error) {
      console.error('Error showing player popup:', error);
      toast({
        title: "Error",
        description: "Failed to load player details",
        variant: "destructive"
      });
    }
  };

  const handleDeletePlayer = async (playerId: string, playerName: string) => {
    if (!authService.isOwner()) {
      toast({
        title: "Permission Denied",
        description: "Only owners can delete players",
        variant: "destructive"
      });
      return;
    }

    if (!confirm(`Are you sure you want to delete ${playerName}? This action cannot be undone.`)) {
      return;
    }

    try {
      const { error } = await supabase
        .from('players')
        .delete()
        .eq('id', playerId);

      if (error) throw error;

      await fetchPlayers();
      toast({
        title: "Player Deleted",
        description: `${playerName} has been removed from the system.`,
      });
    } catch (error: any) {
      toast({
        title: "Delete Failed",
        description: `Failed to delete player: ${error.message}`,
        variant: "destructive"
      });
    }
  };

  const handleToggleBan = async (playerId: string, currentBanned: boolean, playerName: string) => {
    if (!authService.hasPermission('canManageStaff') && !authService.isOwner()) {
      toast({
        title: "Permission Denied",
        description: "You don't have permission to ban/unban players",
        variant: "destructive"
      });
      return;
    }

    try {
      const { error } = await supabase
        .from('players')
        .update({ banned: !currentBanned })
        .eq('id', playerId);

      if (error) throw error;

      await fetchPlayers();
      toast({
        title: currentBanned ? "Player Unbanned" : "Player Banned",
        description: `${playerName} has been ${currentBanned ? 'unbanned' : 'banned'}.`,
      });
    } catch (error: any) {
      toast({
        title: "Ban Toggle Failed",
        description: `Failed to ${currentBanned ? 'unban' : 'ban'} player: ${error.message}`,
        variant: "destructive"
      });
    }
  };

  useEffect(() => {
    fetchPlayers();
  }, []);

  const filteredPlayers = players.filter(player =>
    player.ign?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    player.java_username?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const PlayerCard = ({ player }: { player: Player }) => (
    <div className="group flex items-center justify-between p-3 bg-gray-800/40 rounded-lg border border-gray-700/40 hover:border-gray-600/50 transition-all duration-300 hover:bg-gray-800/60">
      <div className="flex items-center space-x-3 flex-1 min-w-0">
        <div className="w-8 h-8 bg-gradient-to-br from-blue-500/20 to-purple-500/20 border border-blue-500/30 rounded-full flex items-center justify-center flex-shrink-0">
          {player.overall_rank && player.overall_rank <= 3 ? (
            <Crown className="h-4 w-4 text-yellow-400" />
          ) : (
            <User className="h-4 w-4 text-blue-400" />
          )}
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-white font-medium truncate text-sm">
            {player.ign || 'Unknown Player'}
          </p>
          <div className="flex items-center space-x-2 text-xs text-gray-400">
            <span>#{player.overall_rank || 'Unranked'}</span>
            <span>•</span>
            <span>{player.global_points || 0} pts</span>
            {player.region && (
              <>
                <span>•</span>
                <span>{player.region}</span>
              </>
            )}
            {player.banned && (
              <>
                <span>•</span>
                <span className="text-red-400 font-medium">BANNED</span>
              </>
            )}
          </div>
        </div>
      </div>
      
      <div className="flex items-center space-x-1 flex-shrink-0">
        <Button
          onClick={(e) => {
            console.log('View button clicked for player:', player.ign);
            handlePlayerClick(player, e);
          }}
          size="sm"
          className="bg-blue-600/20 border border-blue-500/50 text-blue-400 hover:bg-blue-600/30"
        >
          <Eye className="h-3 w-3" />
        </Button>
        
        {authService.hasPermission('canManageStaff') && (
          <Button
            onClick={(e) => {
              e.preventDefault();
              e.stopPropagation();
              handleToggleBan(player.id, player.banned, player.ign);
            }}
            size="sm"
            className={`${
              player.banned
                ? 'bg-green-600/20 border border-green-500/50 text-green-400 hover:bg-green-600/30'
                : 'bg-yellow-600/20 border border-yellow-500/50 text-yellow-400 hover:bg-yellow-600/30'
            }`}
          >
            {player.banned ? <Shield className="h-3 w-3" /> : <ShieldOff className="h-3 w-3" />}
          </Button>
        )}
        
        {authService.isOwner() && (
          <Button
            onClick={(e) => {
              e.preventDefault();
              e.stopPropagation();
              handleDeletePlayer(player.id, player.ign);
            }}
            size="sm"
            className="bg-red-600/20 border border-red-500/50 text-red-400 hover:bg-red-600/30"
          >
            <Trash2 className="h-3 w-3" />
          </Button>
        )}
      </div>
    </div>
  );

  return (
    <div className="space-y-4">
      <div className="flex items-center space-x-3">
        <div className="p-2 bg-gradient-to-br from-blue-600/20 to-purple-600/20 rounded-lg border border-blue-500/30">
          <Users className="h-5 w-5 text-blue-400" />
        </div>
        <div>
          <h3 className="text-lg font-bold text-white">Submission Control</h3>
          <p className="text-gray-400 text-sm">Player management and result submissions</p>
        </div>
      </div>

      <Card className="bg-gray-900/40 backdrop-blur-xl border-gray-700/50">
        <CardContent className="p-4">
          <Tabs defaultValue="single-submit" className="w-full">
            <TabsList className="grid w-full grid-cols-3 bg-gray-800/50 mb-4">
              <TabsTrigger value="single-submit" className="text-xs">
                <Upload className="h-4 w-4 mr-1" />
                Single Submit
              </TabsTrigger>
              {authService.hasPermission('canMassSubmit') && (
                <TabsTrigger value="mass-submit" className="text-xs">
                  <FileSpreadsheet className="h-4 w-4 mr-1" />
                  Mass Submit
                </TabsTrigger>
              )}
              <TabsTrigger value="players" className="text-xs">
                <Users className="h-4 w-4 mr-1" />
                Players ({filteredPlayers.length})
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="single-submit" className="mt-0">
              <div className="space-y-4">
                <h4 className="text-base font-medium text-white">Submit Individual Results</h4>
                <ModernSubmissionForm />
              </div>
            </TabsContent>
            
            {authService.hasPermission('canMassSubmit') && (
              <TabsContent value="mass-submit" className="mt-0">
                <div className="space-y-4">
                  <h4 className="text-base font-medium text-white">Bulk Result Submission</h4>
                  <EnhancedMassSubmissionForm />
                </div>
              </TabsContent>
            )}
            
            <TabsContent value="players" className="mt-0">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h4 className="text-base font-medium text-white">Player Management</h4>
                  <div className="flex items-center space-x-2">
                    <Input
                      placeholder="Search players..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="w-48 bg-gray-800/50 border-gray-600/50 text-white text-sm"
                    />
                    <Button
                      onClick={fetchPlayers}
                      disabled={isLoading}
                      size="sm"
                      className="bg-blue-600/20 border border-blue-500/50 text-blue-400 hover:bg-blue-600/30"
                    >
                      <Search className="h-4 w-4" />
                    </Button>
                  </div>
                </div>

                {isLoading ? (
                  <div className="text-center text-gray-400 py-6">Loading players...</div>
                ) : filteredPlayers.length === 0 ? (
                  <div className="text-center text-gray-400 py-6">No players found.</div>
                ) : (
                  <div className="space-y-2 max-h-96 overflow-y-auto">
                    {filteredPlayers.map((player) => (
                      <PlayerCard key={player.id} player={player} />
                    ))}
                  </div>
                )}
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
};

export default SubmissionControl;
