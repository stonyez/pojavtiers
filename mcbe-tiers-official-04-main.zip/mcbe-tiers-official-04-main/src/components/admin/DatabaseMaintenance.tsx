
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { 
  Trash2,
  Zap,
  Wrench,
  AlertTriangle,
  CheckCircle,
  Activity
} from 'lucide-react';

interface DatabaseMaintenanceProps {
  activeOperation?: string;
}

const DatabaseMaintenance: React.FC<DatabaseMaintenanceProps> = ({ activeOperation }) => {
  const [isLoading, setIsLoading] = useState(false);
  const [maintenanceMode, setMaintenanceMode] = useState(false);
  const { toast } = useToast();

  const handleCleanupDatabase = async () => {
    if (!confirm('This will remove old logs, expired sessions, and orphaned data. Continue?')) {
      return;
    }
    
    setIsLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 4000));
      toast({
        title: "Cleanup Complete",
        description: "Database cleanup completed successfully. 1.2GB freed.",
      });
    } catch (error) {
      toast({
        title: "Cleanup Failed",
        description: "Failed to cleanup database",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleOptimizeDatabase = async () => {
    setIsLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 5000));
      toast({
        title: "Optimization Complete",
        description: "Database indexes rebuilt and queries optimized",
      });
    } catch (error) {
      toast({
        title: "Optimization Failed",
        description: "Failed to optimize database",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleMaintenanceMode = async () => {
    setIsLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 1000));
      setMaintenanceMode(!maintenanceMode);
      toast({
        title: maintenanceMode ? "Maintenance Mode Disabled" : "Maintenance Mode Enabled",
        description: maintenanceMode 
          ? "System is now accessible to all users" 
          : "System is now in maintenance mode - only owners can access",
      });
    } catch (error) {
      toast({
        title: "Mode Change Failed",
        description: "Failed to toggle maintenance mode",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="text-center space-y-4">
        <div className="flex items-center justify-center space-x-4">
          <Wrench className="h-10 w-10 text-indigo-400" />
          <Zap className="h-8 w-8 text-yellow-400" />
          <Trash2 className="h-8 w-8 text-red-400" />
        </div>
        <h3 className="text-xl font-semibold text-white">Database Maintenance Center</h3>
        <p className="text-gray-400">Comprehensive database maintenance and optimization tools</p>
      </div>

      {/* Maintenance Mode Status */}
      <div className={`${maintenanceMode ? 'bg-red-600/10 border-red-500/30' : 'bg-green-600/10 border-green-500/30'} border rounded-lg p-4`}>
        <div className={`flex items-center justify-center space-x-2 ${maintenanceMode ? 'text-red-400' : 'text-green-400'}`}>
          {maintenanceMode ? <AlertTriangle className="h-5 w-5" /> : <CheckCircle className="h-5 w-5" />}
          <span className="font-medium">
            System Status: {maintenanceMode ? 'Maintenance Mode Active' : 'Operational'}
          </span>
        </div>
        {maintenanceMode && (
          <p className="text-center text-red-300 text-sm mt-2">
            Only owners can access the system during maintenance mode
          </p>
        )}
      </div>

      {/* Action Buttons */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        <div className="space-y-3 p-4 bg-gray-800/30 rounded-lg border border-gray-700/40">
          <div className="text-center">
            <Trash2 className="h-8 w-8 mx-auto text-red-400 mb-2" />
            <h4 className="text-white font-medium">Database Cleanup</h4>
            <p className="text-gray-400 text-xs">Remove old logs and orphaned data</p>
          </div>
          <Button
            onClick={handleCleanupDatabase}
            disabled={isLoading}
            className="w-full bg-red-600/20 border border-red-500/50 text-red-400 hover:bg-red-600/30"
          >
            {isLoading ? 'Cleaning...' : 'Start Cleanup'}
          </Button>
        </div>

        <div className="space-y-3 p-4 bg-gray-800/30 rounded-lg border border-gray-700/40">
          <div className="text-center">
            <Zap className="h-8 w-8 mx-auto text-yellow-400 mb-2" />
            <h4 className="text-white font-medium">Optimize Database</h4>
            <p className="text-gray-400 text-xs">Rebuild indexes and optimize queries</p>
          </div>
          <Button
            onClick={handleOptimizeDatabase}
            disabled={isLoading}
            className="w-full bg-yellow-600/20 border border-yellow-500/50 text-yellow-400 hover:bg-yellow-600/30"
          >
            {isLoading ? 'Optimizing...' : 'Optimize Now'}
          </Button>
        </div>

        <div className="space-y-3 p-4 bg-gray-800/30 rounded-lg border border-gray-700/40">
          <div className="text-center">
            <Wrench className="h-8 w-8 mx-auto text-indigo-400 mb-2" />
            <h4 className="text-white font-medium">Maintenance Mode</h4>
            <p className="text-gray-400 text-xs">Toggle system maintenance mode</p>
          </div>
          <Button
            onClick={handleMaintenanceMode}
            disabled={isLoading}
            className={`w-full ${maintenanceMode ? 'bg-green-600/20 border-green-500/50 text-green-400 hover:bg-green-600/30' : 'bg-red-600/20 border-red-500/50 text-red-400 hover:bg-red-600/30'}`}
          >
            {isLoading ? 'Processing...' : (maintenanceMode ? 'Disable Maintenance' : 'Enable Maintenance')}
          </Button>
        </div>
      </div>

      {/* Warning Notice */}
      <div className="bg-yellow-600/10 border border-yellow-500/30 rounded-lg p-4">
        <div className="flex items-start space-x-3">
          <AlertTriangle className="h-5 w-5 text-yellow-400 flex-shrink-0 mt-0.5" />
          <div>
            <h4 className="text-yellow-400 font-medium text-sm">Important Notice</h4>
            <ul className="text-yellow-300 text-xs mt-1 space-y-1">
              <li>• Database cleanup will permanently remove old data</li>
              <li>• Optimization may temporarily slow down database performance</li>
              <li>• Maintenance mode will block access for non-owner users</li>
              <li>• Always create a backup before performing maintenance tasks</li>
            </ul>
          </div>
        </div>
      </div>

      {/* System Health Indicators */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-gray-800/30 p-3 rounded-lg border border-gray-700/40 text-center">
          <Activity className="h-4 w-4 mx-auto text-green-400 mb-1" />
          <p className="text-gray-400 text-xs">DB Health</p>
          <p className="text-green-400 text-sm font-bold">Excellent</p>
        </div>
        <div className="bg-gray-800/30 p-3 rounded-lg border border-gray-700/40 text-center">
          <Activity className="h-4 w-4 mx-auto text-blue-400 mb-1" />
          <p className="text-gray-400 text-xs">Query Speed</p>
          <p className="text-blue-400 text-sm font-bold">Fast</p>
        </div>
        <div className="bg-gray-800/30 p-3 rounded-lg border border-gray-700/40 text-center">
          <Activity className="h-4 w-4 mx-auto text-yellow-400 mb-1" />
          <p className="text-gray-400 text-xs">Storage Used</p>
          <p className="text-yellow-400 text-sm font-bold">234 MB</p>
        </div>
        <div className="bg-gray-800/30 p-3 rounded-lg border border-gray-700/40 text-center">
          <Activity className="h-4 w-4 mx-auto text-purple-400 mb-1" />
          <p className="text-gray-400 text-xs">Connections</p>
          <p className="text-purple-400 text-sm font-bold">12/50</p>
        </div>
      </div>
    </div>
  );
};

export default DatabaseMaintenance;
