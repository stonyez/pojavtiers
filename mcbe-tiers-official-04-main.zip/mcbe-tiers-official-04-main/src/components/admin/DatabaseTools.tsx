
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { useToast } from '@/hooks/use-toast';
import { useAdminTheme } from '@/contexts/AdminThemeContext';
import BackupManager from './BackupManager';
import DatabaseMaintenance from './DatabaseMaintenance';
import { supabase } from '@/integrations/supabase/client';
import { 
  Database,
  RefreshCw,
  HardDrive,
  Activity,
  Zap,
  Trash2,
  Wrench,
  Download,
  AlertTriangle,
  CheckCircle
} from 'lucide-react';

interface DatabaseToolsProps {
  activeOperation?: string;
}

interface DatabaseStats {
  totalPlayers: number;
  totalScores: number;
  totalStaff: number;
  totalLogs: number;
}

const DatabaseTools: React.FC<DatabaseToolsProps> = ({ activeOperation }) => {
  const [isLoading, setIsLoading] = useState(false);
  const [maintenanceMode, setMaintenanceMode] = useState(false);
  const [dbStats, setDbStats] = useState<DatabaseStats>({
    totalPlayers: 0,
    totalScores: 0,
    totalStaff: 0,
    totalLogs: 0
  });
  const { toast } = useToast();
  const { theme } = useAdminTheme();

  const fetchDatabaseStats = async () => {
    try {
      const [playersResult, scoresResult, staffResult, logsResult] = await Promise.all([
        supabase.from('players').select('id', { count: 'exact', head: true }),
        supabase.from('gamemode_scores').select('id', { count: 'exact', head: true }),
        supabase.from('staff_device_bindings').select('id', { count: 'exact', head: true }),
        supabase.from('staff_logs').select('log_id', { count: 'exact', head: true })
      ]);

      setDbStats({
        totalPlayers: playersResult.count || 0,
        totalScores: scoresResult.count || 0,
        totalStaff: staffResult.count || 0,
        totalLogs: logsResult.count || 0
      });
    } catch (error: any) {
      console.error('Error fetching database stats:', error);
    }
  };

  const handleRefreshData = async () => {
    setIsLoading(true);
    try {
      await fetchDatabaseStats();
      await new Promise(resolve => setTimeout(resolve, 1000));
      toast({
        title: "Data Refreshed",
        description: "Database statistics have been updated successfully",
      });
    } catch (error) {
      toast({
        title: "Refresh Failed",
        description: "Failed to refresh database statistics",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleDatabaseCleanup = async () => {
    if (!confirm('This will remove old logs, expired sessions, and orphaned data. Continue?')) {
      return;
    }
    
    setIsLoading(true);
    try {
      // Clean up old staff sessions (older than 7 days)
      const { error: sessionsError } = await supabase
        .from('staff_sessions')
        .delete()
        .lt('expires_at', new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString());

      if (sessionsError) throw sessionsError;

      // Clean up old webhook logs (older than 30 days)
      const { error: webhookError } = await supabase
        .from('mcbe_webhook_logs')
        .delete()
        .lt('sent_at', new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString());

      if (webhookError) throw webhookError;

      await fetchDatabaseStats();
      
      toast({
        title: "Cleanup Complete",
        description: "Database cleanup completed successfully. Old sessions and logs removed.",
      });
    } catch (error: any) {
      toast({
        title: "Cleanup Failed",
        description: `Failed to cleanup database: ${error.message}`,
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleOptimizeDatabase = async () => {
    setIsLoading(true);
    try {
      // Update player global points to ensure consistency
      const { data: players } = await supabase.from('players').select('id');
      
      if (players) {
        for (const player of players) {
          const { data: scores } = await supabase
            .from('gamemode_scores')
            .select('points')
            .eq('player_id', player.id);
          
          const totalPoints = scores?.reduce((sum, score) => sum + (score.points || 0), 0) || 0;
          
          await supabase
            .from('players')
            .update({ global_points: totalPoints })
            .eq('id', player.id);
        }
      }

      toast({
        title: "Optimization Complete",
        description: "Database has been optimized and player points recalculated",
      });
    } catch (error: any) {
      toast({
        title: "Optimization Failed",
        description: `Failed to optimize database: ${error.message}`,
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleMaintenanceMode = async () => {
    setIsLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 1000));
      setMaintenanceMode(!maintenanceMode);
      
      // Store maintenance mode in localStorage for demo purposes
      localStorage.setItem('maintenance-mode', (!maintenanceMode).toString());
      
      toast({
        title: maintenanceMode ? "Maintenance Mode Disabled" : "Maintenance Mode Enabled",
        description: maintenanceMode 
          ? "System is now accessible to all users" 
          : "System is now in maintenance mode - only owners can access",
      });
    } catch (error: any) {
      toast({
        title: "Mode Change Failed",
        description: `Failed to toggle maintenance mode: ${error.message}`,
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleDownloadBackup = async () => {
    setIsLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('create-daily-backup');
      
      if (error) throw error;
      
      const backupData = JSON.stringify(data, null, 2);
      const blob = new Blob([backupData], { type: 'application/json' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `backup_${new Date().toISOString().split('T')[0]}.json`;
      a.click();
      window.URL.revokeObjectURL(url);

      toast({
        title: "Backup Downloaded",
        description: "Database backup has been downloaded successfully",
      });
    } catch (error: any) {
      toast({
        title: "Download Failed",
        description: `Failed to download backup: ${error.message}`,
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchDatabaseStats();
    const savedMaintenanceMode = localStorage.getItem('maintenance-mode') === 'true';
    setMaintenanceMode(savedMaintenanceMode);
  }, []);

  // Handle specific operations
  if (activeOperation === 'db-backup' || activeOperation === 'db-download') {
    return <BackupManager activeOperation={activeOperation} />;
  }

  if (activeOperation === 'db-maintenance') {
    return <DatabaseMaintenance activeOperation={activeOperation} />;
  }

  if (activeOperation === 'db-refresh') {
    return (
      <div className="text-center space-y-6">
        <div className="flex items-center justify-center w-24 h-24 mx-auto rounded-full bg-gradient-to-br from-blue-500/20 to-cyan-500/20 border border-blue-500/30">
          <RefreshCw className={`h-12 w-12 text-blue-400 ${isLoading ? 'animate-spin' : ''}`} />
        </div>
        <div className="space-y-2">
          <h3 className="text-2xl font-bold text-foreground">Refresh Database</h3>
          <p className="text-muted-foreground max-w-md mx-auto">
            Synchronize and refresh all database connections and statistics
          </p>
        </div>
        <Button
          onClick={handleRefreshData}
          disabled={isLoading}
          className="admin-button admin-button-primary px-8 py-3 text-base"
        >
          <RefreshCw className={`h-5 w-5 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
          {isLoading ? 'Refreshing...' : 'Refresh Data'}
        </Button>
      </div>
    );
  }

  const cardClass = theme === 'dark' ? 'admin-card-dark' : 'admin-card-light';
  const statCardClass = theme === 'dark' ? 'admin-stat-card-dark' : 'admin-stat-card-light';

  // Default overview
  return (
    <div className="space-y-6">
      <Card className={`${cardClass} admin-card`}>
        <CardHeader className="pb-4">
          <CardTitle className="text-foreground text-lg flex items-center space-x-3">
            <div className="p-2 rounded-lg bg-primary/20">
              <Database className="h-5 w-5 text-primary" />
            </div>
            <span>Database Operations</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Maintenance Mode Status */}
          <div className={`${maintenanceMode ? 'bg-red-500/10 border-red-500/30' : 'bg-green-500/10 border-green-500/30'} border rounded-xl p-4 transition-all duration-300`}>
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                {maintenanceMode ? 
                  <AlertTriangle className="h-5 w-5 text-red-400" /> : 
                  <CheckCircle className="h-5 w-5 text-green-400" />
                }
                <div>
                  <p className={`font-medium ${maintenanceMode ? 'text-red-400' : 'text-green-400'}`}>
                    System Status: {maintenanceMode ? 'Maintenance Mode Active' : 'Operational'}
                  </p>
                  <p className="text-muted-foreground text-sm">
                    {maintenanceMode ? 'Only owners can access the system' : 'All users have full access'}
                  </p>
                </div>
              </div>
              <Switch
                checked={maintenanceMode}
                onCheckedChange={handleMaintenanceMode}
                disabled={isLoading}
              />
            </div>
          </div>

          {/* Action Buttons Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <Button
              onClick={handleRefreshData}
              disabled={isLoading}
              className="admin-button admin-button-primary h-20 flex flex-col items-center justify-center space-y-2"
            >
              <RefreshCw className={`h-6 w-6 ${isLoading ? 'animate-spin' : ''}`} />
              <span className="text-sm font-medium">Refresh Data</span>
            </Button>

            <Button
              onClick={handleDatabaseCleanup}
              disabled={isLoading}
              className="admin-button admin-button-warning h-20 flex flex-col items-center justify-center space-y-2"
            >
              <Trash2 className="h-6 w-6" />
              <span className="text-sm font-medium">Cleanup Database</span>
            </Button>

            <Button
              onClick={handleOptimizeDatabase}
              disabled={isLoading}
              className="admin-button admin-button-success h-20 flex flex-col items-center justify-center space-y-2"
            >
              <Zap className="h-6 w-6" />
              <span className="text-sm font-medium">Optimize Database</span>
            </Button>

            <Button
              onClick={handleDownloadBackup}
              disabled={isLoading}
              className="admin-button admin-button-primary h-20 flex flex-col items-center justify-center space-y-2"
            >
              <Download className="h-6 w-6" />
              <span className="text-sm font-medium">Download Backup</span>
            </Button>
          </div>

          {/* Database Statistics */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <HardDrive className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm font-medium text-foreground">Live Database Statistics</span>
              </div>
              <Button
                onClick={handleRefreshData}
                disabled={isLoading}
                size="sm"
                variant="ghost"
                className="h-8 w-8 p-0"
              >
                <RefreshCw className={`h-3 w-3 ${isLoading ? 'animate-spin' : ''}`} />
              </Button>
            </div>
            
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              <div className={`admin-stat-card ${statCardClass} text-center`}>
                <div className="flex items-center justify-center w-8 h-8 mx-auto mb-2 rounded-lg bg-blue-500/20">
                  <Activity className="h-4 w-4 text-blue-400" />
                </div>
                <p className="text-muted-foreground text-xs">Players</p>
                <p className="text-blue-400 font-bold text-lg">{dbStats.totalPlayers.toLocaleString()}</p>
              </div>
              
              <div className={`admin-stat-card ${statCardClass} text-center`}>
                <div className="flex items-center justify-center w-8 h-8 mx-auto mb-2 rounded-lg bg-green-500/20">
                  <Activity className="h-4 w-4 text-green-400" />
                </div>
                <p className="text-muted-foreground text-xs">Game Scores</p>
                <p className="text-green-400 font-bold text-lg">{dbStats.totalScores.toLocaleString()}</p>
              </div>
              
              <div className={`admin-stat-card ${statCardClass} text-center`}>
                <div className="flex items-center justify-center w-8 h-8 mx-auto mb-2 rounded-lg bg-purple-500/20">
                  <Activity className="h-4 w-4 text-purple-400" />
                </div>
                <p className="text-muted-foreground text-xs">Staff Members</p>
                <p className="text-purple-400 font-bold text-lg">{dbStats.totalStaff.toLocaleString()}</p>
              </div>
              
              <div className={`admin-stat-card ${statCardClass} text-center`}>
                <div className="flex items-center justify-center w-8 h-8 mx-auto mb-2 rounded-lg bg-yellow-500/20">
                  <Activity className="h-4 w-4 text-yellow-400" />
                </div>
                <p className="text-muted-foreground text-xs">Staff Logs</p>
                <p className="text-yellow-400 font-bold text-lg">{dbStats.totalLogs.toLocaleString()}</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default DatabaseTools;
