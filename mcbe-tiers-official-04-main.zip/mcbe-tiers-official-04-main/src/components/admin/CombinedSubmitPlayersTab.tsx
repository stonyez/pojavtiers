
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import SubmitResultsForm from './SubmitResultsForm';
import MassSubmissionForm from './MassSubmissionForm';
import { EnhancedSubmissionSystem } from './EnhancedSubmissionSystem';
import { supabase } from '@/integrations/supabase/client';
import { 
  Upload, 
  FileSpreadsheet, 
  Trophy, 
  Search,
  Users,
  RefreshCw
} from 'lucide-react';

interface Player {
  id: string;
  ign: string;
  java_username?: string;
  region?: string;
  device?: string;
  global_points: number;
  gamemode_scores?: Array<{
    id: string;
    gamemode: string;
    internal_tier: string;
    display_tier: string;
    points: number;
  }>;
}

export const CombinedSubmitPlayersTab = () => {
  const [activeSubmissionTab, setActiveSubmissionTab] = useState<'single' | 'mass' | 'enhanced'>('single');
  const [recentPlayers, setRecentPlayers] = useState<Player[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const fetchRecentPlayers = async () => {
    setIsLoading(true);
    try {
      const { data, error } = await supabase
        .from('players')
        .select(`
          *,
          gamemode_scores (
            id,
            gamemode,
            internal_tier,
            display_tier,
            points
          )
        `)
        .order('updated_at', { ascending: false })
        .limit(20);

      if (error) throw error;
      setRecentPlayers(data || []);
    } catch (error) {
      console.error('Error fetching recent players:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const searchPlayers = async () => {
    if (!searchTerm.trim()) {
      fetchRecentPlayers();
      return;
    }

    setIsLoading(true);
    try {
      const { data, error } = await supabase
        .from('players')
        .select(`
          *,
          gamemode_scores (
            id,
            gamemode,
            internal_tier,
            display_tier,
            points
          )
        `)
        .ilike('ign', `%${searchTerm}%`)
        .order('global_points', { ascending: false })
        .limit(20);

      if (error) throw error;
      setRecentPlayers(data || []);
    } catch (error) {
      console.error('Error searching players:', error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchRecentPlayers();
  }, []);

  useEffect(() => {
    const timeoutId = setTimeout(() => {
      searchPlayers();
    }, 300);

    return () => clearTimeout(timeoutId);
  }, [searchTerm]);

  const renderSubmissionContent = () => {
    switch (activeSubmissionTab) {
      case 'single':
        return <SubmitResultsForm />;
      case 'mass':
        return <MassSubmissionForm />;
      case 'enhanced':
        return <EnhancedSubmissionSystem />;
      default:
        return null;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center space-x-3">
        <div className="p-3 bg-gradient-to-br from-green-600/20 to-blue-600/20 rounded-xl border border-green-500/30 shadow-lg">
          <Upload className="h-6 w-6 text-green-400" />
        </div>
        <div>
          <h3 className="text-xl font-bold text-white">Player Submission Center</h3>
          <p className="text-gray-400 text-sm">Submit results and manage player data</p>
        </div>
      </div>

      {/* Enhanced Submission Methods Tabs */}
      <div className="flex space-x-1 bg-gray-800/60 backdrop-blur-sm p-1 rounded-lg border border-gray-700/50 shadow-inner">
        <button
          onClick={() => setActiveSubmissionTab('single')}
          className={`flex-1 px-6 py-3 rounded-md text-sm font-medium transition-all duration-200 ${
            activeSubmissionTab === 'single'
              ? 'bg-gradient-to-r from-green-600/30 to-green-500/20 text-green-400 border border-green-500/50 shadow-lg'
              : 'text-gray-400 hover:text-gray-300 hover:bg-gray-700/50'
          }`}
        >
          <Upload className="h-4 w-4 mr-2 inline" />
          Single Result
        </button>
        <button
          onClick={() => setActiveSubmissionTab('mass')}
          className={`flex-1 px-6 py-3 rounded-md text-sm font-medium transition-all duration-200 ${
            activeSubmissionTab === 'mass'
              ? 'bg-gradient-to-r from-blue-600/30 to-blue-500/20 text-blue-400 border border-blue-500/50 shadow-lg'
              : 'text-gray-400 hover:text-gray-300 hover:bg-gray-700/50'
          }`}
        >
          <FileSpreadsheet className="h-4 w-4 mr-2 inline" />
          Mass Import
        </button>
        <button
          onClick={() => setActiveSubmissionTab('enhanced')}
          className={`flex-1 px-6 py-3 rounded-md text-sm font-medium transition-all duration-200 ${
            activeSubmissionTab === 'enhanced'
              ? 'bg-gradient-to-r from-purple-600/30 to-purple-500/20 text-purple-400 border border-purple-500/50 shadow-lg'
              : 'text-gray-400 hover:text-gray-300 hover:bg-gray-700/50'
          }`}
        >
          <Trophy className="h-4 w-4 mr-2 inline" />
          Multi-Gamemode
        </button>
      </div>

      {/* Submission Form */}
      <div className="relative">
        {renderSubmissionContent()}
      </div>

      {/* Recent/Search Results */}
      <Card className="bg-gray-900/60 backdrop-blur-xl border-gray-700/50 shadow-xl">
        <CardHeader className="pb-4">
          <div className="flex items-center justify-between">
            <CardTitle className="text-white flex items-center">
              <Users className="h-5 w-5 mr-2 text-blue-400" />
              Recent Submissions & Search
            </CardTitle>
            <Button
              onClick={fetchRecentPlayers}
              size="sm"
              variant="outline"
              className="border-gray-600 text-gray-300 hover:bg-gray-700 hover:border-gray-500 transition-all"
              disabled={isLoading}
            >
              <RefreshCw className={`h-4 w-4 mr-1 ${isLoading ? 'animate-spin' : ''}`} />
              Refresh
            </Button>
          </div>
          <div className="flex items-center space-x-2 mt-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                placeholder="Search players by IGN..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 bg-gray-800/60 border-gray-600/50 text-white placeholder-gray-400 focus:border-blue-500/50 focus:ring-blue-500/20"
              />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-96 w-full">
            <div className="space-y-3">
              {recentPlayers.length === 0 ? (
                <div className="text-center text-gray-400 py-8">
                  {searchTerm ? 'No players found matching your search.' : 'No recent submissions found.'}
                </div>
              ) : (
                recentPlayers.map((player) => (
                  <div key={player.id} className="p-3 bg-gray-800/40 rounded-lg border border-gray-700/40">
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <p className="text-white font-medium">{player.ign}</p>
                        <div className="flex items-center space-x-2 text-xs text-gray-400 mt-1">
                          <span>Java: {player.java_username || 'N/A'}</span>
                          {player.region && <span>Region: {player.region}</span>}
                          {player.device && <span>Device: {player.device}</span>}
                          <span>Points: {player.global_points}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </ScrollArea>
        </CardContent>
      </Card>
    </div>
  );
};
