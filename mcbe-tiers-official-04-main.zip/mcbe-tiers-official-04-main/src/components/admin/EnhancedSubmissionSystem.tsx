import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { Trophy, Send, Plus, X } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { calculatePoints } from '@/lib/pointsCalculation';

interface GamemodeTier {
  gamemode: string;
  tier: string;
}

interface SubmissionForm {
  ign: string;
  java_username: string;
  region: string;
  device: string;
  gamemode_tiers: GamemodeTier[];
}

export const EnhancedSubmissionSystem = () => {
  const [form, setForm] = useState<SubmissionForm>({
    ign: '',
    java_username: '',
    region: '',
    device: '',
    gamemode_tiers: [{ gamemode: '', tier: '' }]
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  const gamemodes = ['Crystal', 'Sword', 'Mace', 'Axe', 'SMP', 'UHC', 'NethPot', 'Bedwars'];
  const regions = ['NA', 'EU', 'AS', 'OCE', 'SA', 'AF'];
  const devices = ['Mobile', 'PC', 'Console'];
  const tiers = ['RHT1', 'RLT1', 'RHT2', 'RLT2', 'HT1', 'LT1', 'HT2', 'LT2', 'HT3', 'LT3', 'HT4', 'LT4', 'HT5', 'LT5', 'Retired'];

  const addGamemodeTier = () => {
    setForm({
      ...form,
      gamemode_tiers: [...form.gamemode_tiers, { gamemode: '', tier: '' }]
    });
  };

  const removeGamemodeTier = (index: number) => {
    setForm({
      ...form,
      gamemode_tiers: form.gamemode_tiers.filter((_, i) => i !== index)
    });
  };

  const updateGamemodeTier = (index: number, field: keyof GamemodeTier, value: string) => {
    const updated = [...form.gamemode_tiers];
    updated[index][field] = value;
    setForm({ ...form, gamemode_tiers: updated });
  };

  const handleSubmit = async () => {
    // Mandatory field validation
    if (!form.ign.trim() || !form.region || !form.device) {
      toast({
        title: "Validation Error",
        description: "Player IGN, Region, and Device are required fields",
        variant: "destructive"
      });
      return;
    }

    const validTiers = form.gamemode_tiers.filter(gt => gt.gamemode && gt.tier);
    if (validTiers.length === 0) {
      toast({
        title: "Validation Error",
        description: "At least one gamemode tier is required",
        variant: "destructive"
      });
      return;
    }

    setIsSubmitting(true);
    try {
      // First, search for existing player by IGN
      const { data: existingPlayer, error: searchError } = await supabase
        .from('players')
        .select('id')
        .eq('ign', form.ign.trim())
        .maybeSingle();

      if (searchError) {
        console.error('Error searching for player:', searchError);
        throw new Error('Failed to search for existing player');
      }

      let playerId: string;

      if (existingPlayer) {
        // Update existing player
        playerId = existingPlayer.id;
        const { error: updateError } = await supabase
          .from('players')
          .update({
            java_username: form.java_username.trim() || null,
            region: form.region as "NA" | "EU" | "AS" | "OCE" | "SA" | "AF",
            device: form.device as "Mobile" | "PC" | "Console",
            updated_at: new Date().toISOString()
          })
          .eq('id', playerId);

        if (updateError) throw updateError;
      } else {
        // Create new player
        const { data: newPlayer, error: createError } = await supabase
          .from('players')
          .insert({
            ign: form.ign.trim(),
            java_username: form.java_username.trim() || null,
            region: form.region as "NA" | "EU" | "AS" | "OCE" | "SA" | "AF",
            device: form.device as "Mobile" | "PC" | "Console",
            global_points: 0,
            banned: false
          })
          .select('id')
          .single();

        if (createError) throw createError;
        playerId = newPlayer.id;
      }

      // Submit gamemode scores with correct point calculation
      for (const gt of validTiers) {
        const points = calculatePoints(gt.tier);
        const { error: scoreError } = await supabase
          .from('gamemode_scores')
          .upsert({
            player_id: playerId,
            gamemode: gt.gamemode as "Crystal" | "Sword" | "Mace" | "Axe" | "SMP" | "UHC" | "NethPot" | "Bedwars",
            internal_tier: gt.tier as any,
            display_tier: gt.tier as any,
            points,
            updated_at: new Date().toISOString()
          });

        if (scoreError) throw scoreError;
      }

      // Reset form
      setForm({
        ign: '',
        java_username: '',
        region: '',
        device: '',
        gamemode_tiers: [{ gamemode: '', tier: '' }]
      });

      toast({
        title: "Submission Successful",
        description: `Results submitted for ${form.ign} in ${validTiers.length} gamemode(s)`,
      });
    } catch (error: any) {
      toast({
        title: "Submission Failed",
        description: error.message,
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Card className="bg-gray-900/40 backdrop-blur-xl border-gray-700/50">
      <CardHeader>
        <CardTitle className="text-white flex items-center space-x-2">
          <Trophy className="h-5 w-5 text-green-400" />
          <span>Multi-Gamemode Result Submission</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Basic Player Info */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label className="text-gray-300 font-medium">IGN (Required) *</Label>
            <Input
              value={form.ign}
              onChange={(e) => setForm({ ...form, ign: e.target.value })}
              placeholder="Enter player IGN"
              className="bg-gray-800/60 border-gray-600/50 text-white"
              required
            />
          </div>
          <div className="space-y-2">
            <Label className="text-gray-300 font-medium">Java Username</Label>
            <Input
              value={form.java_username}
              onChange={(e) => setForm({ ...form, java_username: e.target.value })}
              placeholder="Enter Java username (optional)"
              className="bg-gray-800/60 border-gray-600/50 text-white"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label className="text-gray-300 font-medium">Region (Required) *</Label>
            <Select value={form.region} onValueChange={(value) => setForm({ ...form, region: value })} required>
              <SelectTrigger className="bg-gray-800/60 border-gray-600/50 text-white">
                <SelectValue placeholder="Select region" />
              </SelectTrigger>
              <SelectContent className="bg-gray-800 border-gray-600">
                {regions.map(region => (
                  <SelectItem key={region} value={region}>{region}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label className="text-gray-300 font-medium">Device (Required) *</Label>
            <Select value={form.device} onValueChange={(value) => setForm({ ...form, device: value })} required>
              <SelectTrigger className="bg-gray-800/60 border-gray-600/50 text-white">
                <SelectValue placeholder="Select device" />
              </SelectTrigger>
              <SelectContent className="bg-gray-800 border-gray-600">
                {devices.map(device => (
                  <SelectItem key={device} value={device}>{device}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Gamemode Tiers */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <Label className="text-gray-300 font-medium text-lg">Gamemode Tiers</Label>
            <Button
              onClick={addGamemodeTier}
              size="sm"
              className="bg-blue-600/20 border border-blue-500/50 text-blue-400 hover:bg-blue-600/30"
            >
              <Plus className="h-4 w-4 mr-1" />
              Add Tier
            </Button>
          </div>

          {form.gamemode_tiers.map((gt, index) => (
            <div key={index} className="flex items-end space-x-3 p-3 bg-gray-800/40 rounded-lg border border-gray-700/40">
              <div className="flex-1 space-y-2">
                <Label className="text-gray-400 text-sm">Gamemode</Label>
                <Select 
                  value={gt.gamemode} 
                  onValueChange={(value) => updateGamemodeTier(index, 'gamemode', value)}
                >
                  <SelectTrigger className="bg-gray-700/60 border-gray-600/50 text-white">
                    <SelectValue placeholder="Select gamemode" />
                  </SelectTrigger>
                  <SelectContent className="bg-gray-800 border-gray-600">
                    {gamemodes.map(gamemode => (
                      <SelectItem key={gamemode} value={gamemode}>{gamemode}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="flex-1 space-y-2">
                <Label className="text-gray-400 text-sm">Tier</Label>
                <Select 
                  value={gt.tier} 
                  onValueChange={(value) => updateGamemodeTier(index, 'tier', value)}
                >
                  <SelectTrigger className="bg-gray-700/60 border-gray-600/50 text-white">
                    <SelectValue placeholder="Select tier" />
                  </SelectTrigger>
                  <SelectContent className="bg-gray-800 border-gray-600">
                    {tiers.map(tier => (
                      <SelectItem key={tier} value={tier}>
                        {tier} ({calculatePoints(tier)} pts)
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {form.gamemode_tiers.length > 1 && (
                <Button
                  onClick={() => removeGamemodeTier(index)}
                  size="sm"
                  variant="outline"
                  className="border-red-500/50 text-red-400 hover:bg-red-600/20"
                >
                  <X className="h-4 w-4" />
                </Button>
              )}
            </div>
          ))}
        </div>

        <Button
          onClick={handleSubmit}
          disabled={isSubmitting}
          className="w-full bg-green-600/20 border border-green-500/50 text-green-400 hover:bg-green-600/30 hover:border-green-400/60"
        >
          <Send className="h-4 w-4 mr-2" />
          {isSubmitting ? 'Submitting...' : 'Submit Results'}
        </Button>
      </CardContent>
    </Card>
  );
};
