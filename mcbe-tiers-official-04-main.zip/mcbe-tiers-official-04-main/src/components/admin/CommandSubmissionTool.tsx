
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { newAdminService } from '@/services/newAdminService';
import { supabase } from '@/integrations/supabase/client';
import { 
  Terminal, 
  Play, 
  CheckCircle, 
  XCircle,
  AlertCircle,
  Code
} from 'lucide-react';

interface CommandSubmissionToolProps {
  userRole: string;
}

interface ParsedCommand {
  type: 'update' | 'register';
  ign: string;
  javaUsername: string;
  device: string;
  region: string;
  gamemodeAndTier?: string;
}

const CommandSubmissionTool: React.FC<CommandSubmissionToolProps> = ({ userRole }) => {
  const [commands, setCommands] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [results, setResults] = useState<{
    processed: number;
    successful: number;
    failed: number;
    errors: string[];
    successMessages: string[];
  } | null>(null);
  const { toast } = useToast();

  const canUseMassSubmission = newAdminService.canMassSubmit();

  const parseCommands = (commandText: string) => {
    const lines = commandText.trim().split('\n').filter(line => line.trim());
    const parsedCommands: ParsedCommand[] = [];
    const errors: string[] = [];

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i].trim();
      
      if (line.startsWith('!update') || line.startsWith('!register')) {
        const commandType = line.startsWith('!update') ? 'update' : 'register';
        const commandLines: string[] = [];
        
        // Get the command data lines
        for (let j = i + 1; j < lines.length; j++) {
          const nextLine = lines[j].trim();
          if (nextLine.startsWith('!')) {
            break;
          }
          if (nextLine) {
            commandLines.push(nextLine);
          }
        }
        
        // Validate command structure
        if (commandLines.length < 3) {
          errors.push(`Invalid ${commandType} command at line ${i + 1}: Missing required fields (IGN, Device, Region)`);
          continue;
        }

        const ign = commandLines[0];
        let javaUsername = commandLines[1];
        const device = commandLines[2];
        const region = commandLines[3];
        const gamemodeAndTier = commandLines[4];

        // Default java username if empty
        if (!javaUsername || javaUsername.trim() === '') {
          javaUsername = 'itzrealme';
        }

        // Validate required fields
        if (!ign || !device || !region) {
          errors.push(`Invalid ${commandType} command at line ${i + 1}: IGN, Device, and Region are required`);
          continue;
        }

        // For update commands, gamemode and tier are required
        if (commandType === 'update' && !gamemodeAndTier) {
          errors.push(`Invalid update command at line ${i + 1}: Gamemode and tier are required for updates`);
          continue;
        }

        parsedCommands.push({
          type: commandType,
          ign,
          javaUsername,
          device,
          region,
          gamemodeAndTier
        });
      }
    }

    return { commands: parsedCommands, errors };
  };

  const executeCommand = async (command: ParsedCommand): Promise<{ success: boolean; message: string }> => {
    try {
      if (command.type === 'register') {
        return await executeRegister(command);
      } else {
        return await executeUpdate(command);
      }
    } catch (error: any) {
      return { success: false, message: error.message };
    }
  };

  const executeRegister = async (command: ParsedCommand): Promise<{ success: boolean; message: string }> => {
    // Check if player already exists
    const { data: existingPlayer } = await supabase
      .from('players')
      .select('id')
      .eq('ign', command.ign)
      .single();

    if (existingPlayer) {
      return { success: false, message: `Player ${command.ign} already exists. Use !update instead.` };
    }

    // Map region to correct enum value
    const regionMap: Record<string, string> = {
      'asia': 'AS',
      'ASIA': 'AS',
      'eu': 'EU',
      'na': 'NA',
      'sa': 'SA',
      'af': 'AF',
      'oce': 'OCE'
    };

    const mappedRegion = regionMap[command.region.toLowerCase()] || command.region.toUpperCase();

    // Create new player
    const { error: playerError } = await supabase
      .from('players')
      .insert({
        ign: command.ign,
        java_username: command.javaUsername,
        device: command.device.charAt(0).toUpperCase() + command.device.slice(1).toLowerCase() as "Mobile" | "PC" | "Console",
        region: mappedRegion as "NA" | "EU" | "AS" | "SA" | "AF" | "OCE",
        global_points: 0
      });

    if (playerError) {
      return { success: false, message: `Failed to register ${command.ign}: ${playerError.message}` };
    }

    return { success: true, message: `Successfully registered ${command.ign} as Rookie` };
  };

  const executeUpdate = async (command: ParsedCommand): Promise<{ success: boolean; message: string }> => {
    // Check if player exists
    const { data: existingPlayer, error: fetchError } = await supabase
      .from('players')
      .select('id')
      .eq('ign', command.ign)
      .single();

    if (fetchError || !existingPlayer) {
      return { success: false, message: `Player ${command.ign} not found. Use !register first.` };
    }

    if (!command.gamemodeAndTier) {
      return { success: false, message: `Gamemode and tier required for update command` };
    }

    // Parse gamemode and tier
    const gamemodeAndTier = command.gamemodeAndTier.toLowerCase();
    let gamemode: string;
    let tier: string;

    if (gamemodeAndTier.includes('crystal')) {
      gamemode = 'Crystal';
      tier = gamemodeAndTier.replace('crystal_', '').toUpperCase();
    } else if (gamemodeAndTier.includes('sword')) {
      gamemode = 'Sword';
      tier = gamemodeAndTier.replace('sword_', '').toUpperCase();
    } else if (gamemodeAndTier.includes('bedwars')) {
      gamemode = 'Bedwars';
      tier = gamemodeAndTier.replace('bedwars_', '').toUpperCase();
    } else if (gamemodeAndTier.includes('mace')) {
      gamemode = 'Mace';
      tier = gamemodeAndTier.replace('mace_', '').toUpperCase();
    } else if (gamemodeAndTier.includes('smp')) {
      gamemode = 'SMP';
      tier = gamemodeAndTier.replace('smp_', '').toUpperCase();
    } else if (gamemodeAndTier.includes('uhc')) {
      gamemode = 'UHC';
      tier = gamemodeAndTier.replace('uhc_', '').toUpperCase();
    } else if (gamemodeAndTier.includes('nethpot')) {
      gamemode = 'NethPot';
      tier = gamemodeAndTier.replace('nethpot_', '').toUpperCase();
    } else if (gamemodeAndTier.includes('axe')) {
      gamemode = 'Axe';
      tier = gamemodeAndTier.replace('axe_', '').toUpperCase();
    } else {
      return { success: false, message: `Invalid gamemode in: ${command.gamemodeAndTier}` };
    }

    // Calculate points based on tier
    const tierPoints: Record<string, number> = {
      'HT1': 50, 'LT1': 45, 'HT2': 40, 'LT2': 35, 'HT3': 30, 'LT3': 25,
      'HT4': 20, 'LT4': 15, 'HT5': 10, 'LT5': 5, 'RETIRED': 0
    };

    const points = tierPoints[tier] || 0;

    // Update or insert gamemode score
    const { error: scoreError } = await supabase
      .from('gamemode_scores')
      .upsert({
        player_id: existingPlayer.id,
        gamemode: gamemode as any,
        internal_tier: tier as any,
        display_tier: tier as any,
        points: points,
        score: points
      });

    if (scoreError) {
      return { success: false, message: `Failed to update ${command.ign}: ${scoreError.message}` };
    }

    return { success: true, message: `Successfully updated ${command.ign} to ${gamemode} ${tier}` };
  };

  const handleExecute = async () => {
    if (!commands.trim()) {
      toast({
        title: "Validation Error",
        description: "Please enter commands to execute",
        variant: "destructive"
      });
      return;
    }

    setIsProcessing(true);
    setResults(null);

    try {
      const { commands: parsedCommands, errors } = parseCommands(commands);
      
      if (errors.length > 0 && parsedCommands.length === 0) {
        setResults({
          processed: 0,
          successful: 0,
          failed: errors.length,
          errors,
          successMessages: []
        });
        return;
      }

      const successMessages: string[] = [];
      const executionErrors: string[] = [...errors];

      for (const command of parsedCommands) {
        const result = await executeCommand(command);
        if (result.success) {
          successMessages.push(result.message);
        } else {
          executionErrors.push(result.message);
        }
      }

      setResults({
        processed: parsedCommands.length,
        successful: successMessages.length,
        failed: executionErrors.length,
        errors: executionErrors,
        successMessages
      });

      if (successMessages.length > 0) {
        toast({
          title: "Commands Processed",
          description: `${successMessages.length} commands executed successfully`,
        });
      }

      if (executionErrors.length === 0) {
        setCommands('');
      }
    } catch (error: any) {
      toast({
        title: "Execution Failed",
        description: error.message || "Failed to process commands",
        variant: "destructive"
      });
    } finally {
      setIsProcessing(false);
    }
  };

  if (!canUseMassSubmission) {
    return (
      <div className="text-center text-gray-400 py-8">
        <Terminal className="h-12 w-12 mx-auto mb-4 opacity-50" />
        <p>You don't have permission to use mass submission commands.</p>
        <p className="text-sm mt-2">Current role: {userRole}</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-gradient-to-br from-green-600/20 to-blue-600/20 rounded-lg border border-green-500/30">
            <Terminal className="h-6 w-6 text-green-400" />
          </div>
          <div>
            <h3 className="text-xl font-bold text-white">Command Submission Tool</h3>
            <p className="text-gray-400 text-sm">Execute !update and !register commands</p>
          </div>
        </div>

        <Badge variant="outline" className={
          userRole === 'owner' 
            ? 'border-red-500/50 text-red-400' 
            : 'border-orange-500/50 text-orange-400'
        }>
          {userRole}
        </Badge>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="bg-gray-900/40 backdrop-blur-xl border-gray-700/50">
          <CardHeader>
            <CardTitle className="text-white flex items-center space-x-2">
              <Code className="h-5 w-5" />
              <span>Command Input</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="p-3 bg-gray-800/40 rounded-lg border border-gray-700/30">
              <p className="text-sm text-gray-300 mb-2">Command Format:</p>
              <div className="space-y-2 text-xs text-gray-400">
                <div>
                  <code className="text-green-400">!register</code> - IGN → Java Username → Device → Region
                </div>
                <div>
                  <code className="text-blue-400">!update</code> - IGN → Java Username → Device → Region → Gamemode_Tier
                </div>
                <p className="text-yellow-400 mt-2">Java Username defaults to "itzrealme" if left blank</p>
                <p className="text-purple-400">Gamemodes: crystal, sword, bedwars, mace, smp, uhc, nethpot, axe</p>
                <p className="text-purple-400">Tiers: HT1, LT1, HT2, LT2, HT3, LT3, HT4, LT4, HT5, LT5, RETIRED</p>
              </div>
            </div>

            <Textarea
              value={commands}
              onChange={(e) => setCommands(e.target.value)}
              placeholder={`!register
jamal
itzrealme
mobile
eu

!update
jamal
itzrealme
mobile
eu
crystal_LT4`}
              className="bg-gray-800/50 border-gray-600/50 text-white font-mono min-h-[300px]"
            />

            <Button
              onClick={handleExecute}
              disabled={isProcessing || !commands.trim()}
              className="w-full bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700"
            >
              <Play className="h-4 w-4 mr-2" />
              {isProcessing ? 'Processing...' : 'Execute Commands'}
            </Button>
          </CardContent>
        </Card>

        <Card className="bg-gray-900/40 backdrop-blur-xl border-gray-700/50">
          <CardHeader>
            <CardTitle className="text-white">Execution Results</CardTitle>
          </CardHeader>
          <CardContent>
            {results ? (
              <div className="space-y-4">
                <div className="grid grid-cols-3 gap-4">
                  <div className="text-center p-3 bg-blue-600/10 border border-blue-500/30 rounded-lg">
                    <div className="text-2xl font-bold text-blue-400">{results.processed}</div>
                    <div className="text-sm text-gray-400">Processed</div>
                  </div>
                  <div className="text-center p-3 bg-green-600/10 border border-green-500/30 rounded-lg">
                    <div className="text-2xl font-bold text-green-400">{results.successful}</div>
                    <div className="text-sm text-gray-400">Successful</div>
                  </div>
                  <div className="text-center p-3 bg-red-600/10 border border-red-500/30 rounded-lg">
                    <div className="text-2xl font-bold text-red-400">{results.failed}</div>
                    <div className="text-sm text-gray-400">Failed</div>
                  </div>
                </div>

                {results.successMessages.length > 0 && (
                  <div className="p-3 bg-green-600/10 border border-green-500/30 rounded-lg">
                    <div className="flex items-center space-x-2 mb-2">
                      <CheckCircle className="h-4 w-4 text-green-400" />
                      <span className="text-sm font-medium text-green-400">Successful Operations</span>
                    </div>
                    <div className="space-y-1">
                      {results.successMessages.map((message, index) => (
                        <div key={index} className="text-sm text-green-300">{message}</div>
                      ))}
                    </div>
                  </div>
                )}

                {results.errors.length > 0 && (
                  <div className="p-3 bg-red-600/10 border border-red-500/30 rounded-lg">
                    <div className="flex items-center space-x-2 mb-2">
                      <AlertCircle className="h-4 w-4 text-red-400" />
                      <span className="text-sm font-medium text-red-400">Errors</span>
                    </div>
                    <div className="space-y-1">
                      {results.errors.map((error, index) => (
                        <div key={index} className="text-sm text-red-300">{error}</div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="text-center text-gray-400 py-8">
                <Terminal className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p>Execute commands to see results</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default CommandSubmissionTool;
