
import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { Trash2, Plus } from 'lucide-react';
import { Database } from '@/integrations/supabase/types';

type RegionType = Database['public']['Enums']['region_type'];
type DeviceType = Database['public']['Enums']['device_type'];
type GamemodeType = Database['public']['Enums']['gamemode_type'];
type TierLevel = Database['public']['Enums']['tier_level'];

interface Player {
  id: string;
  ign: string;
  java_username?: string;
  uuid?: string;
  region?: RegionType;
  device?: DeviceType;
  global_points: number;
  overall_rank?: number;
  banned: boolean;
  ban_reason?: string;
  gamemode_scores?: Array<{
    id: string;
    gamemode: GamemodeType;
    internal_tier: TierLevel;
    points: number;
  }>;
}

interface ModernUserEditFormProps {
  player: Player;
  isOpen: boolean;
  onClose: () => void;
  onSave: () => void;
}

const TIER_OPTIONS: TierLevel[] = [
  'LT5',
  'HT5',
  'LT4',
  'HT4',
  'LT3',
  'HT3',
  'LT2',
  'HT2',
  'LT1',
  'HT1',
  'RLT1',
  'RHT1',
  'RLT2',
  'RHT2'
];

const REGION_OPTIONS: { value: RegionType; label: string }[] = [
  { value: 'AS', label: 'Asia' },
  { value: 'EU', label: 'Europe' },
  { value: 'NA', label: 'North America' }
];

const DEVICE_OPTIONS: { value: DeviceType; label: string }[] = [
  { value: 'Mobile', label: 'Mobile' },
  { value: 'Console', label: 'Controller' },
  { value: 'PC', label: 'Keyboard & Mouse' }
];

const GAMEMODE_OPTIONS: GamemodeType[] = ['Crystal', 'Sword', 'Axe', 'UHC', 'Mace', 'SMP', 'Bedwars', 'NethPot'];

export const ModernUserEditForm: React.FC<ModernUserEditFormProps> = ({
  player,
  isOpen,
  onClose,
  onSave
}) => {
  const [formData, setFormData] = useState({
    ign: player.ign || '',
    java_username: player.java_username || '',
    region: player.region || '' as RegionType,
    device: player.device || '' as DeviceType,
    banned: player.banned || false
  });

  const [gamemodeScores, setGamemodeScores] = useState(player.gamemode_scores || []);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    setFormData({
      ign: player.ign || '',
      java_username: player.java_username || '',
      region: player.region || '' as RegionType,
      device: player.device || '' as DeviceType,
      banned: player.banned || false
    });
    setGamemodeScores(player.gamemode_scores || []);
  }, [player]);

  const handleAddGamemode = () => {
    const newGamemode = {
      id: `temp-${Date.now()}`,
      gamemode: '' as GamemodeType,
      internal_tier: '' as TierLevel,
      points: 0
    };
    setGamemodeScores([...gamemodeScores, newGamemode]);
  };

  const handleRemoveGamemode = (index: number) => {
    const updated = gamemodeScores.filter((_, i) => i !== index);
    setGamemodeScores(updated);
  };

  const handleGamemodeChange = (index: number, field: string, value: string) => {
    const updated = [...gamemodeScores];
    updated[index] = { ...updated[index], [field]: value };
    setGamemodeScores(updated);
  };

  const handleSave = async () => {
    setIsLoading(true);
    try {
      // Update player basic info
      const { error: playerError } = await supabase
        .from('players')
        .update({
          ign: formData.ign,
          java_username: formData.java_username,
          region: formData.region,
          device: formData.device,
          banned: formData.banned,
          updated_at: new Date().toISOString()
        })
        .eq('id', player.id);

      if (playerError) throw playerError;

      // Handle gamemode scores updates
      for (const score of gamemodeScores) {
        if (score.gamemode && score.internal_tier) {
          if (score.id.startsWith('temp-')) {
            // Insert new gamemode score
            const { error } = await supabase
              .from('gamemode_scores')
              .insert({
                player_id: player.id,
                gamemode: score.gamemode as GamemodeType,
                internal_tier: score.internal_tier as TierLevel,
                display_tier: score.internal_tier as TierLevel,
                points: score.points || 0
              });
            if (error) throw error;
          } else {
            // Update existing gamemode score
            const { error } = await supabase
              .from('gamemode_scores')
              .update({
                gamemode: score.gamemode as GamemodeType,
                internal_tier: score.internal_tier as TierLevel,
                display_tier: score.internal_tier as TierLevel,
                points: score.points || 0,
                updated_at: new Date().toISOString()
              })
              .eq('id', score.id);
            if (error) throw error;
          }
        }
      }

      toast({
        title: "Player Updated",
        description: `${formData.ign} has been updated successfully.`,
      });

      onSave();
      onClose();
    } catch (error: any) {
      toast({
        title: "Update Failed",
        description: `Failed to update player: ${error.message}`,
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-gray-900 border-gray-700 max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-white">Edit Player: {player.ign}</DialogTitle>
          <p className="text-gray-400 text-sm">Update player information and ban status</p>
        </DialogHeader>

        <div className="space-y-6 mt-4">
          {/* Basic Player Info */}
          <div className="space-y-4">
            <div className="space-y-2">
              <Label className="text-gray-300">Player IGN *</Label>
              <Input
                value={formData.ign}
                onChange={(e) => setFormData({ ...formData, ign: e.target.value })}
                className="bg-gray-800/60 border-gray-600/50 text-white"
                placeholder=".Zestycpvp"
              />
            </div>

            <div className="space-y-2">
              <Label className="text-gray-300">Java Username (Optional)</Label>
              <div className="relative">
                <Input
                  value={formData.java_username}
                  onChange={(e) => setFormData({ ...formData, java_username: e.target.value })}
                  className="bg-gray-800/60 border-gray-600/50 text-white pl-8"
                  placeholder="Enter Java IGN"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label className="text-gray-300">UUID (Read-only)</Label>
              <Input
                value={player.uuid || 'N/A'}
                readOnly
                className="bg-gray-700/30 border-gray-600/30 text-gray-400 cursor-not-allowed"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="text-gray-300">Region *</Label>
                <Select value={formData.region} onValueChange={(value) => setFormData({ ...formData, region: value as RegionType })}>
                  <SelectTrigger className="bg-gray-800/60 border-gray-600/50 text-white">
                    <SelectValue placeholder="Select region" />
                  </SelectTrigger>
                  <SelectContent className="bg-gray-800 border-gray-600">
                    {REGION_OPTIONS.map(region => (
                      <SelectItem key={region.value} value={region.value}>{region.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label className="text-gray-300">Device *</Label>
                <Select value={formData.device} onValueChange={(value) => setFormData({ ...formData, device: value as DeviceType })}>
                  <SelectTrigger className="bg-gray-800/60 border-gray-600/50 text-white">
                    <SelectValue placeholder="Select device" />
                  </SelectTrigger>
                  <SelectContent className="bg-gray-800 border-gray-600">
                    {DEVICE_OPTIONS.map(device => (
                      <SelectItem key={device.value} value={device.value}>{device.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          {/* Ban Status */}
          <div className="p-4 bg-gray-800/30 rounded-lg border border-gray-700/40">
            <div className="flex items-center justify-between">
              <div>
                <Label className="text-gray-300 flex items-center space-x-2">
                  <span>Ban Status</span>
                </Label>
                <p className="text-sm text-gray-400 mt-1">
                  {formData.banned ? 'Player is currently banned' : 'Player is active'}
                </p>
              </div>
              <Switch
                checked={formData.banned}
                onCheckedChange={(checked) => setFormData({ ...formData, banned: checked })}
              />
            </div>
          </div>

          {/* Gamemode Tiers */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-white font-medium">Gamemode Tiers</h3>
              <Button
                onClick={handleAddGamemode}
                size="sm"
                className="bg-green-600/20 border border-green-500/50 text-green-400 hover:bg-green-600/30"
              >
                <Plus className="h-4 w-4 mr-1" />
                Add Gamemode
              </Button>
            </div>

            <div className="space-y-3">
              {gamemodeScores.map((score, index) => (
                <div key={score.id} className="grid grid-cols-3 gap-3 p-3 bg-gray-800/40 rounded-lg border border-gray-700/40">
                  <Select
                    value={score.gamemode}
                    onValueChange={(value) => handleGamemodeChange(index, 'gamemode', value)}
                  >
                    <SelectTrigger className="bg-gray-800/60 border-gray-600/50 text-white">
                      <SelectValue placeholder="Select gamemode" />
                    </SelectTrigger>
                    <SelectContent className="bg-gray-800 border-gray-600">
                      {GAMEMODE_OPTIONS.map(gamemode => (
                        <SelectItem key={gamemode} value={gamemode}>{gamemode}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>

                  <Select
                    value={score.internal_tier}
                    onValueChange={(value) => handleGamemodeChange(index, 'internal_tier', value)}
                  >
                    <SelectTrigger className="bg-gray-800/60 border-gray-600/50 text-white">
                      <SelectValue placeholder="Select tier" />
                    </SelectTrigger>
                    <SelectContent className="bg-gray-800 border-gray-600">
                      {TIER_OPTIONS.map(tier => (
                        <SelectItem key={tier} value={tier}>{tier}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>

                  <Button
                    onClick={() => handleRemoveGamemode(index)}
                    size="sm"
                    className="bg-red-600/20 border border-red-500/50 text-red-400 hover:bg-red-600/30"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              ))}

              {gamemodeScores.length === 0 && (
                <div className="text-center text-gray-400 py-6">
                  No gamemode tiers assigned. Click "Add Gamemode" to get started.
                </div>
              )}
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex space-x-3 pt-4 border-t border-gray-700/50">
            <Button
              onClick={handleSave}
              disabled={isLoading}
              className="flex-1 bg-green-600/20 border border-green-500/50 text-green-400 hover:bg-green-600/30"
            >
              {isLoading ? 'Saving...' : 'Save Changes'}
            </Button>
            <Button
              onClick={onClose}
              variant="outline"
              className="flex-1 border-gray-600/50 text-gray-300 hover:bg-gray-800/60"
            >
              Cancel
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};
