import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { Shield, Lock, UserPlus, CheckCircle } from 'lucide-react';
import { newAdminService, clearAllAuthState } from '@/services/newAdminService';
import { StaffOnboardingModal } from './StaffOnboardingModal';
import { staffOnboardingService } from '@/services/staffOnboardingService';

interface NewAdminAuthProps {
  onAuthSuccess: (role: string) => void;
}

export const NewAdminAuth: React.FC<NewAdminAuthProps> = ({ onAuthSuccess }) => {
  const [step, setStep] = useState<'login' | 'onboarding' | 'staff-onboarding' | 'pending' | 'owner-username' | 'staff-onboarding-complete'>('login');
  const [password, setPassword] = useState('');
  const [ownerUsername, setOwnerUsername] = useState('');
  const [onboardingData, setOnboardingData] = useState({
    discord: '',
    requestedRole: '',
    secretKey: '',
    applicationStatement: ''
  });
  const [isLoading, setIsLoading] = useState(false);
  const [showStaffOnboarding, setShowStaffOnboarding] = useState(false);
  const [pendingRole, setPendingRole] = useState<string>('');
  const { toast } = useToast();

  useEffect(() => {
    const checkExistingBinding = async () => {
      const binding = await staffOnboardingService.checkExistingBinding();
      if (binding && staffOnboardingService.isOnboardingComplete()) {
        localStorage.setItem('admin_role', binding.staff_role);
        localStorage.setItem('admin_session_active', 'true');
        localStorage.setItem('staff_username', binding.custom_username);
        onAuthSuccess(binding.staff_role);
      }
    };

    checkExistingBinding();
  }, [onAuthSuccess]);

  const handlePasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!password.trim()) {
      return;
    }

    setIsLoading(true);
    try {
      clearAllAuthState();

      console.log('🔐 Attempting authentication with password:', password.substring(0, 5) + '...');
      const result = await newAdminService.authenticateAdmin(password);
      console.log('🔍 Authentication result:', result);

      if (result.success) {
        if (result.needsOnboarding) {
          console.log('✅ Staff password accepted - routing to onboarding');
          toast({
            title: "Staff Password Accepted",
            description: "Please complete your application form",
            variant: "default"
          });
          setStep('onboarding');
        } else if (result.role) {
          // Owner login - check if username is set
          const existingUsername = localStorage.getItem('owner_username');
          if (result.role === 'owner' && !existingUsername) {
            setStep('owner-username');
          } else {
            // Check if staff onboarding is needed
            if (result.role === 'owner' && staffOnboardingService.needsOnboarding('owner')) {
              setPendingRole('owner');
              setShowStaffOnboarding(true);
              setIsLoading(false);
              return;
            } else if (result.role === 'admin' && staffOnboardingService.needsOnboarding('admin')) {
              setPendingRole('admin');
              setShowStaffOnboarding(true);
              setIsLoading(false);
              return;
            } else {
              toast({
                title: "Access Granted",
                description: `Welcome back, ${result.role}!`,
              });
              onAuthSuccess(result.role);
              setTimeout(() => {
                window.location.reload();
              }, 120);
              return;
            }
          }
        }
      } else {
        console.log('❌ Authentication failed:', result.error);
        toast({
          title: "Authentication Failed",
          description: result.error || "Invalid password. Please check your password and try again.",
          variant: "destructive"
        });
      }
    } catch (error) {
      console.error('❌ Unexpected authentication error:', error);
      toast({
        title: "Error",
        description: "An unexpected error occurred during authentication",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleOwnerUsernameSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!ownerUsername.trim()) {
      toast({
        title: "Username Required",
        description: "Please enter a username",
        variant: "destructive"
      });
      return;
    }

    setIsLoading(true);
    try {
      // Store owner username
      localStorage.setItem('owner_username', ownerUsername);
      localStorage.setItem('admin_role', 'owner');
      localStorage.setItem('admin_session_active', 'true');
      
      // Complete staff onboarding for owner
      await staffOnboardingService.completeOnboarding(ownerUsername, 'owner');
      
      toast({
        title: "Welcome Owner",
        description: `Username set successfully: ${ownerUsername}`,
      });

      onAuthSuccess('owner');
      setTimeout(() => {
        window.location.reload();
      }, 120);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to set username",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleOnboardingSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!onboardingData.discord || !onboardingData.requestedRole || !onboardingData.secretKey || !onboardingData.applicationStatement) {
      toast({
        title: "Missing Fields",
        description: "Please fill in all required fields",
        variant: "destructive"
      });
      return;
    }
    
    setIsLoading(true);
    try {
      const result = await newAdminService.submitOnboardingApplication(onboardingData);
      if (result.success) {
        setStep('pending');
        toast({
          title: "Application Submitted",
          description: "Your application has been submitted for review",
        });
      } else {
        toast({
          title: "Submission Failed",
          description: result.error || "Failed to submit application",
          variant: "destructive"
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "An unexpected error occurred",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleStaffOnboardingComplete = (username: string) => {
    localStorage.setItem('admin_role', pendingRole);
    localStorage.setItem('admin_session_active', 'true');
    localStorage.setItem('staff_username', username);
    setShowStaffOnboarding(false);
    onAuthSuccess(pendingRole);
  };

  const handleKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && !isLoading) {
      if (step === 'owner-username') {
        handleOwnerUsernameSubmit(e as any);
      } else {
        handlePasswordSubmit(e as any);
      }
    }
  };

  if (step === 'owner-username') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-[#0a0b14] via-[#0f111a] to-[#1a1b2a] flex items-center justify-center p-3 md:p-4">
        <Card className="w-full max-w-sm md:max-w-md bg-gray-900/40 backdrop-blur-xl border-gray-700/50 shadow-2xl">
          <CardHeader className="text-center space-y-2 md:space-y-3 pb-3 md:pb-4">
            <div className="flex justify-center">
              <div className="p-2 md:p-3 bg-gradient-to-br from-yellow-600 to-orange-600 rounded-full">
                <UserPlus className="h-5 w-5 md:h-6 md:w-6 lg:h-8 lg:w-8 text-white" />
              </div>
            </div>
            <CardTitle className="text-base md:text-lg lg:text-2xl font-bold bg-gradient-to-r from-white via-yellow-200 to-orange-200 bg-clip-text text-transparent">
              Set Owner Username
            </CardTitle>
            <CardDescription className="text-gray-400 text-xs md:text-sm">
              Please set your username to complete the setup
            </CardDescription>
          </CardHeader>
          
          <CardContent className="pt-0 space-y-3 md:space-y-4">
            <form onSubmit={handleOwnerUsernameSubmit} className="space-y-3 md:space-y-4">
              <div className="space-y-2">
                <label htmlFor="username" className="text-xs md:text-sm font-medium text-gray-300">
                  Username
                </label>
                <Input
                  id="username"
                  type="text"
                  value={ownerUsername}
                  onChange={(e) => setOwnerUsername(e.target.value)}
                  onKeyDown={handleKeyPress}
                  placeholder="Enter your username"
                  className="bg-gray-800/50 border-gray-600/50 text-white placeholder:text-gray-500 h-9 md:h-10 text-sm"
                  disabled={isLoading}
                  autoComplete="off"
                />
              </div>
              <Button 
                type="submit" 
                className="w-full bg-gradient-to-r from-yellow-600 to-orange-600 hover:from-yellow-700 hover:to-orange-700 text-white font-medium py-2 md:py-2.5 px-3 md:px-4 rounded-lg transition-all duration-300 h-9 md:h-10 text-sm"
                disabled={isLoading}
              >
                {isLoading ? 'Setting...' : 'Set Username'}
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (step === 'pending') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-[#0a0b14] via-[#0f111a] to-[#1a1b2a] flex items-center justify-center p-3 md:p-4">
        <Card className="w-full max-w-xs md:max-w-sm bg-gray-900/40 backdrop-blur-xl border-gray-700/50 shadow-2xl">
          <CardHeader className="text-center space-y-2 md:space-y-3 pb-3 md:pb-4">
            <div className="flex justify-center">
              <div className="p-2 md:p-3 bg-gradient-to-br from-green-600 to-blue-600 rounded-full">
                <CheckCircle className="h-5 w-5 md:h-6 md:w-6 lg:h-8 lg:w-8 text-white" />
              </div>
            </div>
            <CardTitle className="text-base md:text-lg lg:text-2xl font-bold bg-gradient-to-r from-white via-green-200 to-blue-200 bg-clip-text text-transparent">
              Application Submitted
            </CardTitle>
            <CardDescription className="text-gray-400 text-xs md:text-sm">
              Your application has been submitted successfully. You'll get access if approved by the owner.
            </CardDescription>
          </CardHeader>
          
          <CardContent className="pt-0">
            <Button 
              onClick={() => window.location.reload()}
              className="w-full bg-gradient-to-r from-gray-600 to-gray-700 hover:from-gray-700 hover:to-gray-800 text-white font-medium py-2 md:py-2.5 px-3 md:px-4 rounded-lg transition-all duration-300 text-sm"
            >
              Check Status
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (step === 'onboarding') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-[#0a0b14] via-[#0f111a] to-[#1a1b2a] flex items-center justify-center p-3 md:p-4">
        <Card className="w-full max-w-sm md:max-w-md bg-gray-900/40 backdrop-blur-xl border-gray-700/50 shadow-2xl">
          <CardHeader className="text-center space-y-2 md:space-y-3 pb-3 md:pb-4">
            <div className="flex justify-center">
              <div className="p-2 md:p-3 bg-gradient-to-br from-purple-600 to-blue-600 rounded-full">
                <UserPlus className="h-5 w-5 md:h-6 md:w-6 lg:h-8 lg:w-8 text-white" />
              </div>
            </div>
            <CardTitle className="text-base md:text-lg lg:text-2xl font-bold bg-gradient-to-r from-white via-purple-200 to-blue-200 bg-clip-text text-transparent">
              Staff Application Form
            </CardTitle>
            <CardDescription className="text-gray-400 text-xs md:text-sm">
              ✅ Staff password accepted! Complete your application below.
            </CardDescription>
          </CardHeader>
          
          <CardContent className="pt-0 space-y-3 md:space-y-4">
            <form onSubmit={handleOnboardingSubmit} className="space-y-3 md:space-y-4">
              <div className="space-y-2">
                <label className="text-xs md:text-sm font-medium text-gray-300">
                  Which role are you applying for?
                </label>
                <Select value={onboardingData.requestedRole} onValueChange={(value) => 
                  setOnboardingData(prev => ({ ...prev, requestedRole: value }))
                }>
                  <SelectTrigger className="bg-gray-800/50 border-gray-600/50 text-white h-9 md:h-10 text-sm">
                    <SelectValue placeholder="Select a role" />
                  </SelectTrigger>
                  <SelectContent className="bg-gray-800 border-gray-600 z-50">
                    <SelectItem value="admin">Admin</SelectItem>
                    <SelectItem value="moderator">Moderator</SelectItem>
                    <SelectItem value="tester">Tester</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <label className="text-xs md:text-sm font-medium text-gray-300">
                  Discord username
                </label>
                <Input
                  type="text"
                  value={onboardingData.discord}
                  onChange={(e) => setOnboardingData(prev => ({ ...prev, discord: e.target.value }))}
                  placeholder="your_discord_username"
                  className="bg-gray-800/50 border-gray-600/50 text-white placeholder:text-gray-500 h-9 md:h-10 text-sm"
                  disabled={isLoading}
                />
              </div>

              <div className="space-y-2">
                <label className="text-xs md:text-sm font-medium text-gray-300">
                  Secret key from owner
                </label>
                <Input
                  type="password"
                  value={onboardingData.secretKey}
                  onChange={(e) => setOnboardingData(prev => ({ ...prev, secretKey: e.target.value }))}
                  placeholder="Secret key"
                  className="bg-gray-800/50 border-gray-600/50 text-white placeholder:text-gray-500 h-9 md:h-10 text-sm"
                  disabled={isLoading}
                />
              </div>

              <div className="space-y-2">
                <label className="text-xs md:text-sm font-medium text-gray-300">
                  Application statement
                </label>
                <Input
                  type="text"
                  value={onboardingData.applicationStatement}
                  onChange={(e) => setOnboardingData(prev => ({ ...prev, applicationStatement: e.target.value }))}
                  placeholder="Why do you want this role?"
                  className="bg-gray-800/50 border-gray-600/50 text-white placeholder:text-gray-500 h-9 md:h-10 text-sm"
                  disabled={isLoading}
                />
              </div>
              
              <Button 
                type="submit" 
                className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white font-medium py-2 md:py-2.5 px-3 md:px-4 rounded-lg transition-all duration-300 h-9 md:h-10 text-sm"
                disabled={isLoading}
              >
                {isLoading ? 'Submitting...' : 'Submit Application'}
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (step === 'staff-onboarding-complete') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-[#0a0b14] via-[#0f111a] to-[#1a1b2a] flex items-center justify-center p-3 md:p-4">
        <Card className="w-full max-w-xs md:max-w-sm bg-gray-900/40 backdrop-blur-xl border-gray-700/50 shadow-2xl">
          <CardHeader className="text-center space-y-2 md:space-y-3 pb-3 md:pb-4">
            <div className="flex justify-center">
              <div className="p-2 md:p-3 bg-gradient-to-br from-green-600 to-blue-600 rounded-full">
                <CheckCircle className="h-5 w-5 md:h-6 md:w-6 lg:h-8 lg:w-8 text-white" />
              </div>
            </div>
            <CardTitle className="text-base md:text-lg lg:text-2xl font-bold bg-gradient-to-r from-white via-green-200 to-blue-200 bg-clip-text text-transparent">
              Application Submitted
            </CardTitle>
            <CardDescription className="text-gray-400 text-xs md:text-sm">
              Your application has been submitted successfully. You'll get access if approved by the owner.
            </CardDescription>
          </CardHeader>
          
          <CardContent className="pt-0">
            <Button 
              onClick={() => window.location.reload()}
              className="w-full bg-gradient-to-r from-gray-600 to-gray-700 hover:from-gray-700 hover:to-gray-800 text-white font-medium py-2 md:py-2.5 px-3 md:px-4 rounded-lg transition-all duration-300 text-sm"
            >
              Check Status
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <>
      <div className="min-h-screen bg-gradient-to-br from-[#0a0b14] via-[#0f111a] to-[#1a1b2a] flex items-center justify-center p-3 md:p-4">
        <Card className="w-full max-w-sm md:max-w-md bg-gray-900/40 backdrop-blur-xl border-gray-700/50 shadow-2xl">
          <CardHeader className="text-center space-y-2 md:space-y-3 pb-3 md:pb-4">
            <div className="flex justify-center">
              <div className="p-2 md:p-3 bg-gradient-to-br from-purple-600 to-blue-600 rounded-full">
                <Shield className="h-5 w-5 md:h-6 md:w-6 lg:h-8 lg:w-8 text-white" />
              </div>
            </div>
            <CardTitle className="text-base md:text-lg lg:text-2xl font-bold bg-gradient-to-r from-white via-purple-200 to-blue-200 bg-clip-text text-transparent">
              Admin Access
            </CardTitle>
            <CardDescription className="text-gray-400 text-xs md:text-sm">
              Enter your admin password to access the dashboard
            </CardDescription>
          </CardHeader>
          
          <CardContent className="pt-0 space-y-3 md:space-y-4">
            <form onSubmit={handlePasswordSubmit} className="space-y-3 md:space-y-4">
              <div className="space-y-2">
                <label htmlFor="password" className="text-xs md:text-sm font-medium text-gray-300">
                  Admin Password
                </label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 h-3 w-3 md:h-4 md:w-4 text-gray-400" />
                  <Input
                    id="password"
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    onKeyDown={handleKeyPress}
                    placeholder="Enter admin password"
                    className="pl-8 md:pl-10 bg-gray-800/50 border-gray-600/50 text-white placeholder:text-gray-500 focus:border-purple-500/50 focus:ring-purple-500/25 h-9 md:h-10 text-sm"
                    disabled={isLoading}
                    autoComplete="off"
                  />
                </div>
              </div>
              <Button 
                type="submit" 
                className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white font-medium py-2 md:py-2.5 px-3 md:px-4 rounded-lg transition-all duration-300 h-9 md:h-10 text-sm"
                disabled={isLoading}
              >
                {isLoading ? 'Authenticating...' : 'Access Admin Panel'}
              </Button>
            </form>
            
            <div className="text-center pt-2 border-t border-gray-700/50">
              <p className="text-xs text-gray-500">
                💡 Try staff password: $$Mcbetlstaff20$$
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      <StaffOnboardingModal
        isOpen={showStaffOnboarding}
        staffRole={pendingRole}
        onComplete={handleStaffOnboardingComplete}
        onClose={() => setShowStaffOnboarding(false)}
      />
    </>
  );
};
