
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { mcbeAdminService, AdminApplication } from '@/services/mcbeAdminService';
import { 
  Users, 
  CheckCircle, 
  XCircle, 
  Clock,
  MessageSquare,
  Shield
} from 'lucide-react';

const StaffApplicationsManager = () => {
  const [applications, setApplications] = useState<AdminApplication[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const fetchApplications = async () => {
    setIsLoading(true);
    try {
      const data = await mcbeAdminService.getPendingApplications();
      setApplications(data);
    } catch (error) {
      toast({
        title: "Fetch Failed",
        description: "Failed to fetch applications",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchApplications();
  }, []);

  const handleReviewApplication = async (
    applicationId: string, 
    action: 'approve' | 'reject',
    assignedRole?: 'admin' | 'publisher'
  ) => {
    setIsLoading(true);
    try {
      const result = await mcbeAdminService.reviewApplication(applicationId, action, assignedRole);
      
      if (result.success) {
        toast({
          title: action === 'approve' ? "Application Approved" : "Application Rejected",
          description: `Application has been ${action}d successfully.`,
        });
        await fetchApplications();
      } else {
        toast({
          title: "Review Failed",
          description: result.error || `Failed to ${action} application`,
          variant: "destructive"
        });
      }
    } catch (error: any) {
      toast({
        title: "Review Error",
        description: error.message || "An unexpected error occurred",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const ApplicationCard = ({ application }: { application: AdminApplication }) => {
    const [selectedRole, setSelectedRole] = useState<'admin' | 'publisher'>(application.requested_role);

    return (
      <div className="group p-4 bg-gray-800/40 rounded-lg border border-gray-700/40 hover:border-gray-600/50 transition-all duration-300 hover:bg-gray-800/60">
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-to-br from-blue-500/20 to-purple-500/20 border border-blue-500/30 rounded-full flex items-center justify-center">
              <Users className="h-5 w-5 text-blue-400" />
            </div>
            <div>
              <p className="text-white font-medium">{application.discord}</p>
              <div className="flex items-center space-x-2 mt-1">
                <Badge variant="outline" className={
                  application.requested_role === 'admin' 
                    ? 'border-orange-500/50 text-orange-400' 
                    : 'border-blue-500/50 text-blue-400'
                }>
                  {application.requested_role}
                </Badge>
                <div className="flex items-center space-x-1 text-xs text-gray-400">
                  <Clock className="h-3 w-3" />
                  <span>{new Date(application.submitted_at).toLocaleDateString()}</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {application.application_statement && (
          <div className="mb-4 p-3 bg-gray-900/40 rounded-lg border border-gray-700/30">
            <div className="flex items-center space-x-2 mb-2">
              <MessageSquare className="h-4 w-4 text-gray-400" />
              <span className="text-sm text-gray-400">Application Statement</span>
            </div>
            <p className="text-sm text-gray-300">{application.application_statement}</p>
          </div>
        )}

        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <span className="text-sm text-gray-400">Assign Role:</span>
            <Select value={selectedRole} onValueChange={(value: 'admin' | 'publisher') => setSelectedRole(value)}>
              <SelectTrigger className="w-32 h-8 bg-gray-800 border-gray-600 text-white text-sm">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-gray-800 border-gray-600">
                <SelectItem value="admin" className="text-white">Admin</SelectItem>
                <SelectItem value="publisher" className="text-white">Publisher</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-center space-x-2">
            <Button
              onClick={() => handleReviewApplication(application.id, 'approve', selectedRole)}
              disabled={isLoading}
              className="bg-green-600/20 border border-green-500/50 text-green-400 hover:bg-green-600/30 transition-all duration-200"
              size="sm"
            >
              <CheckCircle className="h-3 w-3 mr-1" />
              Approve
            </Button>
            
            <Button
              onClick={() => handleReviewApplication(application.id, 'reject')}
              disabled={isLoading}
              className="bg-red-600/20 border border-red-500/50 text-red-400 hover:bg-red-600/30 transition-all duration-200"
              size="sm"
            >
              <XCircle className="h-3 w-3 mr-1" />
              Reject
            </Button>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-gradient-to-br from-blue-600/20 to-purple-600/20 rounded-lg border border-blue-500/30">
            <Shield className="h-6 w-6 text-blue-400" />
          </div>
          <div>
            <h3 className="text-xl font-bold text-white">Staff Applications</h3>
            <p className="text-gray-400 text-sm">Review and approve staff applications</p>
          </div>
        </div>

        <Button
          onClick={fetchApplications}
          disabled={isLoading}
          className="bg-blue-600/20 border border-blue-500/50 text-blue-400 hover:bg-blue-600/30"
        >
          Refresh
        </Button>
      </div>

      <Card className="bg-gray-900/40 backdrop-blur-xl border-gray-700/50">
        <CardHeader>
          <CardTitle className="text-white">Pending Applications ({applications.length})</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="text-center text-gray-400 py-8">Loading applications...</div>
          ) : applications.length === 0 ? (
            <div className="text-center text-gray-400 py-8">No pending applications.</div>
          ) : (
            <div className="space-y-4">
              {applications.map((application) => (
                <ApplicationCard key={application.id} application={application} />
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default StaffApplicationsManager;
