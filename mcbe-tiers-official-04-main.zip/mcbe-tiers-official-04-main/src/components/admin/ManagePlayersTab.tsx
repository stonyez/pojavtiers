
import React, { useEffect } from 'react';
import { usePlayerManagement } from '@/hooks/usePlayerManagement';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { MoreVertical, Edit, Trash2, Ban, UserX, CheckCircle } from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { GameMode } from '@/services/playerService';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { ScrollArea } from "@/components/ui/scroll-area"
import { cn } from "@/lib/utils"

interface Player {
  id: string;
  ign: string;
  global_points: number;
  overall_rank: number;
  avatar_url?: string;
  java_username?: string;
  gamemode_scores: {
    gamemode: string;
    internal_tier: string;
    score: number;
  }[];
  banned: boolean;
  created_at: string;
  updated_at: string;
}

export const ManagePlayersTab = () => {
  const {
    players,
    isLoading,
    error,
    updatePlayerTier,
    refreshPlayers,
    deletePlayer,
    banPlayer
  } = usePlayerManagement();

  useEffect(() => {
    refreshPlayers();
  }, [refreshPlayers]);

  const handleUpdateTier = async (playerId: string, gamemode: string, tier: string, score: number) => {
    const result = await updatePlayerTier(playerId, gamemode as any, tier as any, score);
    if (result.success) {
      // Handle success
    } else {
      console.error('Update failed:', result.error);
    }
  };

  const handleDeletePlayer = async (playerId: string) => {
    await deletePlayer(playerId);
  };

  const handleBanPlayer = async (playerId: string, banned: boolean) => {
    await banPlayer(playerId, banned);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Manage Players</CardTitle>
        <CardDescription>
          Here you can manage existing players, update their tiers, and
          ban/unban them.
        </CardDescription>
      </CardHeader>
      <CardContent className="overflow-auto">
        {isLoading ? (
          <div>Loading players...</div>
        ) : error ? (
          <div>Error: {error}</div>
        ) : (
          <ScrollArea>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>IGN</TableHead>
                  <TableHead>Global Points</TableHead>
                  <TableHead>Overall Rank</TableHead>
                  <TableHead>Banned</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {players.map((player: Player) => (
                  <TableRow key={player.id}>
                    <TableCell>
                      <div className="flex items-center space-x-2">
                        <img
                          src={player.avatar_url}
                          alt={player.ign}
                          className="w-8 h-8 rounded-full"
                        />
                        <span>{player.ign}</span>
                      </div>
                    </TableCell>
                    <TableCell>{player.global_points}</TableCell>
                    <TableCell>{player.overall_rank}</TableCell>
                    <TableCell>
                      {player.banned ? (
                        <Badge variant="destructive">Banned</Badge>
                      ) : (
                        <Badge variant="outline">Active</Badge>
                      )}
                    </TableCell>
                    <TableCell>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" className="h-8 w-8 p-0">
                            <span className="sr-only">Open menu</span>
                            <MoreVertical className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuLabel>Actions</DropdownMenuLabel>
                          <DropdownMenuItem>
                            <Edit className="h-4 w-4 mr-2" /> Update Tier
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <Trash2 className="h-4 w-4 mr-2" /> Delete Player
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem>
                            {player.banned ? (
                              <UserX className="h-4 w-4 mr-2" />
                            ) : (
                              <Ban className="h-4 w-4 mr-2" />
                            )}
                            {player.banned ? 'Unban' : 'Ban'}
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </ScrollArea>
        )}
      </CardContent>
    </Card>
  );
};

export default ManagePlayersTab;
