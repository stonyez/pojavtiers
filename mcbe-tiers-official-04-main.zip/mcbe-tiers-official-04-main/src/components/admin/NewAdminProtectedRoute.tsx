
import React, { useState, useEffect } from 'react';
import { NewAdminAuth } from './NewAdminAuth';
import { newAdminService } from '@/services/newAdminService';

interface NewAdminProtectedRouteProps {
  children: (userRole: string) => React.ReactNode;
}

export const NewAdminProtectedRoute: React.FC<NewAdminProtectedRouteProps> = ({ children }) => {
  const [userRole, setUserRole] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const checkAccess = async () => {
      try {
        console.log('NewAdminProtectedRoute: Checking access...');
        
        // Check localStorage first to avoid infinite loops
        const storedRole = localStorage.getItem('admin_role');
        const sessionActive = localStorage.getItem('admin_session_active');
        
        if (sessionActive === 'true' && storedRole) {
          console.log('Found valid session in localStorage:', storedRole);
          setUserRole(storedRole);
          setIsLoading(false);
          return;
        }
        
        // Fallback to service check
        const result = await newAdminService.checkAdminAccess();
        console.log('Access check result:', result);
        
        if (result.hasAccess && result.role) {
          console.log('Setting user role:', result.role);
          setUserRole(result.role);
          localStorage.setItem('admin_role', result.role);
          localStorage.setItem('admin_session_active', 'true');
        } else {
          console.log('No access found');
          setUserRole(null);
        }
      } catch (error) {
        console.error('Access check error:', error);
        setUserRole(null);
      } finally {
        setIsLoading(false);
      }
    };

    checkAccess();
  }, []);

  const handleAuthSuccess = (role: string) => {
    console.log('Auth success with role:', role);
    setUserRole(role);
    localStorage.setItem('admin_role', role);
    localStorage.setItem('admin_session_active', 'true');
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-[#0a0b14] via-[#0f111a] to-[#1a1b2a] flex items-center justify-center">
        <div className="text-white text-lg">Verifying access...</div>
      </div>
    );
  }

  if (!userRole) {
    return <NewAdminAuth onAuthSuccess={handleAuthSuccess} />;
  }

  console.log('NewAdminProtectedRoute: Rendering with role:', userRole);
  return <>{children(userRole)}</>;
};
