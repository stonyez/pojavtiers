
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { mcbeAdminService, LockboxTask } from '@/services/mcbeAdminService';
import { 
  Lock, 
  CheckCircle, 
  XCircle, 
  Clock,
  User,
  Settings
} from 'lucide-react';

const LockboxManager = () => {
  const [tasks, setTasks] = useState<LockboxTask[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const fetchTasks = async () => {
    setIsLoading(true);
    try {
      const data = await mcbeAdminService.getLockboxTasks();
      setTasks(data);
    } catch (error) {
      toast({
        title: "Fetch Failed",
        description: "Failed to fetch lockbox tasks",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchTasks();
  }, []);

  const handleReviewTask = async (taskId: string, action: 'approve' | 'reject') => {
    setIsLoading(true);
    try {
      const result = await mcbeAdminService.reviewLockboxTask(taskId, action);
      
      if (result.success) {
        toast({
          title: action === 'approve' ? "Task Approved" : "Task Rejected",
          description: `Task has been ${action}d successfully.`,
        });
        await fetchTasks();
      } else {
        toast({
          title: "Review Failed",
          description: result.error || `Failed to ${action} task`,
          variant: "destructive"
        });
      }
    } catch (error: any) {
      toast({
        title: "Review Error",
        description: error.message || "An unexpected error occurred",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleAcceptAll = async () => {
    if (tasks.length === 0) return;
    
    setIsLoading(true);
    try {
      const results = await Promise.all(
        tasks.map(task => mcbeAdminService.reviewLockboxTask(task.id, 'approve'))
      );
      
      const successful = results.filter(r => r.success).length;
      
      toast({
        title: "Batch Approval Complete",
        description: `${successful} of ${tasks.length} tasks approved successfully.`,
      });
      
      await fetchTasks();
    } catch (error: any) {
      toast({
        title: "Batch Approval Error",
        description: error.message || "An unexpected error occurred",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const getTaskTypeIcon = (taskType: string) => {
    switch (taskType) {
      case 'result_submission':
        return <Settings className="h-4 w-4" />;
      case 'mass_submission':
        return <User className="h-4 w-4" />;
      case 'player_update':
        return <User className="h-4 w-4" />;
      default:
        return <Settings className="h-4 w-4" />;
    }
  };

  const getTaskTypeColor = (taskType: string) => {
    switch (taskType) {
      case 'result_submission':
        return 'border-blue-500/50 text-blue-400';
      case 'mass_submission':
        return 'border-purple-500/50 text-purple-400';
      case 'player_update':
        return 'border-green-500/50 text-green-400';
      default:
        return 'border-gray-500/50 text-gray-400';
    }
  };

  const TaskCard = ({ task }: { task: LockboxTask }) => (
    <div className="group p-4 bg-gray-800/40 rounded-lg border border-gray-700/40 hover:border-gray-600/50 transition-all duration-300 hover:bg-gray-800/60">
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-gradient-to-br from-purple-500/20 to-blue-500/20 border border-purple-500/30 rounded-full flex items-center justify-center">
            {getTaskTypeIcon(task.task_type)}
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <Badge variant="outline" className={getTaskTypeColor(task.task_type)}>
                {task.task_type.replace('_', ' ')}
              </Badge>
              <span className="text-sm text-gray-400">by {task.submitter_role}</span>
            </div>
            <div className="flex items-center space-x-1 text-xs text-gray-400 mt-1">
              <Clock className="h-3 w-3" />
              <span>{new Date(task.submitted_at).toLocaleString()}</span>
            </div>
          </div>
        </div>
      </div>

      <div className="mb-4 p-3 bg-gray-900/40 rounded-lg border border-gray-700/30">
        <pre className="text-sm text-gray-300 whitespace-pre-wrap overflow-x-auto">
          {JSON.stringify(task.task_data, null, 2)}
        </pre>
      </div>

      <div className="flex items-center justify-end space-x-2">
        <Button
          onClick={() => handleReviewTask(task.id, 'approve')}
          disabled={isLoading}
          className="bg-green-600/20 border border-green-500/50 text-green-400 hover:bg-green-600/30 transition-all duration-200"
          size="sm"
        >
          <CheckCircle className="h-3 w-3 mr-1" />
          Approve
        </Button>
        
        <Button
          onClick={() => handleReviewTask(task.id, 'reject')}
          disabled={isLoading}
          className="bg-red-600/20 border border-red-500/50 text-red-400 hover:bg-red-600/30 transition-all duration-200"
          size="sm"
        >
          <XCircle className="h-3 w-3 mr-1" />
          Reject
        </Button>
      </div>
    </div>
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-gradient-to-br from-purple-600/20 to-blue-600/20 rounded-lg border border-purple-500/30">
            <Lock className="h-6 w-6 text-purple-400" />
          </div>
          <div>
            <h3 className="text-xl font-bold text-white">Lockbox - Task Approval</h3>
            <p className="text-gray-400 text-sm">Review and approve pending tasks</p>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          {tasks.length > 0 && (
            <Button
              onClick={handleAcceptAll}
              disabled={isLoading}
              className="bg-green-600/20 border border-green-500/50 text-green-400 hover:bg-green-600/30"
            >
              Accept All ({tasks.length})
            </Button>
          )}
          
          <Button
            onClick={fetchTasks}
            disabled={isLoading}
            className="bg-blue-600/20 border border-blue-500/50 text-blue-400 hover:bg-blue-600/30"
          >
            Refresh
          </Button>
        </div>
      </div>

      <Card className="bg-gray-900/40 backdrop-blur-xl border-gray-700/50">
        <CardHeader>
          <CardTitle className="text-white">Pending Tasks ({tasks.length})</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="text-center text-gray-400 py-8">Loading tasks...</div>
          ) : tasks.length === 0 ? (
            <div className="text-center text-gray-400 py-8">No pending tasks.</div>
          ) : (
            <div className="space-y-4">
              {tasks.map((task) => (
                <TaskCard key={task.id} task={task} />
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default LockboxManager;
