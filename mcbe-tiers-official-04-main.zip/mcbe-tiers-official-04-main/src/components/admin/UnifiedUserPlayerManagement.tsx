
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';
import { ManagePlayersTab } from './ManagePlayersTab';
import MassSubmissionForm from './MassSubmissionForm';
import { ModernUserEditForm } from './ModernUserEditForm';
import { authService } from '@/services/authService';
import { 
  Users, 
  Search, 
  Trash2, 
  Shield, 
  ShieldOff, 
  User,
  Crown,
  Edit,
  FileSpreadsheet,
  Database,
  Download,
  RefreshCw,
  UserCheck,
  UserX,
  Clock
} from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import type { Database as DatabaseType } from '@/integrations/supabase/types';

type RegionType = DatabaseType['public']['Enums']['region_type'];
type DeviceType = DatabaseType['public']['Enums']['device_type'];
type GamemodeType = DatabaseType['public']['Enums']['gamemode_type'];
type TierLevel = DatabaseType['public']['Enums']['tier_level'];

interface Player {
  id: string;
  ign: string;
  java_username?: string;
  uuid?: string;
  avatar_url?: string;
  region?: RegionType;
  device?: DeviceType;
  global_points: number;
  overall_rank?: number;
  banned: boolean;
  ban_reason?: string;
  created_at: string;
  updated_at: string;
  gamemode_scores?: Array<{
    id: string;
    gamemode: GamemodeType;
    internal_tier: TierLevel;
    points: number;
  }>;
}

interface StaffMember {
  id: string;
  username: string;
  role: string;
  is_active: boolean;
  last_login: string | null;
  created_at: string;
}

interface UnifiedUserPlayerManagementProps {
  mode?: 'management' | 'mass-submission' | 'database';
}

const UnifiedUserPlayerManagement: React.FC<UnifiedUserPlayerManagementProps> = ({ 
  mode = 'management' 
}) => {
  const [players, setPlayers] = useState<Player[]>([]);
  const [staffMembers, setStaffMembers] = useState<StaffMember[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [selectedPlayer, setSelectedPlayer] = useState<Player | null>(null);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isBanModalOpen, setIsBanModalOpen] = useState(false);
  const [banReason, setBanReason] = useState('');
  const [playerToBan, setPlayerToBan] = useState<Player | null>(null);
  const { toast } = useToast();

  const fetchPlayers = async () => {
    setIsLoading(true);
    try {
      const { data, error } = await supabase
        .from('players')
        .select(`
          *,
          gamemode_scores (
            id,
            gamemode,
            internal_tier,
            points
          )
        `)
        .order('overall_rank', { ascending: true });

      if (error) throw error;
      setPlayers(data || []);
    } catch (error: any) {
      toast({
        title: "Fetch Failed",
        description: `Failed to fetch players: ${error.message}`,
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const fetchStaffMembers = async () => {
    try {
      const { data, error } = await supabase
        .from('staff')
        .select('id, username, role, is_active, last_login, created_at')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setStaffMembers(data || []);
    } catch (error: any) {
      console.error('Failed to fetch staff members:', error);
    }
  };

  const handleEditPlayer = (player: Player) => {
    console.log('Edit player clicked:', player);
    setSelectedPlayer(player);
    setIsEditModalOpen(true);
  };

  const handleBanPlayer = (player: Player) => {
    setPlayerToBan(player);
    setBanReason(player.ban_reason || '');
    setIsBanModalOpen(true);
  };

  const submitBan = async () => {
    if (!playerToBan) return;

    setIsLoading(true);
    try {
      const { error } = await supabase
        .from('players')
        .update({ 
          banned: !playerToBan.banned,
          ban_reason: !playerToBan.banned ? banReason : null
        })
        .eq('id', playerToBan.id);

      if (error) throw error;

      await fetchPlayers();
      toast({
        title: playerToBan.banned ? "Player Unbanned" : "Player Banned",
        description: `${playerToBan.ign} has been ${playerToBan.banned ? 'unbanned' : 'banned'}.`,
      });
      
      setIsBanModalOpen(false);
      setPlayerToBan(null);
      setBanReason('');
    } catch (error: any) {
      toast({
        title: "Ban Toggle Failed",
        description: `Failed to ${playerToBan.banned ? 'unban' : 'ban'} player: ${error.message}`,
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const deletePlayer = async (playerId: string, playerName: string) => {
    if (!authService.isOwner()) {
      toast({
        title: "Access Denied",
        description: "Only Owner can delete players",
        variant: "destructive"
      });
      return;
    }

    if (!confirm(`Are you sure you want to permanently delete ${playerName}? This action cannot be undone.`)) {
      return;
    }

    setIsLoading(true);
    try {
      const { error } = await supabase
        .from('players')
        .delete()
        .eq('id', playerId);

      if (error) throw error;

      await fetchPlayers();
      toast({
        title: "Player Deleted",
        description: `${playerName} has been permanently deleted.`,
      });
    } catch (error: any) {
      toast({
        title: "Delete Failed",
        description: `Failed to delete player: ${error.message}`,
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const exportToCSV = async () => {
    try {
      const csv = [
        ['IGN', 'Java Username', 'UUID', 'Region', 'Device', 'Global Points', 'Rank', 'Banned', 'Ban Reason', 'Created At'].join(','),
        ...players.map(player => [
          player.ign,
          player.java_username || '',
          player.uuid || '',
          player.region || '',
          player.device || '',
          player.global_points,
          player.overall_rank || '',
          player.banned ? 'Yes' : 'No',
          player.ban_reason || '',
          new Date(player.created_at).toLocaleDateString()
        ].join(','))
      ].join('\n');

      const blob = new Blob([csv], { type: 'text/csv' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `players_export_${new Date().toISOString().split('T')[0]}.csv`;
      a.click();
      window.URL.revokeObjectURL(url);

      toast({
        title: "Export Successful",
        description: "Player data has been exported to CSV",
      });
    } catch (error: any) {
      toast({
        title: "Export Failed",
        description: error.message,
        variant: "destructive"
      });
    }
  };

  useEffect(() => {
    fetchPlayers();
    fetchStaffMembers();
  }, []);

  const filteredPlayers = players.filter(player =>
    player.ign?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const activeStaff = staffMembers.filter(staff => staff.is_active);
  const offlineStaff = staffMembers.filter(staff => !staff.is_active);

  const PlayerCard = ({ player, showRank = true }: { player: Player; showRank?: boolean }) => (
    <div className="group flex items-center justify-between p-3 bg-gray-800/40 rounded-lg border border-gray-700/40 hover:border-gray-600/50 transition-all duration-300 hover:bg-gray-800/60">
      <div className="flex items-center space-x-3 flex-1 min-w-0">
        <div className="relative">
          {player.avatar_url ? (
            <img 
              src={player.avatar_url} 
              alt={player.ign}
              className="w-8 h-8 rounded-full border border-blue-500/30"
            />
          ) : (
            <div className="w-8 h-8 bg-gradient-to-br from-blue-500/20 to-purple-500/20 border border-blue-500/30 rounded-full flex items-center justify-center flex-shrink-0">
              {player.overall_rank && player.overall_rank <= 3 ? (
                <Crown className="h-4 w-4 text-yellow-400" />
              ) : (
                <User className="h-4 w-4 text-blue-400" />
              )}
            </div>
          )}
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-white font-medium truncate text-sm">
            {player.ign || 'Unknown Player'}
          </p>
          <div className="flex items-center space-x-2 text-xs text-gray-400">
            {showRank && <span>#{player.overall_rank || 'Unranked'}</span>}
            {showRank && <span>•</span>}
            <span>{player.global_points || 0} pts</span>
            {player.banned && (
              <>
                <span>•</span>
                <span className="text-red-400 font-medium">BANNED</span>
              </>
            )}
          </div>
        </div>
      </div>
      
      <div className="flex items-center space-x-1 flex-shrink-0">
        <Button
          onClick={() => handleEditPlayer(player)}
          disabled={isLoading}
          className="bg-blue-600/20 border border-blue-500/50 text-blue-400 hover:bg-blue-600/30 transition-all duration-200"
          size="sm"
        >
          <Edit className="h-3 w-3" />
        </Button>
        
        {(authService.hasPermission('canManageStaff') || authService.isOwner()) && (
          <Button
            onClick={() => handleBanPlayer(player)}
            disabled={isLoading}
            className={`${
              player.banned
                ? 'bg-green-600/20 border border-green-500/50 text-green-400 hover:bg-green-600/30'
                : 'bg-yellow-600/20 border border-yellow-500/50 text-yellow-400 hover:bg-yellow-600/30'
            } transition-all duration-200`}
            size="sm"
          >
            {player.banned ? (
              <Shield className="h-3 w-3" />
            ) : (
              <ShieldOff className="h-3 w-3" />
            )}
          </Button>
        )}
        
        {authService.isOwner() && (
          <Button
            onClick={() => deletePlayer(player.id, player.ign)}
            disabled={isLoading}
            className="bg-red-600/20 border border-red-500/50 text-red-400 hover:bg-red-600/30 transition-all duration-200"
            size="sm"
          >
            <Trash2 className="h-3 w-3" />
          </Button>
        )}
      </div>
    </div>
  );

  const renderModeContent = () => {
    switch (mode) {
      case 'mass-submission':
        return (
          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <div className="p-1 bg-yellow-600/20 rounded border border-yellow-500/50">
                <FileSpreadsheet className="h-4 w-4 text-yellow-400" />
              </div>
              <h4 className="text-white font-medium">Bulk Result Submission</h4>
              <span className="text-xs bg-red-600/20 text-red-400 px-2 py-1 rounded border border-red-500/50">
                Admin & Owner Only
              </span>
            </div>
            <MassSubmissionForm />
          </div>
        );

      case 'database':
        return (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <div className="p-1 bg-purple-600/20 rounded border border-purple-500/50">
                  <Database className="h-4 w-4 text-purple-400" />
                </div>
                <h4 className="text-white font-medium">Player Database & Staff Overview</h4>
              </div>
              <div className="flex items-center space-x-2">
                <Button
                  onClick={exportToCSV}
                  disabled={isLoading}
                  size="sm"
                  className="bg-green-600/20 border border-green-500/50 text-green-400 hover:bg-green-600/30"
                >
                  <Download className="h-4 w-4 mr-1" />
                  Export CSV
                </Button>
                <Button
                  onClick={() => {
                    fetchPlayers();
                    fetchStaffMembers();
                  }}
                  disabled={isLoading}
                  size="sm"
                  className="bg-blue-600/20 border border-blue-500/50 text-blue-400 hover:bg-blue-600/30"
                >
                  <RefreshCw className="h-4 w-4 mr-1" />
                  Refresh
                </Button>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-4">
              <div className="bg-gray-800/30 p-3 rounded-lg border border-gray-700/40">
                <p className="text-gray-400 text-sm">Total Players</p>
                <p className="text-white text-xl font-bold">{players.length}</p>
              </div>
              <div className="bg-gray-800/30 p-3 rounded-lg border border-gray-700/40">
                <p className="text-gray-400 text-sm">Banned Players</p>
                <p className="text-red-400 text-xl font-bold">{players.filter(p => p.banned).length}</p>
              </div>
              <div className="bg-gray-800/30 p-3 rounded-lg border border-gray-700/40">
                <p className="text-gray-400 text-sm">Active Players</p>
                <p className="text-green-400 text-xl font-bold">{players.filter(p => !p.banned).length}</p>
              </div>
              <div className="bg-gray-800/30 p-3 rounded-lg border border-gray-700/40">
                <p className="text-gray-400 text-sm">Top Player Points</p>
                <p className="text-blue-400 text-xl font-bold">{Math.max(...players.map(p => p.global_points), 0)}</p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
              <div className="bg-gray-800/30 p-3 rounded-lg border border-gray-700/40">
                <div className="flex items-center space-x-2 mb-2">
                  <UserCheck className="h-4 w-4 text-green-400" />
                  <p className="text-gray-400 text-sm">Active Staff</p>
                </div>
                <p className="text-green-400 text-xl font-bold">{activeStaff.length}</p>
              </div>
              <div className="bg-gray-800/30 p-3 rounded-lg border border-gray-700/40">
                <div className="flex items-center space-x-2 mb-2">
                  <UserX className="h-4 w-4 text-red-400" />
                  <p className="text-gray-400 text-sm">Offline Staff</p>
                </div>
                <p className="text-red-400 text-xl font-bold">{offlineStaff.length}</p>
              </div>
              <div className="bg-gray-800/30 p-3 rounded-lg border border-gray-700/40">
                <div className="flex items-center space-x-2 mb-2">
                  <Users className="h-4 w-4 text-blue-400" />
                  <p className="text-gray-400 text-sm">Total Staff</p>
                </div>
                <p className="text-blue-400 text-xl font-bold">{staffMembers.length}</p>
              </div>
            </div>

            <div className="flex items-center space-x-2 mb-4">
              <Input
                placeholder="Search players..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-64 bg-gray-800/50 border-gray-600/50 text-white text-sm"
              />
            </div>

            {isLoading ? (
              <div className="text-center text-gray-400 py-6">Loading players...</div>
            ) : filteredPlayers.length === 0 ? (
              <div className="text-center text-gray-400 py-6">No players found.</div>
            ) : (
              <div className="space-y-2 max-h-96 overflow-y-auto">
                {filteredPlayers.map((player) => (
                  <PlayerCard key={player.id} player={player} />
                ))}
              </div>
            )}
          </div>
        );

      default: // management
        return (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h4 className="text-white font-medium">Edit & Update Player Results</h4>
              <div className="flex items-center space-x-2">
                <Input
                  placeholder="Search players..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-48 bg-gray-800/50 border-gray-600/50 text-white text-sm"
                />
                <Button
                  onClick={fetchPlayers}
                  disabled={isLoading}
                  size="sm"
                  className="bg-blue-600/20 border border-blue-500/50 text-blue-400 hover:bg-blue-600/30"
                >
                  <Search className="h-4 w-4" />
                </Button>
              </div>
            </div>

            {isLoading ? (
              <div className="text-center text-gray-400 py-6">Loading players...</div>
            ) : filteredPlayers.length === 0 ? (
              <div className="text-center text-gray-400 py-6">No players found.</div>
            ) : (
              <div className="space-y-2 max-h-96 overflow-y-auto">
                {filteredPlayers.map((player) => (
                  <PlayerCard key={player.id} player={player} />
                ))}
              </div>
            )}
          </div>
        );
    }
  };

  return (
    <div className="space-y-4">
      <Card className="bg-gray-900/40 backdrop-blur-xl border-gray-700/50">
        <CardHeader className="pb-3">
          <CardTitle className="text-white text-lg flex items-center space-x-2">
            <Users className="h-5 w-5" />
            <span>
              {mode === 'mass-submission' && 'Mass Submission Console'}
              {mode === 'database' && 'Player Database Console'}
              {mode === 'management' && 'Player Management Console'}
            </span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          {renderModeContent()}
        </CardContent>
      </Card>

      {/* Modern User Edit Modal */}
      {selectedPlayer && (
        <ModernUserEditForm
          player={selectedPlayer}
          isOpen={isEditModalOpen}
          onClose={() => {
            setIsEditModalOpen(false);
            setSelectedPlayer(null);
          }}
          onSave={() => {
            fetchPlayers();
          }}
        />
      )}

      {/* Ban/Unban Modal */}
      <Dialog open={isBanModalOpen} onOpenChange={setIsBanModalOpen}>
        <DialogContent className="bg-gray-900 border-gray-700">
          <DialogHeader>
            <DialogTitle className="text-white">
              {playerToBan?.banned ? 'Unban Player' : 'Ban Player'}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <p className="text-gray-300">
              {playerToBan?.banned 
                ? `Are you sure you want to unban ${playerToBan.ign}?`
                : `Are you sure you want to ban ${playerToBan?.ign}?`
              }
            </p>
            {!playerToBan?.banned && (
              <div className="space-y-2">
                <Label htmlFor="banReason" className="text-gray-300">Ban Reason (Optional)</Label>
                <Textarea
                  id="banReason"
                  value={banReason}
                  onChange={(e) => setBanReason(e.target.value)}
                  placeholder="Enter reason for ban..."
                  className="bg-gray-800/60 border-gray-600/50 text-white"
                />
              </div>
            )}
            <div className="flex space-x-3">
              <Button
                onClick={submitBan}
                disabled={isLoading}
                className={`${
                  playerToBan?.banned
                    ? 'bg-green-600/20 border border-green-500/50 text-green-400 hover:bg-green-600/30'
                    : 'bg-red-600/20 border border-red-500/50 text-red-400 hover:bg-red-600/30'
                }`}
              >
                {playerToBan?.banned ? 'Unban Player' : 'Ban Player'}
              </Button>
              <Button
                onClick={() => setIsBanModalOpen(false)}
                variant="outline"
                className="border-gray-600/50 text-gray-300 hover:bg-gray-800/60"
              >
                Cancel
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default UnifiedUserPlayerManagement;
