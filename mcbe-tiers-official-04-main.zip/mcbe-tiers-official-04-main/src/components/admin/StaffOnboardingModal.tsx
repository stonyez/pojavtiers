
import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { User, Shield } from 'lucide-react';
import { staffOnboardingService } from '@/services/staffOnboardingService';

interface StaffOnboardingModalProps {
  isOpen: boolean;
  staffRole: string;
  onComplete: (username: string) => void;
  onClose: () => void;
}

export const StaffOnboardingModal: React.FC<StaffOnboardingModalProps> = ({
  isOpen,
  staffRole,
  onComplete,
  onClose
}) => {
  const [username, setUsername] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!username.trim()) {
      toast({
        title: "Error",
        description: "Please enter a username",
        variant: "destructive"
      });
      return;
    }

    setIsLoading(true);
    
    try {
      const result = await staffOnboardingService.createDeviceBinding({
        customUsername: username,
        staffRole
      });

      if (result.success) {
        const formattedUsername = staffOnboardingService.formatStaffUsername(username);
        toast({
          title: "Onboarding Complete",
          description: "Your device has been registered successfully",
        });
        onComplete(formattedUsername);
      } else {
        toast({
          title: "Error",
          description: result.error || "Failed to complete onboarding",
          variant: "destructive"
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "An unexpected error occurred",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const getRoleIcon = (role: string) => {
    switch (role.toLowerCase()) {
      case 'owner': return <Shield className="h-5 w-5 text-red-400" />;
      case 'admin': return <Shield className="h-5 w-5 text-purple-400" />;
      case 'moderator': return <Shield className="h-5 w-5 text-blue-400" />;
      default: return <User className="h-5 w-5 text-muted-foreground" />;
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            {getRoleIcon(staffRole)}
            <span>Staff Onboarding</span>
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          <div className="bg-muted/50 rounded-lg p-4">
            <h4 className="font-medium mb-2">Welcome to MCBE-Tiers Admin!</h4>
            <p className="text-sm text-muted-foreground">
              You're being granted <strong className="capitalize">{staffRole}</strong> access. 
              Please choose a username that will identify you in the admin panel.
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="username">Choose Your Username</Label>
              <Input
                id="username"
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="e.g., Blitz"
                disabled={isLoading}
              />
              <p className="text-sm text-muted-foreground">
                Your display name will be: <strong>{username}#MCBETIERS.com</strong>
              </p>
            </div>
            
            <div className="flex justify-end space-x-2">
              <Button type="button" variant="outline" onClick={onClose} disabled={isLoading}>
                Cancel
              </Button>
              <Button type="submit" disabled={isLoading}>
                {isLoading ? 'Setting up...' : 'Complete Setup'}
              </Button>
            </div>
          </form>
        </div>
      </DialogContent>
    </Dialog>
  );
};
