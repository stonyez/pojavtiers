
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { staffAuthService } from '@/services/staffAuthService';
import { supabase } from '@/integrations/supabase/client';
import { staffLoggingService } from '@/services/staffLoggingService';
import { staffOnboardingService } from '@/services/staffOnboardingService';
import { 
  Users, 
  Search, 
  Trash2, 
  Ban,
  CheckCircle,
  Filter,
  RefreshCw,
  UserX
} from 'lucide-react';

interface Player {
  id: string;
  ign: string;
  java_username?: string;
  uuid?: string;
  region?: 'AF' | 'AS' | 'OCE' | 'NA' | 'SA' | 'EU';
  device?: 'PC' | 'Console' | 'Mobile';
  global_points: number;
  overall_rank?: number;
  banned: boolean;
  ban_reason?: string;
  created_at: string;
  updated_at: string;
  gamemode_scores?: Array<{
    gamemode: string;
    internal_tier: string;
    points: number;
  }>;
}

const EnhancedUserManagement = () => {
  const [players, setPlayers] = useState<Player[]>([]);
  const [filteredPlayers, setFilteredPlayers] = useState<Player[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterRegion, setFilterRegion] = useState('all');
  const [filterDevice, setFilterDevice] = useState('all');
  const [isLoading, setIsLoading] = useState(false);
  const [isBanModalOpen, setIsBanModalOpen] = useState(false);
  const [banReason, setBanReason] = useState('');
  const [playerToBan, setPlayerToBan] = useState<Player | null>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage] = useState(20);
  const { toast } = useToast();

  const regions: ('AF' | 'AS' | 'OCE' | 'NA' | 'SA' | 'EU')[] = ['AF', 'AS', 'OCE', 'NA', 'SA', 'EU'];
  const devices: ('PC' | 'Console' | 'Mobile')[] = ['PC', 'Console', 'Mobile'];

  const fetchPlayers = async () => {
    if (!staffAuthService.canManageUsers()) {
      toast({
        title: "Access Denied",
        description: "You don't have permission to manage users",
        variant: "destructive"
      });
      return;
    }

    setIsLoading(true);
    try {
      const { data, error } = await supabase
        .from('players')
        .select(`
          *,
          gamemode_scores (
            gamemode,
            internal_tier,
            points
          )
        `)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setPlayers(data || []);
      setFilteredPlayers(data || []);
    } catch (error: any) {
      toast({
        title: "Fetch Failed",
        description: `Failed to fetch players: ${error.message}`,
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchPlayers();
  }, []);

  useEffect(() => {
    let filtered = players;

    if (searchTerm) {
      filtered = filtered.filter(player =>
        player.ign?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        player.java_username?.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    if (filterRegion !== 'all') {
      filtered = filtered.filter(player => player.region === filterRegion);
    }

    if (filterDevice !== 'all') {
      filtered = filtered.filter(player => player.device === filterDevice);
    }

    setFilteredPlayers(filtered);
    setCurrentPage(1);
  }, [players, searchTerm, filterRegion, filterDevice]);

  const handleBanPlayer = async (playerId: string, banned: boolean, reason?: string) => {
    const staffData = staffOnboardingService.getStaffData();
    const currentRole = localStorage.getItem('admin_role');
    
    if (currentRole !== 'owner') {
      toast({
        title: "Access Denied",
        description: "Only Owner can ban/unban users",
        variant: "destructive"
      });
      return;
    }

    setIsLoading(true);
    try {
      const { error } = await supabase
        .from('players')
        .update({ 
          banned, 
          ban_reason: banned ? reason : null,
          updated_at: new Date().toISOString()
        })
        .eq('id', playerId);

      if (error) throw error;

      await fetchPlayers();

      const targetPlayer = players.find(p => p.id === playerId);
      await staffLoggingService.logStaffOperation(
        staffData?.username || 'unknown',
        'admin-panel',
        staffData?.username || 'Staff Member',
        banned ? 'User Banned' : 'User Unbanned',
        {
          target_user: targetPlayer?.ign,
          reason: reason
        }
      );
      
      toast({
        title: banned ? "Player Banned" : "Player Unbanned",
        description: `Player has been ${banned ? 'banned' : 'unbanned'} successfully.`,
      });
    } catch (error: any) {
      toast({
        title: "Ban Action Failed",
        description: `Failed to ${banned ? 'ban' : 'unban'} player: ${error.message}`,
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleDeletePlayer = async (playerId: string, ign: string) => {
    const currentRole = localStorage.getItem('admin_role');
    
    if (currentRole !== 'owner') {
      toast({
        title: "Access Denied",
        description: "Only Owner can delete users",
        variant: "destructive"
      });
      return;
    }

    if (!confirm(`Are you sure you want to delete player ${ign}?`)) {
      return;
    }

    setIsLoading(true);
    try {
      const { error } = await supabase
        .from('players')
        .delete()
        .eq('id', playerId);

      if (error) throw error;

      await fetchPlayers();

      const staffData = staffOnboardingService.getStaffData();
      await staffLoggingService.logStaffOperation(
        staffData?.username || 'unknown',
        'admin-panel',
        staffData?.username || 'Staff Member',
        'User Deleted',
        {
          deleted_user: ign
        }
      );
      
      toast({
        title: "Player Deleted",
        description: `Player ${ign} has been removed from the system.`,
      });
    } catch (error: any) {
      toast({
        title: "Delete Failed",
        description: `Failed to delete player: ${error.message}`,
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const openBanModal = (player: Player) => {
    setPlayerToBan(player);
    setBanReason(player.ban_reason || '');
    setIsBanModalOpen(true);
  };

  const submitBan = async () => {
    if (!playerToBan) return;
    await handleBanPlayer(playerToBan.id, !playerToBan.banned, banReason);
    setIsBanModalOpen(false);
    setPlayerToBan(null);
    setBanReason('');
  };

  const paginatedPlayers = filteredPlayers.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  const totalPages = Math.ceil(filteredPlayers.length / itemsPerPage);

  const PlayerRow = ({ player }: { player: Player }) => (
    <div className="group flex items-center justify-between p-3 bg-gray-800/40 rounded-lg border border-gray-700/40 hover:border-gray-600/50 transition-all duration-300 hover:bg-gray-800/60">
      <div className="flex items-center space-x-3 flex-1 min-w-0">
        <div className="w-8 h-8 bg-gradient-to-br from-green-500/20 to-blue-500/20 border border-green-500/30 rounded-full flex items-center justify-center flex-shrink-0">
          {player.banned ? (
            <Ban className="h-4 w-4 text-red-400" />
          ) : (
            <CheckCircle className="h-4 w-4 text-green-400" />
          )}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center space-x-2">
            <p className="text-white font-medium truncate">{player.ign}</p>
            {player.overall_rank && (
              <span className="px-2 py-1 text-xs bg-blue-600/20 text-blue-400 rounded-full">
                #{player.overall_rank}
              </span>
            )}
            {player.banned && (
              <span className="px-2 py-1 text-xs bg-red-600/20 text-red-400 rounded-full">
                BANNED
              </span>
            )}
          </div>
          <div className="flex items-center space-x-4 text-xs text-gray-400 mt-1">
            <span>Java: {player.java_username || 'N/A'}</span>
            {player.region && <span>Region: {player.region}</span>}
            {player.device && <span>Device: {player.device}</span>}
            <span>Points: {player.global_points}</span>
          </div>
        </div>
      </div>
      
      <div className="flex items-center space-x-1 flex-shrink-0">
        <Button
          onClick={() => openBanModal(player)}
          disabled={isLoading}
          className={`${
            player.banned
              ? 'bg-green-600/20 border border-green-500/50 text-green-400 hover:bg-green-600/30'
              : 'bg-yellow-600/20 border border-yellow-500/50 text-yellow-400 hover:bg-yellow-600/30'
          } transition-all duration-200`}
          size="sm"
        >
          {player.banned ? <CheckCircle className="h-3 w-3" /> : <Ban className="h-3 w-3" />}
        </Button>
        
        <Button
          onClick={() => handleDeletePlayer(player.id, player.ign)}
          disabled={isLoading}
          className="bg-red-600/20 border border-red-500/50 text-red-400 hover:bg-red-600/30 transition-all duration-200"
          size="sm"
        >
          <Trash2 className="h-3 w-3" />
        </Button>
      </div>
    </div>
  );

  if (!staffAuthService.canManageUsers()) {
    return (
      <div className="text-center text-gray-400 py-8">
        <Users className="h-12 w-12 mx-auto mb-4 opacity-50" />
        <p>You don't have permission to manage users.</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-gradient-to-br from-green-600/20 to-blue-600/20 rounded-lg border border-green-500/30">
            <Users className="h-6 w-6 text-green-400" />
          </div>
          <div>
            <h3 className="text-xl font-bold text-white">User Management</h3>
            <p className="text-gray-400 text-sm">Manage player accounts and information</p>
          </div>
        </div>

        <Button onClick={fetchPlayers} disabled={isLoading} className="bg-blue-600/20 border border-blue-500/50 text-blue-400 hover:bg-blue-600/30">
          <RefreshCw className="h-4 w-4 mr-2" />
          Refresh
        </Button>
      </div>

      {/* Filters */}
      <Card className="bg-gray-900/40 backdrop-blur-xl border-gray-700/50">
        <CardContent className="p-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search by IGN..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 bg-gray-800/50 border-gray-600/50 text-white"
              />
            </div>
            <Select value={filterRegion} onValueChange={setFilterRegion}>
              <SelectTrigger className="bg-gray-800/50 border-gray-600/50 text-white">
                <SelectValue placeholder="Filter by region" />
              </SelectTrigger>
              <SelectContent className="bg-gray-800 border-gray-600">
                <SelectItem value="all">All Regions</SelectItem>
                {regions.map(region => (
                  <SelectItem key={region} value={region}>{region}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={filterDevice} onValueChange={setFilterDevice}>
              <SelectTrigger className="bg-gray-800/50 border-gray-600/50 text-white">
                <SelectValue placeholder="Filter by device" />
              </SelectTrigger>
              <SelectContent className="bg-gray-800 border-gray-600">
                <SelectItem value="all">All Devices</SelectItem>
                {devices.map(device => (
                  <SelectItem key={device} value={device}>{device}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <div className="text-sm text-gray-400 flex items-center">
              <Filter className="h-4 w-4 mr-2" />
              {filteredPlayers.length} of {players.length} players
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Players List */}
      <Card className="bg-gray-900/40 backdrop-blur-xl border-gray-700/50">
        <CardHeader>
          <CardTitle className="text-white">Players</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="text-center text-gray-400 py-8">Loading players...</div>
          ) : paginatedPlayers.length === 0 ? (
            <div className="text-center text-gray-400 py-8">No players found.</div>
          ) : (
            <>
              <div className="space-y-2 mb-4">
                {paginatedPlayers.map((player) => (
                  <PlayerRow key={player.id} player={player} />
                ))}
              </div>
              
              {totalPages > 1 && (
                <div className="flex items-center justify-between">
                  <Button
                    onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                    disabled={currentPage === 1}
                    variant="outline"
                    size="sm"
                  >
                    Previous
                  </Button>
                  <span className="text-sm text-gray-400">
                    Page {currentPage} of {totalPages}
                  </span>
                  <Button
                    onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                    disabled={currentPage === totalPages}
                    variant="outline"
                    size="sm"
                  >
                    Next
                  </Button>
                </div>
              )}
            </>
          )}
        </CardContent>
      </Card>

      {/* Ban/Unban Dialog */}
      <Dialog open={isBanModalOpen} onOpenChange={setIsBanModalOpen}>
        <DialogContent className="bg-gray-900 border-gray-700">
          <DialogHeader>
            <DialogTitle className="text-white">
              {playerToBan?.banned ? 'Unban User' : 'Ban User'}: {playerToBan?.ign}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label className="text-white">Reason</Label>
              <Textarea
                value={banReason}
                onChange={(e) => setBanReason(e.target.value)}
                placeholder={playerToBan?.banned ? "Reason for unbanning..." : "Reason for banning..."}
                className="bg-gray-800 border-gray-600 text-white"
              />
            </div>
            <div className="flex space-x-3">
              <Button 
                onClick={submitBan}
                disabled={isLoading} 
                className={`flex-1 ${
                  playerToBan?.banned 
                    ? 'bg-green-600/20 border border-green-500/50 text-green-400 hover:bg-green-600/30'
                    : 'bg-red-600/20 border border-red-500/50 text-red-400 hover:bg-red-600/30'
                }`}
              >
                {isLoading ? 'Processing...' : (playerToBan?.banned ? 'Unban User' : 'Ban User')}
              </Button>
              <Button 
                onClick={() => setIsBanModalOpen(false)}
                variant="outline" 
                className="flex-1 border-gray-600 text-gray-300"
              >
                Cancel
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default EnhancedUserManagement;
