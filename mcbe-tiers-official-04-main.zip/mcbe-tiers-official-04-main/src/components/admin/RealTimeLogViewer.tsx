
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Button } from '@/components/ui/button';
import { useRealTimeLogger } from '@/hooks/useRealTimeLogger';
import { Terminal, Database, Activity, Download, Zap } from 'lucide-react';

const RealTimeLogViewer = () => {
  const { getRecentLogs, getPerformanceData } = useRealTimeLogger();
  const [logs, setLogs] = useState<any[]>([]);
  const [performanceData, setPerformanceData] = useState<any>({});

  useEffect(() => {
    const updateData = () => {
      setLogs(getRecentLogs());
      setPerformanceData(getPerformanceData());
    };

    // Update immediately
    updateData();

    // Update every 5 seconds
    const interval = setInterval(updateData, 5000);
    return () => clearInterval(interval);
  }, [getRecentLogs, getPerformanceData]);

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'tier_update': return '🎖️';
      case 'player_event': return '🟢';
      case 'system_monitor': return '⚙️';
      case 'api_call': return '📡';
      case 'database_log': return '🧾';
      case 'staff_action': return '🔧';
      default: return '📋';
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'tier_update': return 'border-cyan-600 text-cyan-400';
      case 'player_event': return 'border-green-600 text-green-400';
      case 'system_monitor': return 'border-yellow-600 text-yellow-400';
      case 'api_call': return 'border-blue-600 text-blue-400';
      case 'database_log': return 'border-orange-600 text-orange-400';
      case 'staff_action': return 'border-red-600 text-red-400';
      default: return 'border-gray-600 text-gray-400';
    }
  };

  const exportLogs = () => {
    const exportData = {
      timestamp: new Date().toISOString(),
      performance: performanceData,
      logs: logs,
      total_logs: logs.length
    };

    const blob = new Blob([JSON.stringify(exportData, null, 2)], { 
      type: 'application/json' 
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `real-time-logs-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Zap className="h-5 w-5 text-purple-400" />
          <h3 className="text-lg font-bold text-white">Real-Time System Logger</h3>
          <Badge variant="outline" className="border-green-600 text-green-400">
            100% Real Data
          </Badge>
          <Badge variant="outline" className="text-xs border-gray-600 text-gray-300">
            {logs.length} verified events
          </Badge>
        </div>
        
        <Button
          onClick={exportLogs}
          variant="outline"
          size="sm"
          className="border-gray-600 text-gray-300 hover:bg-gray-700"
        >
          <Download className="h-4 w-4 mr-1" />
          Export
        </Button>
      </div>

      {/* Performance Dashboard */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="bg-gray-800/50 border-gray-600/50">
          <CardContent className="p-3">
            <div className="flex items-center space-x-2">
              <Activity className="h-4 w-4 text-yellow-400" />
              <div>
                <p className="text-xs text-gray-400">RAM Usage</p>
                <p className="text-lg font-bold text-white">{performanceData.ramUsage || 0}%</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gray-800/50 border-gray-600/50">
          <CardContent className="p-3">
            <div className="flex items-center space-x-2">
              <Database className="h-4 w-4 text-blue-400" />
              <div>
                <p className="text-xs text-gray-400">CPU Load</p>
                <p className="text-lg font-bold text-white">{performanceData.cpuLoad || 0}%</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gray-800/50 border-gray-600/50">
          <CardContent className="p-3">
            <div className="flex items-center space-x-2">
              <Terminal className="h-4 w-4 text-green-400" />
              <div>
                <p className="text-xs text-gray-400">Uptime</p>
                <p className="text-sm font-bold text-white">{performanceData.uptime || '0h 0m'}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gray-800/50 border-gray-600/50">
          <CardContent className="p-3">
            <div className="flex items-center space-x-2">
              <Zap className="h-4 w-4 text-purple-400" />
              <div>
                <p className="text-xs text-gray-400">Active Logs</p>
                <p className="text-lg font-bold text-white">{performanceData.activeConnections || 0}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Real-Time Logs */}
      <Card className="bg-gray-900/40 backdrop-blur-xl border-gray-700/50">
        <CardHeader className="pb-3">
          <CardTitle className="text-white text-lg flex items-center">
            <Terminal className="h-5 w-5 mr-2" />
            Live Verified Events
            <Badge variant="outline" className="ml-2 text-xs border-green-600 text-green-400 animate-pulse">
              REAL-TIME
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-96 w-full">
            <div className="space-y-2">
              {logs.length === 0 ? (
                <div className="text-center text-gray-400 py-8">
                  <Activity className="h-8 w-8 mx-auto mb-2" />
                  Monitoring real system events...
                  <p className="text-xs mt-2">All logs are 100% verified and real</p>
                </div>
              ) : (
                logs.slice().reverse().map((log, index) => (
                  <div 
                    key={`${log.id}-${index}`}
                    className="flex items-start space-x-3 p-3 rounded bg-gray-800/30 border border-gray-700/30"
                  >
                    <span className="text-lg">{getCategoryIcon(log.category)}</span>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center space-x-2 mb-1">
                        <Badge 
                          variant="outline" 
                          className={`text-xs ${getCategoryColor(log.category)}`}
                        >
                          {log.category.replace('_', ' ').toUpperCase()}
                        </Badge>
                        <Badge variant="outline" className="text-xs border-green-600 text-green-400">
                          VERIFIED
                        </Badge>
                        <span className="text-xs text-gray-500">
                          {new Date(log.timestamp).toLocaleTimeString()}
                        </span>
                      </div>
                      <div className="text-sm text-white">
                        {JSON.stringify(log.data, null, 2).slice(1, -1).replace(/"/g, '').replace(/,/g, ' •')}
                      </div>
                      <div className="text-xs text-gray-500 mt-1">
                        Source: {log.source} • ID: {log.id.slice(0, 8)}
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </ScrollArea>
        </CardContent>
      </Card>

      <div className="text-xs text-gray-500 text-center">
        Real-time verified event logging • No fake data • Backend-driven • 24/7 autonomous monitoring
      </div>
    </div>
  );
};

export default RealTimeLogViewer;
