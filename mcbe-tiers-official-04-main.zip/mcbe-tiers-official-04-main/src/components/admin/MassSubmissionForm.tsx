
import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { usePlayerManagement } from '@/hooks/usePlayerManagement';
import { Download, Upload, FileText } from 'lucide-react';

interface PlayerSubmissionData {
  ign: string;
  gamemode: string;
  tier: string;
  javaUsername?: string;
  region?: string;
  device?: string;
}

const MassSubmissionForm = () => {
  const [csvData, setCsvData] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [previewData, setPreviewData] = useState<PlayerSubmissionData[]>([]);
  const { toast } = useToast();
  const { submitPlayerResults } = usePlayerManagement();

  const downloadTemplate = () => {
    const template = `IGN,Gamemode,Tier,JavaUsername,Region,Device
ExamplePlayer1,Crystal,HT1,JavaPlayer1,NA,PC
ExamplePlayer2,Sword,LT2,JavaPlayer2,EU,Mobile
ExamplePlayer3,Axe,HT3,JavaPlayer3,AS,Console`;
    
    const blob = new Blob([template], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'mass_submission_template.csv';
    a.click();
    window.URL.revokeObjectURL(url);
    
    toast({
      title: "Template Downloaded",
      description: "CSV template has been downloaded successfully.",
    });
  };

  const parseCsvData = () => {
    if (!csvData.trim()) {
      toast({
        title: "No Data",
        description: "Please paste CSV data first.",
        variant: "destructive"
      });
      return;
    }

    try {
      const lines = csvData.trim().split('\n');
      const headers = lines[0].split(',').map(h => h.trim().toLowerCase());
      
      const requiredHeaders = ['ign', 'gamemode', 'tier', 'region', 'device'];
      const missingHeaders = requiredHeaders.filter(req => !headers.includes(req));
      
      if (missingHeaders.length > 0) {
        toast({
          title: "Invalid CSV Format",
          description: `Missing required columns: ${missingHeaders.join(', ')}`,
          variant: "destructive"
        });
        return;
      }

      const parsed: PlayerSubmissionData[] = [];
      
      for (let i = 1; i < lines.length; i++) {
        const values = lines[i].split(',').map(v => v.trim());
        if (values.length < headers.length) continue;
        
        const row: any = {};
        headers.forEach((header, index) => {
          row[header] = values[index] || '';
        });
        
        // Validate required fields
        if (!row.ign || !row.gamemode || !row.tier || !row.region || !row.device) {
          toast({
            title: "Invalid Row Data",
            description: `Row ${i + 1}: Missing required fields (IGN, Gamemode, Tier, Region, Device)`,
            variant: "destructive"
          });
          return;
        }
        
        parsed.push({
          ign: row.ign,
          gamemode: row.gamemode,
          tier: row.tier,
          javaUsername: row.javausername || row.java_username || undefined,
          region: row.region,
          device: row.device
        });
      }
      
      setPreviewData(parsed);
      toast({
        title: "CSV Parsed",
        description: `Successfully parsed ${parsed.length} player records.`,
      });
    } catch (error) {
      toast({
        title: "Parse Error",
        description: "Failed to parse CSV data. Please check the format.",
        variant: "destructive"
      });
    }
  };

  const handleMassSubmission = async () => {
    if (previewData.length === 0) {
      toast({
        title: "No Data",
        description: "Please parse CSV data first.",
        variant: "destructive"
      });
      return;
    }

    setIsSubmitting(true);
    try {
      const submissions = previewData.map(player => ({
        ign: player.ign,
        gamemode: player.gamemode,
        tier: player.tier,
        score: 0, // Will be calculated based on tier
        javaUsername: player.javaUsername,
        region: player.region,
        device: player.device
      }));

      const result = await submitPlayerResults(submissions);
      
      if (result.success) {
        toast({
          title: "Mass Submission Complete",
          description: `Successfully submitted ${submissions.length} player results.`,
        });
        setCsvData('');
        setPreviewData([]);
      } else {
        toast({
          title: "Submission Failed",
          description: result.error || "Failed to submit player results.",
          variant: "destructive"
        });
      }
    } catch (error) {
      toast({
        title: "Submission Error",
        description: "An unexpected error occurred during submission.",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      <Card className="bg-gray-900/40 backdrop-blur-xl border-gray-700/50">
        <CardHeader>
          <CardTitle className="text-white flex items-center">
            <Upload className="h-5 w-5 mr-2" />
            Mass Player Submission
          </CardTitle>
          <CardDescription className="text-gray-400">
            Submit multiple player results at once using CSV data. All fields (IGN, Gamemode, Tier, Region, Device) are required.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-2">
            <Button 
              onClick={downloadTemplate}
              variant="outline"
              className="border-gray-600 text-gray-300 hover:bg-gray-700"
            >
              <Download className="h-4 w-4 mr-2" />
              Download Template
            </Button>
            <Button 
              onClick={parseCsvData}
              disabled={!csvData.trim()}
              className="bg-blue-600 hover:bg-blue-700"
            >
              <FileText className="h-4 w-4 mr-2" />
              Parse CSV
            </Button>
          </div>
          
          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-300">
              CSV Data (paste your data here)
            </label>
            <Textarea
              value={csvData}
              onChange={(e) => setCsvData(e.target.value)}
              placeholder={`IGN,Gamemode,Tier,JavaUsername,Region,Device
Player1,Crystal,HT1,JavaUser1,NA,PC
Player2,Sword,LT2,JavaUser2,EU,Mobile`}
              className="min-h-[200px] bg-gray-800/60 border-gray-600/50 text-white font-mono text-sm"
            />
          </div>
        </CardContent>
      </Card>

      {previewData.length > 0 && (
        <Card className="bg-gray-900/40 backdrop-blur-xl border-gray-700/50">
          <CardHeader>
            <CardTitle className="text-white">Preview ({previewData.length} records)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="max-h-96 overflow-y-auto">
              <div className="grid gap-2">
                {previewData.slice(0, 10).map((player, index) => (
                  <div key={index} className="bg-gray-800/40 p-3 rounded-lg text-sm">
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-2 text-gray-300">
                      <div><strong>IGN:</strong> {player.ign}</div>
                      <div><strong>Mode:</strong> {player.gamemode}</div>
                      <div><strong>Tier:</strong> {player.tier}</div>
                      <div><strong>Region:</strong> {player.region}</div>
                      <div><strong>Device:</strong> {player.device}</div>
                      {player.javaUsername && (
                        <div><strong>Java:</strong> {player.javaUsername}</div>
                      )}
                    </div>
                  </div>
                ))}
                {previewData.length > 10 && (
                  <div className="text-center text-gray-400 text-sm">
                    ... and {previewData.length - 10} more records
                  </div>
                )}
              </div>
            </div>
            
            <div className="mt-4 pt-4 border-t border-gray-700">
              <Button 
                onClick={handleMassSubmission}
                disabled={isSubmitting}
                className="w-full bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700"
              >
                {isSubmitting ? 'Submitting...' : `Submit ${previewData.length} Records`}
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default MassSubmissionForm;
