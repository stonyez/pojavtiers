
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { Shield, Lock, User, MessageSquare, Eye, EyeOff, Sparkles, Crown, Zap } from 'lucide-react';
import { mcbeAdminService } from '@/services/mcbeAdminService';
import { motion } from 'framer-motion';

interface MCBEAdminAuthProps {
  onAuthSuccess: (role: string) => void;
}

export const MCBEAdminAuth: React.FC<MCBEAdminAuthProps> = ({ onAuthSuccess }) => {
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showOnboarding, setShowOnboarding] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [onboardingData, setOnboardingData] = useState({
    discord: '',
    secretKey: '',
    requestedRole: 'admin' as 'admin' | 'publisher',
    applicationStatement: ''
  });
  const { toast } = useToast();

  const handleInitialAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!password.trim()) {
      toast({
        title: "Validation Error",
        description: "Please enter a password",
        variant: "destructive"
      });
      return;
    }

    setIsLoading(true);
    try {
      const result = await mcbeAdminService.authenticateAdmin(password);
      
      if (result.success && result.role) {
        toast({
          title: "Access Granted",
          description: `Welcome back, ${result.role}!`,
        });
        onAuthSuccess(result.role);
      } else if (result.success && result.needsOnboarding) {
        setShowOnboarding(true);
        toast({
          title: "Staff Password Accepted",
          description: "Please complete your application",
        });
      } else {
        toast({
          title: "Access Denied",
          description: result.error || "Invalid credentials",
          variant: "destructive"
        });
      }
    } catch (error: any) {
      toast({
        title: "Authentication Error",
        description: error.message || "An unexpected error occurred",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleOnboardingSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!onboardingData.discord.trim() || !onboardingData.secretKey.trim() || !onboardingData.applicationStatement.trim()) {
      toast({
        title: "Validation Error",
        description: "Please fill in all required fields",
        variant: "destructive"
      });
      return;
    }

    setIsLoading(true);
    try {
      const result = await mcbeAdminService.submitApplication(onboardingData);
      
      if (result.success) {
        toast({
          title: "Application Submitted",
          description: "Your application has been submitted for review. You will be able to access the panel once approved.",
        });
        setShowOnboarding(false);
        setPassword('');
        setOnboardingData({
          discord: '',
          secretKey: '',
          requestedRole: 'admin',
          applicationStatement: ''
        });
      } else {
        toast({
          title: "Submission Failed",
          description: result.error || "Failed to submit application",
          variant: "destructive"
        });
      }
    } catch (error: any) {
      toast({
        title: "Submission Error",
        description: error.message || "An unexpected error occurred",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Background component to avoid repetition
  const AuthBackground = ({ children }: { children: React.ReactNode }) => (
    <div className="min-h-screen bg-gradient-to-br from-[#0a0b14] via-[#0f111a] to-[#1a1b2a] flex items-center justify-center p-4 relative overflow-hidden">
      {/* Animated Background Elements */}
      <div className="absolute inset-0 overflow-hidden">
        <motion.div
          className="absolute top-1/4 left-1/4 w-64 h-64 bg-purple-500/10 rounded-full blur-3xl"
          animate={{
            scale: [1, 1.2, 1],
            opacity: [0.3, 0.6, 0.3],
          }}
          transition={{
            duration: 4,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        />
        <motion.div
          className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-blue-500/10 rounded-full blur-3xl"
          animate={{
            scale: [1.2, 1, 1.2],
            opacity: [0.6, 0.3, 0.6],
          }}
          transition={{
            duration: 4,
            repeat: Infinity,
            ease: "easeInOut",
            delay: 2
          }}
        />
      </div>

      {/* Floating Particles */}
      {Array.from({ length: 15 }).map((_, i) => (
        <motion.div
          key={i}
          className="absolute w-1 h-1 bg-white/20 rounded-full"
          style={{
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 100}%`,
          }}
          animate={{
            y: [-20, -100, -20],
            opacity: [0, 1, 0],
          }}
          transition={{
            duration: 3 + Math.random() * 2,
            repeat: Infinity,
            delay: Math.random() * 2,
          }}
        />
      ))}

      {children}
    </div>
  );

  if (showOnboarding) {
    return (
      <AuthBackground>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="relative z-10"
        >
          <Card className="w-full max-w-lg bg-gray-900/60 backdrop-blur-2xl border border-gray-700/50 shadow-2xl shadow-purple-500/10 relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-r from-purple-500/10 via-transparent to-blue-500/10 opacity-50" />
            
            <CardHeader className="text-center space-y-4 pb-4 relative z-10">
              <motion.div 
                className="flex justify-center"
                whileHover={{ scale: 1.05 }}
                transition={{ type: "spring", stiffness: 300 }}
              >
                <div className="relative p-3 bg-gradient-to-br from-purple-600 via-blue-600 to-indigo-700 rounded-2xl shadow-lg">
                  <User className="h-8 w-8 text-white" />
                  <Sparkles className="absolute top-0 right-0 h-3 w-3 text-yellow-300 animate-pulse" />
                </div>
              </motion.div>
              
              <CardTitle className="text-2xl font-bold bg-gradient-to-r from-white via-purple-200 to-blue-200 bg-clip-text text-transparent">
                Staff Application
              </CardTitle>
              <CardDescription className="text-gray-400">
                Complete your staff application to access the admin panel
              </CardDescription>
            </CardHeader>
            
            <CardContent className="pt-0 space-y-4 relative z-10">
              <form onSubmit={handleOnboardingSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label className="text-gray-300 font-medium">Discord Username</Label>
                  <Input
                    value={onboardingData.discord}
                    onChange={(e) => setOnboardingData(prev => ({ ...prev, discord: e.target.value }))}
                    placeholder="Enter your Discord username"
                    className="bg-gray-800/50 border-gray-600/50 text-white h-11"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label className="text-gray-300 font-medium">Secret Key</Label>
                  <Input
                    type="password"
                    value={onboardingData.secretKey}
                    onChange={(e) => setOnboardingData(prev => ({ ...prev, secretKey: e.target.value }))}
                    placeholder="Enter the secret key provided by Owner"
                    className="bg-gray-800/50 border-gray-600/50 text-white h-11"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label className="text-gray-300 font-medium">Requested Role</Label>
                  <Select 
                    value={onboardingData.requestedRole} 
                    onValueChange={(value: 'admin' | 'publisher') => 
                      setOnboardingData(prev => ({ ...prev, requestedRole: value }))
                    }
                  >
                    <SelectTrigger className="bg-gray-800/50 border-gray-600/50 text-white h-11">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-gray-800 border-gray-600">
                      <SelectItem value="admin" className="text-white">Admin</SelectItem>
                      <SelectItem value="publisher" className="text-white">Publisher</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label className="text-gray-300 font-medium">Why are you applying?</Label>
                  <Textarea
                    value={onboardingData.applicationStatement}
                    onChange={(e) => setOnboardingData(prev => ({ ...prev, applicationStatement: e.target.value }))}
                    placeholder="Briefly explain why you're applying for this role..."
                    className="bg-gray-800/50 border-gray-600/50 text-white min-h-[100px] resize-none"
                    required
                  />
                </div>
                
                <div className="flex space-x-3 pt-2">
                  <Button 
                    type="button"
                    onClick={() => setShowOnboarding(false)}
                    variant="outline"
                    className="flex-1 border-gray-600 text-gray-300 hover:bg-gray-800 h-11"
                    disabled={isLoading}
                  >
                    Back
                  </Button>
                  <Button 
                    type="submit" 
                    className="flex-1 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 h-11"
                    disabled={isLoading}
                  >
                    {isLoading ? 'Submitting...' : 'Submit Application'}
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </motion.div>
      </AuthBackground>
    );
  }

  return (
    <AuthBackground>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="relative z-10"
      >
        <Card className="w-full max-w-md bg-gray-900/60 backdrop-blur-2xl border border-gray-700/50 shadow-2xl shadow-purple-500/10 relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-r from-purple-500/10 via-transparent to-blue-500/10 opacity-50" />
          
          <CardHeader className="text-center space-y-4 pb-6 relative z-10">
            <motion.div 
              className="flex justify-center"
              whileHover={{ scale: 1.05 }}
              transition={{ type: "spring", stiffness: 300 }}
            >
              <div className="relative p-4 bg-gradient-to-br from-purple-600 via-blue-600 to-indigo-700 rounded-2xl shadow-lg">
                <Shield className="h-10 w-10 text-white" />
                <Sparkles className="absolute top-1 right-1 h-3 w-3 text-yellow-300 animate-pulse" />
                <Crown className="absolute bottom-1 left-1 h-3 w-3 text-yellow-400 animate-pulse" style={{ animationDelay: '0.5s' }} />
                <Zap className="absolute top-1 left-1 h-3 w-3 text-blue-300 animate-pulse" style={{ animationDelay: '1s' }} />
              </div>
            </motion.div>
            
            <CardTitle className="text-3xl font-bold bg-gradient-to-r from-white via-purple-200 to-blue-200 bg-clip-text text-transparent">
              MCBE-Tiers Admin
            </CardTitle>
            <CardDescription className="text-gray-400 text-base">
              Secure administrative access portal
            </CardDescription>
          </CardHeader>
          
          <CardContent className="pt-0 space-y-6 relative z-10">
            <form onSubmit={handleInitialAuth} className="space-y-6">
              <div className="space-y-3">
                <Label className="text-gray-300 font-semibold flex items-center gap-2">
                  <Lock className="h-4 w-4" />
                  Administrative Password
                </Label>
                <div className="relative group">
                  <Input
                    type={showPassword ? "text" : "password"}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Enter your secure password"
                    className="pl-12 pr-12 h-12 bg-gray-800/50 border-gray-600/50 text-white placeholder:text-gray-500 focus:border-purple-500/70 focus:ring-purple-500/30 transition-all duration-300"
                    disabled={isLoading}
                  />
                  <Lock className="absolute left-4 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400 group-focus-within:text-purple-400 transition-colors" />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-4 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-white transition-colors"
                    disabled={isLoading}
                  >
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
              </div>
              
              <motion.div
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                <Button 
                  type="submit" 
                  className="w-full h-12 bg-gradient-to-r from-purple-600 via-blue-600 to-indigo-700 hover:from-purple-700 hover:via-blue-700 hover:to-indigo-800 text-white font-semibold text-base shadow-lg shadow-purple-500/25 border border-purple-500/30"
                  disabled={isLoading}
                >
                  <div className="flex items-center justify-center gap-2">
                    {isLoading ? (
                      <>
                        <motion.div
                          className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full"
                          animate={{ rotate: 360 }}
                          transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                        />
                        Authenticating...
                      </>
                    ) : (
                      <>
                        <Shield className="h-4 w-4" />
                        Access Control Panel
                      </>
                    )}
                  </div>
                </Button>
              </motion.div>
            </form>
            
            <div className="text-center pt-4 border-t border-gray-700/50">
              <p className="text-xs text-gray-500">
                🔒 Secured with enterprise-grade encryption
              </p>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </AuthBackground>
  );
};
