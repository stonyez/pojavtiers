import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Users, FileText, UserCheck, Clock, Shield, CheckCircle, XCircle, AlertTriangle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { staffService, StaffMember, StaffApplication, StaffLog } from '@/services/staffService';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';

interface StaffLogEntry {
  log_id: string;
  staff_id: string;
  device_id: string;
  username: string;
  operation_type: string;
  operation_details: any;
  timestamp: string;
  status: 'pending' | 'approved' | 'denied' | 'error';
  executed_at?: string;
  owner_remarks?: string;
  error_flag?: boolean;
}

export const UnifiedStaffTools = () => {
  const [activeTab, setActiveTab] = useState('staff');
  const [staffMembers, setStaffMembers] = useState<StaffMember[]>([]);
  const [applications, setApplications] = useState<StaffApplication[]>([]);
  const [logs, setLogs] = useState<StaffLog[]>([]);
  const [staffOperationLogs, setStaffOperationLogs] = useState<StaffLogEntry[]>([]);
  const [pendingApprovals, setPendingApprovals] = useState<StaffLogEntry[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [loadedTabs, setLoadedTabs] = useState<Set<string>>(new Set());
  const { toast } = useToast();

  const loadStaffData = useCallback(async () => {
    if (loadedTabs.has('staff')) return;
    
    try {
      setIsLoading(true);
      console.log('Loading staff data...');
      const staff = await staffService.getStaffMembers();
      setStaffMembers(staff);
      setLoadedTabs(prev => new Set([...prev, 'staff']));
      console.log('Staff data loaded:', staff.length, 'members');
    } catch (error: any) {
      console.error('Error loading staff:', error);
      toast({
        title: "Error Loading Staff",
        description: error.message || "Failed to load staff data",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  }, [loadedTabs, toast]);

  const loadApplicationsData = useCallback(async () => {
    if (loadedTabs.has('applications')) return;
    
    try {
      setIsLoading(true);
      console.log('Loading applications data...');
      const apps = await staffService.getStaffApplications();
      setApplications(apps);
      setLoadedTabs(prev => new Set([...prev, 'applications']));
      console.log('Applications data loaded:', apps.length, 'applications');
    } catch (error: any) {
      console.error('Error loading applications:', error);
      toast({
        title: "Error Loading Applications",
        description: error.message || "Failed to load applications",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  }, [loadedTabs, toast]);

  const loadLogsData = useCallback(async () => {
    if (loadedTabs.has('logs')) return;
    
    try {
      setIsLoading(true);
      console.log('Loading logs data...');
      const logsData = await staffService.getStaffLogs();
      setLogs(logsData);
      setLoadedTabs(prev => new Set([...prev, 'logs']));
      console.log('Logs data loaded:', logsData.length, 'logs');
    } catch (error: any) {
      console.error('Error loading logs:', error);
      toast({
        title: "Error Loading Logs",
        description: error.message || "Failed to load activity logs",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  }, [loadedTabs, toast]);

  const loadStaffOperationLogs = useCallback(async () => {
    if (loadedTabs.has('staff-logs')) return;
    
    try {
      setIsLoading(true);
      console.log('Loading staff operation logs...');
      
      // Mock data for staff operation logs - in real implementation, this would come from Supabase
      const mockStaffLogs: StaffLogEntry[] = [
        {
          log_id: '1',
          staff_id: 'staff-1',
          device_id: 'device-123',
          username: 'moderator#MCBETIERS.com',
          operation_type: 'Tier Updated',
          operation_details: { player: 'PlayerX', gamemode: 'Skywars', old_tier: 'LT3', new_tier: 'HT3' },
          timestamp: new Date().toISOString(),
          status: 'pending'
        },
        {
          log_id: '2',
          staff_id: 'staff-2',
          device_id: 'device-456',
          username: 'admin#MCBETIERS.com',
          operation_type: 'Player Result Submitted',
          operation_details: { player: 'PlayerY', gamemode: 'Bedwars', tier: 'HT2', score: 1500 },
          timestamp: new Date(Date.now() - 3600000).toISOString(),
          status: 'approved',
          executed_at: new Date(Date.now() - 1800000).toISOString()
        },
        {
          log_id: '3',
          staff_id: 'staff-1',
          device_id: 'device-123',
          username: 'moderator#MCBETIERS.com',
          operation_type: 'Player Flagged',
          operation_details: { player: 'SuspiciousPlayer', reason: 'Suspected cheating' },
          timestamp: new Date(Date.now() - 7200000).toISOString(),
          status: 'denied',
          owner_remarks: 'Insufficient evidence'
        }
      ];

      setStaffOperationLogs(mockStaffLogs);
      setPendingApprovals(mockStaffLogs.filter(log => log.status === 'pending'));
      setLoadedTabs(prev => new Set([...prev, 'staff-logs']));
      console.log('Staff operation logs loaded:', mockStaffLogs.length, 'entries');
    } catch (error: any) {
      console.error('Error loading staff operation logs:', error);
      toast({
        title: "Error Loading Staff Logs",
        description: error.message || "Failed to load staff operation logs",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  }, [loadedTabs, toast]);

  // Load data when tab changes
  useEffect(() => {
    console.log('Active tab changed to:', activeTab);
    
    if (activeTab === 'staff') {
      loadStaffData();
    } else if (activeTab === 'applications') {
      loadApplicationsData();
    } else if (activeTab === 'logs') {
      loadLogsData();
    } else if (activeTab === 'staff-logs') {
      loadStaffOperationLogs();
    }
  }, [activeTab, loadStaffData, loadApplicationsData, loadLogsData, loadStaffOperationLogs]);

  const handleApproveApplication = useCallback(async (applicationId: string) => {
    try {
      console.log('Approving application:', applicationId);
      const result = await staffService.reviewApplication(applicationId, 'approve', 'owner');
      
      if (result.success) {
        toast({
          title: "Application Approved",
          description: "The application has been approved successfully.",
        });
        // Force reload applications
        setLoadedTabs(prev => {
          const newSet = new Set(prev);
          newSet.delete('applications');
          return newSet;
        });
        setApplications([]);
        await loadApplicationsData();
      } else {
        throw new Error(result.error);
      }
    } catch (error: any) {
      console.error('Approval failed:', error);
      toast({
        title: "Approval Failed",
        description: error.message || "Failed to approve application",
        variant: "destructive"
      });
    }
  }, [toast, loadApplicationsData]);

  const handleDenyApplication = useCallback(async (applicationId: string) => {
    try {
      console.log('Denying application:', applicationId);
      const result = await staffService.reviewApplication(applicationId, 'deny', 'owner');
      
      if (result.success) {
        toast({
          title: "Application Denied",
          description: "The application has been denied.",
        });
        // Force reload applications
        setLoadedTabs(prev => {
          const newSet = new Set(prev);
          newSet.delete('applications');
          return newSet;
        });
        setApplications([]);
        await loadApplicationsData();
      } else {
        throw new Error(result.error);
      }
    } catch (error: any) {
      console.error('Denial failed:', error);
      toast({
        title: "Denial Failed",
        description: error.message || "Failed to deny application",
        variant: "destructive"
      });
    }
  }, [toast, loadApplicationsData]);

  const handleApproveStaffOperation = useCallback(async (logId: string, remarks?: string) => {
    try {
      console.log('Approving staff operation:', logId);
      
      // Update the staff operation log
      setStaffOperationLogs(prev => prev.map(log => 
        log.log_id === logId 
          ? { ...log, status: 'approved', executed_at: new Date().toISOString(), owner_remarks: remarks }
          : log
      ));
      
      // Remove from pending approvals
      setPendingApprovals(prev => prev.filter(log => log.log_id !== logId));
      
      toast({
        title: "Operation Approved",
        description: "The staff operation has been approved and executed.",
      });
    } catch (error: any) {
      console.error('Operation approval failed:', error);
      toast({
        title: "Approval Failed",
        description: error.message || "Failed to approve operation",
        variant: "destructive"
      });
    }
  }, [toast]);

  const handleDenyStaffOperation = useCallback(async (logId: string, remarks?: string) => {
    try {
      console.log('Denying staff operation:', logId);
      
      // Update the staff operation log
      setStaffOperationLogs(prev => prev.map(log => 
        log.log_id === logId 
          ? { ...log, status: 'denied', owner_remarks: remarks }
          : log
      ));
      
      // Remove from pending approvals
      setPendingApprovals(prev => prev.filter(log => log.log_id !== logId));
      
      toast({
        title: "Operation Denied",
        description: "The staff operation has been denied.",
      });
    } catch (error: any) {
      console.error('Operation denial failed:', error);
      toast({
        title: "Denial Failed",
        description: error.message || "Failed to deny operation",
        variant: "destructive"
      });
    }
  }, [toast]);

  const getRoleBadgeColor = useMemo(() => (role: string) => {
    switch (role.toLowerCase()) {
      case 'owner': return 'bg-red-500/20 text-red-300 border-red-500/50';
      case 'admin': return 'bg-orange-500/20 text-orange-300 border-orange-500/50';
      case 'moderator': return 'bg-blue-500/20 text-blue-300 border-blue-500/50';
      case 'publisher': return 'bg-green-500/20 text-green-300 border-green-500/50';
      default: return 'bg-gray-500/20 text-gray-300 border-gray-500/50';
    }
  }, []);

  const getStatusBadgeColor = (status: string) => {
    switch (status) {
      case 'pending': return 'bg-yellow-500/20 text-yellow-300 border-yellow-500/50';
      case 'approved': return 'bg-green-500/20 text-green-300 border-green-500/50';
      case 'denied': return 'bg-red-500/20 text-red-300 border-red-500/50';
      case 'error': return 'bg-red-600/20 text-red-400 border-red-600/50';
      default: return 'bg-gray-500/20 text-gray-300 border-gray-500/50';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center space-x-2 mb-6">
        <Shield className="h-6 w-6 text-purple-400" />
        <h2 className="text-2xl font-bold text-white">Staff Management</h2>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-4 bg-gray-800/50">
          <TabsTrigger value="staff" className="data-[state=active]:bg-purple-600/20">
            <Users className="h-4 w-4 mr-2" />
            Active Staff
          </TabsTrigger>
          <TabsTrigger value="logs" className="data-[state=active]:bg-purple-600/20">
            <FileText className="h-4 w-4 mr-2" />
            Activity Logs
          </TabsTrigger>
          <TabsTrigger value="applications" className="data-[state=active]:bg-purple-600/20">
            <UserCheck className="h-4 w-4 mr-2" />
            Applications
          </TabsTrigger>
          <TabsTrigger value="staff-logs" className="data-[state=active]:bg-purple-600/20">
            <Shield className="h-4 w-4 mr-2" />
            Staff Logs & Approvals
          </TabsTrigger>
        </TabsList>

        <TabsContent value="staff" className="space-y-4">
          <Card className="bg-gray-900/50 border-gray-700/50">
            <CardHeader>
              <CardTitle className="text-white">Staff Members</CardTitle>
              <CardDescription>Manage active staff members and their permissions</CardDescription>
            </CardHeader>
            <CardContent>
              {isLoading && !loadedTabs.has('staff') ? (
                <div className="text-center text-gray-400 py-8">Loading staff members...</div>
              ) : (
                <div className="space-y-3">
                  {staffMembers.map((member) => (
                    <div key={member.id} className="flex items-center justify-between p-3 bg-gray-800/30 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <div className="w-8 h-8 bg-purple-600 rounded-full flex items-center justify-center">
                          <span className="text-white text-sm font-bold">
                            {member.username.charAt(0).toUpperCase()}
                          </span>
                        </div>
                        <div>
                          <div className="text-white font-medium">{member.username}</div>
                          <div className="text-gray-400 text-sm">Last login: {member.last_login ? new Date(member.last_login).toLocaleDateString() : 'Never'}</div>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Badge className={getRoleBadgeColor(member.role)}>
                          {member.role}
                        </Badge>
                        <div className={`w-2 h-2 rounded-full ${member.is_active ? 'bg-green-400' : 'bg-red-400'}`} />
                      </div>
                    </div>
                  ))}
                  {staffMembers.length === 0 && !isLoading && (
                    <div className="text-center text-gray-400 py-8">
                      No staff members found
                    </div>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="logs" className="space-y-4">
          <Card className="bg-gray-900/50 border-gray-700/50">
            <CardHeader>
              <CardTitle className="text-white">Activity Logs</CardTitle>
              <CardDescription>Recent staff actions and system events</CardDescription>
            </CardHeader>
            <CardContent>
              {isLoading && !loadedTabs.has('logs') ? (
                <div className="text-center text-gray-400 py-8">Loading activity logs...</div>
              ) : (
                <div className="space-y-3">
                  {logs.map((log) => (
                    <div key={log.id} className="flex items-center justify-between p-3 bg-gray-800/30 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <Clock className="h-4 w-4 text-gray-400" />
                        <div>
                          <div className="text-white font-medium">{log.action}</div>
                          <div className="text-gray-400 text-sm">by {log.staff_member}</div>
                          {log.details && (
                            <div className="text-gray-500 text-xs mt-1">{log.details}</div>
                          )}
                        </div>
                      </div>
                      <div className="text-gray-400 text-sm">
                        {new Date(log.timestamp).toLocaleString()}
                      </div>
                    </div>
                  ))}
                  {logs.length === 0 && !isLoading && (
                    <div className="text-center text-gray-400 py-8">
                      No activity logs found
                    </div>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="applications" className="space-y-4">
          <Card className="bg-gray-900/50 border-gray-700/50">
            <CardHeader>
              <CardTitle className="text-white">Pending Applications</CardTitle>
              <CardDescription>Review and approve staff applications</CardDescription>
            </CardHeader>
            <CardContent>
              {isLoading && !loadedTabs.has('applications') ? (
                <div className="text-center text-gray-400 py-8">Loading applications...</div>
              ) : (
                <div className="space-y-4">
                  {applications.map((app) => (
                    <div key={app.id} className="p-4 bg-gray-800/30 rounded-lg border border-gray-700/50">
                      <div className="flex justify-between items-start mb-3">
                        <div>
                          <div className="text-white font-medium">{app.discord}</div>
                          <div className="text-gray-400 text-sm">
                            Requested: {app.requested_role} • {new Date(app.submitted_at).toLocaleDateString()}
                          </div>
                        </div>
                        <Badge className={getRoleBadgeColor(app.requested_role)}>
                          {app.requested_role}
                        </Badge>
                      </div>
                      
                      {app.application_statement && (
                        <div className="mb-3 p-3 bg-gray-900/30 rounded text-gray-300 text-sm">
                          {app.application_statement}
                        </div>
                      )}
                      
                      <div className="flex space-x-2">
                        <Button 
                          size="sm" 
                          className="bg-green-600 hover:bg-green-700"
                          onClick={() => handleApproveApplication(app.id)}
                          disabled={isLoading}
                        >
                          Approve
                        </Button>
                        <Button 
                          size="sm" 
                          variant="outline" 
                          className="border-red-600 text-red-400 hover:bg-red-600/10"
                          onClick={() => handleDenyApplication(app.id)}
                          disabled={isLoading}
                        >
                          Deny
                        </Button>
                      </div>
                    </div>
                  ))}
                  {applications.length === 0 && !isLoading && (
                    <div className="text-center text-gray-400 py-8">
                      No pending applications
                    </div>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="staff-logs" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Pending Approvals */}
            <Card className="bg-gray-900/50 border-gray-700/50">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <AlertTriangle className="h-5 w-5 mr-2 text-yellow-400" />
                  Pending Approvals ({pendingApprovals.length})
                </CardTitle>
                <CardDescription>Staff operations awaiting your approval</CardDescription>
              </CardHeader>
              <CardContent>
                {isLoading && !loadedTabs.has('staff-logs') ? (
                  <div className="text-center text-gray-400 py-8">Loading pending approvals...</div>
                ) : (
                  <div className="space-y-3 max-h-96 overflow-y-auto">
                    {pendingApprovals.map((log) => (
                      <div key={log.log_id} className="p-3 bg-gray-800/30 rounded-lg border border-yellow-500/20">
                        <div className="flex justify-between items-start mb-2">
                          <div>
                            <div className="text-white font-medium">{log.operation_type}</div>
                            <div className="text-gray-400 text-sm">by {log.username}</div>
                          </div>
                          <Badge className={getStatusBadgeColor(log.status)}>
                            {log.status}
                          </Badge>
                        </div>
                        
                        {log.operation_details && (
                          <div className="mb-3 p-2 bg-gray-900/30 rounded text-gray-300 text-xs">
                            <pre className="whitespace-pre-wrap">
                              {JSON.stringify(log.operation_details, null, 2)}
                            </pre>
                          </div>
                        )}
                        
                        <div className="text-gray-500 text-xs mb-3">
                          {new Date(log.timestamp).toLocaleString()}
                        </div>
                        
                        <div className="flex space-x-2">
                          <Button 
                            size="sm" 
                            className="bg-green-600 hover:bg-green-700"
                            onClick={() => handleApproveStaffOperation(log.log_id)}
                          >
                            <CheckCircle className="h-3 w-3 mr-1" />
                            Approve
                          </Button>
                          <Button 
                            size="sm" 
                            variant="outline" 
                            className="border-red-600 text-red-400 hover:bg-red-600/10"
                            onClick={() => handleDenyStaffOperation(log.log_id)}
                          >
                            <XCircle className="h-3 w-3 mr-1" />
                            Deny
                          </Button>
                        </div>
                      </div>
                    ))}
                    {pendingApprovals.length === 0 && !isLoading && (
                      <div className="text-center text-gray-400 py-8">
                        No pending approvals
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* All Staff Logs */}
            <Card className="bg-gray-900/50 border-gray-700/50">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <FileText className="h-5 w-5 mr-2 text-blue-400" />
                  All Staff Logs
                </CardTitle>
                <CardDescription>Complete history of staff operations</CardDescription>
              </CardHeader>
              <CardContent>
                {isLoading && !loadedTabs.has('staff-logs') ? (
                  <div className="text-center text-gray-400 py-8">Loading staff logs...</div>
                ) : (
                  <div className="space-y-2 max-h-96 overflow-y-auto">
                    {staffOperationLogs.map((log) => (
                      <div key={log.log_id} className="p-3 bg-gray-800/30 rounded-lg">
                        <div className="flex justify-between items-start mb-2">
                          <div>
                            <div className="text-white font-medium text-sm">{log.operation_type}</div>
                            <div className="text-gray-400 text-xs">by {log.username}</div>
                          </div>
                          <Badge className={getStatusBadgeColor(log.status)}>
                            {log.status}
                          </Badge>
                        </div>
                        
                        <div className="text-gray-500 text-xs">
                          {new Date(log.timestamp).toLocaleString()}
                          {log.executed_at && (
                            <span className="ml-2">• Executed: {new Date(log.executed_at).toLocaleString()}</span>
                          )}
                        </div>
                        
                        {log.owner_remarks && (
                          <div className="mt-2 p-2 bg-gray-900/30 rounded text-gray-300 text-xs">
                            <strong>Owner remarks:</strong> {log.owner_remarks}
                          </div>
                        )}
                      </div>
                    ))}
                    {staffOperationLogs.length === 0 && !isLoading && (
                      <div className="text-center text-gray-400 py-8">
                        No staff logs found
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};
