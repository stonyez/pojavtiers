
import React, { useState, useEffect, useRef } from 'react';
import { User, Settings, LogOut, Shield, Circle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { cn } from '@/lib/utils';
import { staffOnboardingService } from '@/services/staffOnboardingService';

interface StaffProfileProps {
  onLogout?: () => void;
  onResetSessions?: () => void;
}

export const StaffProfile: React.FC<StaffProfileProps> = ({ onLogout, onResetSessions }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [staffData, setStaffData] = useState(staffOnboardingService.getStaffData());
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Create default staff data if none exists
    if (!staffData || !staffData.username) {
      const defaultStaffData = {
        username: localStorage.getItem('staff_username') || 'Owner',
        role: localStorage.getItem('admin_role') || 'owner',
        onboardingComplete: true,
        firstLoginDate: new Date().toISOString(),
        lastActiveDate: new Date().toISOString()
      };
      setStaffData(defaultStaffData);
      console.log('StaffProfile: Using default staff data', defaultStaffData);
    } else {
      staffOnboardingService.updateLastActive();
    }

    const interval = setInterval(() => {
      const updatedData = staffOnboardingService.getStaffData();
      if (updatedData && updatedData.username) {
        setStaffData(updatedData);
        staffOnboardingService.updateLastActive();
      }
    }, 30000);

    return () => clearInterval(interval);
  }, [staffData]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };

    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
      return () => document.removeEventListener('mousedown', handleClickOutside);
    }
  }, [isOpen]);

  // Always render something, even if no staff data
  const displayData = staffData || {
    username: localStorage.getItem('staff_username') || 'Owner',
    role: localStorage.getItem('admin_role') || 'owner',
    onboardingComplete: true,
    firstLoginDate: new Date().toISOString(),
    lastActiveDate: new Date().toISOString()
  };

  const getInitials = (username: string): string => {
    return username.slice(0, 2).toUpperCase();
  };

  const getRoleColor = (role: string): string => {
    switch (role.toLowerCase()) {
      case 'owner': return 'from-red-500 to-red-600';
      case 'admin': return 'from-purple-500 to-purple-600';
      case 'moderator': return 'from-blue-500 to-blue-600';
      case 'tester': return 'from-green-500 to-green-600';
      default: return 'from-gray-500 to-gray-600';
    }
  };

  const getRoleIcon = (role: string) => {
    switch (role.toLowerCase()) {
      case 'owner': return <Shield className="h-3 w-3 text-red-400" />;
      case 'admin': return <Shield className="h-3 w-3 text-purple-400" />;
      case 'moderator': return <Shield className="h-3 w-3 text-blue-400" />;
      default: return <User className="h-3 w-3 text-muted-foreground" />;
    }
  };

  const handleResetSessions = () => {
    staffOnboardingService.resetAllSessions();
    onResetSessions?.();
    setIsOpen(false);
    window.location.reload();
  };

  const handleLogout = () => {
    onLogout?.();
    setIsOpen(false);
  };

  return (
    <div className="relative" ref={dropdownRef}>
      <Button
        onClick={() => setIsOpen(!isOpen)}
        variant="ghost"
        size="sm"
        className="h-10 w-10 rounded-full p-0 relative hover:opacity-80 transition-opacity"
      >
        <Avatar className="h-10 w-10">
          <AvatarImage 
            src="/default-avatar.png" 
            alt={displayData.username}
            className="object-cover"
          />
          <AvatarFallback 
            className={cn(
              "text-white font-semibold text-sm bg-gradient-to-br",
              getRoleColor(displayData.role)
            )}
          >
            {getInitials(displayData.username)}
          </AvatarFallback>
        </Avatar>
        
        {/* Active status indicator */}
        <div className="absolute -bottom-0.5 -right-0.5 h-3 w-3 bg-green-500 border-2 border-background rounded-full" />
      </Button>

      {isOpen && (
        <Card className="absolute top-12 right-0 w-72 z-50 shadow-lg border bg-background">
          <CardContent className="p-4 space-y-4">
            <div className="flex items-center space-x-3">
              <Avatar className="h-12 w-12">
                <AvatarImage 
                  src="/default-avatar.png" 
                  alt={displayData.username}
                  className="object-cover"
                />
                <AvatarFallback 
                  className={cn(
                    "text-white font-semibold bg-gradient-to-br",
                    getRoleColor(displayData.role)
                  )}
                >
                  {getInitials(displayData.username)}
                </AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-foreground truncate">
                  {displayData.username}
                </p>
                <div className="flex items-center space-x-1">
                  {getRoleIcon(displayData.role)}
                  <p className="text-xs text-muted-foreground capitalize">
                    {displayData.role}
                  </p>
                </div>
              </div>
            </div>

            <div className="flex items-center space-x-2 text-xs text-muted-foreground">
              <Circle className="h-2 w-2 fill-green-500 text-green-500" />
              <span>Active</span>
            </div>

            <div className="space-y-2 pt-2 border-t">
              <Button
                onClick={handleResetSessions}
                variant="outline"
                size="sm"
                className="w-full justify-start text-xs"
              >
                <Settings className="h-3 w-3 mr-2" />
                Reset All Sessions
              </Button>
              
              <Button
                onClick={handleLogout}
                variant="outline"
                size="sm"
                className="w-full justify-start text-xs text-red-600 hover:text-red-700"
              >
                <LogOut className="h-3 w-3 mr-2" />
                Sign Out
              </Button>
            </div>

            {displayData.firstLoginDate && displayData.lastActiveDate && (
              <div className="text-xs text-muted-foreground pt-2 border-t">
                <p>First Login: {new Date(displayData.firstLoginDate).toLocaleDateString()}</p>
                <p>Last Active: {new Date(displayData.lastActiveDate).toLocaleString()}</p>
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
};
