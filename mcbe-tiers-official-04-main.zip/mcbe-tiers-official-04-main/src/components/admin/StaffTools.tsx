import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/hooks/use-toast';
import { newAdminService } from '@/services/newAdminService';
import { supabase } from '@/integrations/supabase/client';
import { 
  Users, 
  FileText, 
  Shield, 
  Clock,
  CheckCircle,
  XCircle,
  Activity,
  RefreshCw,
  UserCheck,
  AlertCircle
} from 'lucide-react';

interface StaffUser {
  id: string;
  role: string;
  ip_address: string;
  is_active: boolean;
  approved_by: string;
  approved_at: string;
  last_access?: string;
}

interface StaffLog {
  id: string;
  staff_name: string;
  action: string;
  details: any;
  status: 'pending' | 'approved' | 'rejected' | 'completed';
  created_at: string;
  reviewed_at?: string;
  reviewed_by?: string;
}

interface StaffApplication {
  id: string;
  discord: string;
  requested_role: string;
  secret_key: string;
  application_statement?: string;
  status: string;
  submitted_at: string;
  ip_address: string;
}

const StaffTools = () => {
  const [activeTab, setActiveTab] = useState('staff');
  const [staffUsers, setStaffUsers] = useState<StaffUser[]>([]);
  const [logs, setLogs] = useState<StaffLog[]>([]);
  const [applications, setApplications] = useState<StaffApplication[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const fetchStaffUsers = async () => {
    try {
      const data = await newAdminService.getAdminUsers();
      setStaffUsers(data);
    } catch (error: any) {
      console.error('Error fetching staff users:', error);
    }
  };

  const fetchLogs = async () => {
    try {
      // Fetch lockbox queue entries as staff actions
      const { data: lockboxEntries, error: lockboxError } = await supabase
        .from('lockbox_queue')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(50);

      if (!lockboxError && lockboxEntries) {
        const lockboxLogs: StaffLog[] = lockboxEntries.map(entry => ({
          id: entry.id,
          staff_name: entry.submitter_role || 'System',
          action: `Lockbox Task: ${entry.task_type || 'Unknown'}`,
          details: entry.task_data || {},
          status: (entry.status as 'pending' | 'approved' | 'rejected') || 'pending',
          created_at: entry.created_at,
          reviewed_at: entry.reviewed_at,
          reviewed_by: entry.reviewed_by
        }));
        setLogs(lockboxLogs);
      }
    } catch (error: any) {
      console.error('Error fetching logs:', error);
    }
  };

  const fetchApplications = async () => {
    try {
      const data = await newAdminService.getPendingApplications();
      setApplications(data);
    } catch (error: any) {
      console.error('Error fetching applications:', error);
    }
  };

  const handleBanUser = async (userId: string) => {
    try {
      const result = await newAdminService.banAdminUser(userId);
      if (result.success) {
        toast({
          title: "User Banned",
          description: "User has been deactivated successfully.",
        });
        await fetchStaffUsers();
      } else {
        toast({
          title: "Ban Failed",
          description: result.error || "Failed to ban user",
          variant: "destructive"
        });
      }
    } catch (error: any) {
      toast({
        title: "Ban Failed",
        description: error.message,
        variant: "destructive"
      });
    }
  };

  const handleReviewApplication = async (
    applicationId: string, 
    action: 'approve' | 'deny',
    assignedRole?: string
  ) => {
    try {
      const result = await newAdminService.reviewApplicationWithRole(
        applicationId, 
        action === 'approve' ? 'approve' : 'reject',
        assignedRole
      );
      
      if (result.success) {
        toast({
          title: action === 'approve' ? "Application Approved" : "Application Rejected",
          description: `Application has been ${action}d successfully.`,
        });
        await fetchApplications();
      } else {
        toast({
          title: "Review Failed",
          description: result.error || `Failed to ${action} application`,
          variant: "destructive"
        });
      }
    } catch (error: any) {
      toast({
        title: "Review Error",
        description: error.message,
        variant: "destructive"
      });
    }
  };

  useEffect(() => {
    if (activeTab === 'staff') {
      fetchStaffUsers();
    } else if (activeTab === 'logs') {
      fetchLogs();
    } else if (activeTab === 'applications') {
      fetchApplications();
    }
  }, [activeTab]);

  if (!newAdminService.canManageStaff()) {
    return (
      <div className="text-center text-gray-400 py-8">
        <Shield className="h-12 w-12 mx-auto mb-4 opacity-50" />
        <p>You don't have permission to access staff tools.</p>
        <p className="text-sm mt-2">Current role: {newAdminService.getCurrentRole()}</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-gradient-to-br from-blue-600/20 to-purple-600/20 rounded-lg border border-blue-500/30">
            <Users className="h-6 w-6 text-blue-400" />
          </div>
          <div>
            <h3 className="text-xl font-bold text-white">Staff Tools</h3>
            <p className="text-gray-400 text-sm">Manage staff, view logs, and review applications</p>
          </div>
        </div>
      </div>

      <Card className="bg-gray-900/40 backdrop-blur-xl border-gray-700/50">
        <CardContent className="p-0">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-3 bg-gray-800/50">
              <TabsTrigger value="staff" className="text-white data-[state=active]:bg-blue-600/20">
                <Users className="h-4 w-4 mr-2" />
                Active Staff
              </TabsTrigger>
              <TabsTrigger value="logs" className="text-white data-[state=active]:bg-blue-600/20">
                <FileText className="h-4 w-4 mr-2" />
                Logs
              </TabsTrigger>
              <TabsTrigger value="applications" className="text-white data-[state=active]:bg-blue-600/20">
                <UserCheck className="h-4 w-4 mr-2" />
                Applications
              </TabsTrigger>
            </TabsList>

            <TabsContent value="staff" className="p-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h4 className="text-lg font-semibold text-white">Staff Members ({staffUsers.length})</h4>
                  <Button
                    onClick={fetchStaffUsers}
                    disabled={isLoading}
                    className="bg-blue-600/20 border border-blue-500/50 text-blue-400 hover:bg-blue-600/30"
                    size="sm"
                  >
                    <RefreshCw className={`h-4 w-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
                    Refresh
                  </Button>
                </div>

                {staffUsers.length === 0 ? (
                  <div className="text-center text-gray-400 py-8">No staff members found.</div>
                ) : (
                  <div className="space-y-3">
                    {staffUsers.map((user) => (
                      <div key={user.id} className="bg-gray-800/40 rounded-lg p-4 border border-gray-700/40">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-3">
                            <div className="w-10 h-10 bg-gradient-to-br from-blue-500/20 to-purple-500/20 border border-blue-500/30 rounded-full flex items-center justify-center">
                              <Shield className="h-5 w-5 text-blue-400" />
                            </div>
                            <div>
                              <div className="flex items-center space-x-2">
                                <span className="text-white font-medium">{user.role}</span>
                                <Badge className={
                                  user.role === 'owner' 
                                    ? 'bg-red-600/20 text-red-400 border-red-500/50' 
                                    : 'bg-orange-600/20 text-orange-400 border-orange-500/50'
                                }>
                                  {user.role}
                                </Badge>
                                {user.is_active ? (
                                  <CheckCircle className="h-4 w-4 text-green-400" />
                                ) : (
                                  <XCircle className="h-4 w-4 text-red-400" />
                                )}
                              </div>
                              <div className="text-sm text-gray-400">
                                Last access: {user.last_access ? new Date(user.last_access).toLocaleDateString() : 'Never'}
                              </div>
                            </div>
                          </div>
                          
                          {user.role !== 'owner' && user.is_active && (
                            <Button
                              onClick={() => handleBanUser(user.id)}
                              disabled={isLoading}
                              className="bg-red-600/20 border border-red-500/50 text-red-400 hover:bg-red-600/30"
                              size="sm"
                            >
                              Ban
                            </Button>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </TabsContent>

            <TabsContent value="logs" className="p-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h4 className="text-lg font-semibold text-white">Activity Logs ({logs.length})</h4>
                  <Button
                    onClick={fetchLogs}
                    disabled={isLoading}
                    className="bg-blue-600/20 border border-blue-500/50 text-blue-400 hover:bg-blue-600/30"
                    size="sm"
                  >
                    <RefreshCw className={`h-4 w-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
                    Refresh
                  </Button>
                </div>

                {logs.length === 0 ? (
                  <div className="text-center text-gray-400 py-8">No logs found.</div>
                ) : (
                  <div className="space-y-3 max-h-96 overflow-y-auto">
                    {logs.map((log) => (
                      <div key={log.id} className="bg-gray-800/40 rounded-lg p-4 border border-gray-700/40">
                        <div className="flex items-start justify-between">
                          <div className="flex items-start space-x-3 flex-1">
                            <div className="w-10 h-10 bg-gradient-to-br from-blue-500/20 to-purple-500/20 border border-blue-500/30 rounded-lg flex items-center justify-center">
                              <Activity className="h-4 w-4 text-blue-400" />
                            </div>
                            <div className="flex-1">
                              <div className="flex items-center space-x-2 mb-2">
                                <span className="text-white font-semibold">{log.staff_name}</span>
                                <Badge className={
                                  log.status === 'completed' ? 'bg-green-500/20 text-green-300 border-green-500/30' :
                                  log.status === 'pending' ? 'bg-amber-500/20 text-amber-300 border-amber-500/30' :
                                  'bg-red-500/20 text-red-300 border-red-500/30'
                                }>
                                  {log.status}
                                </Badge>
                              </div>
                              <p className="text-gray-300 font-medium mb-2">{log.action}</p>
                              <div className="text-xs text-gray-500">
                                {new Date(log.created_at).toLocaleString()}
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </TabsContent>

            <TabsContent value="applications" className="p-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h4 className="text-lg font-semibold text-white">Pending Applications ({applications.length})</h4>
                  <Button
                    onClick={fetchApplications}
                    disabled={isLoading}
                    className="bg-blue-600/20 border border-blue-500/50 text-blue-400 hover:bg-blue-600/30"
                    size="sm"
                  >
                    <RefreshCw className={`h-4 w-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
                    Refresh
                  </Button>
                </div>

                {applications.length === 0 ? (
                  <div className="text-center text-gray-400 py-8">No pending applications.</div>
                ) : (
                  <div className="space-y-4">
                    {applications.map((application) => (
                      <div key={application.id} className="bg-gray-800/40 rounded-lg p-4 border border-gray-700/40">
                        <div className="flex items-start justify-between">
                          <div className="flex items-center space-x-3">
                            <div className="w-10 h-10 bg-gradient-to-br from-blue-500/20 to-purple-500/20 border border-blue-500/30 rounded-full flex items-center justify-center">
                              <UserCheck className="h-5 w-5 text-blue-400" />
                            </div>
                            <div>
                              <p className="text-white font-medium">{application.discord}</p>
                              <div className="flex items-center space-x-2 mt-1">
                                <Badge className="border-orange-500/50 text-orange-400">
                                  {application.requested_role}
                                </Badge>
                                <div className="flex items-center space-x-1 text-xs text-gray-400">
                                  <Clock className="h-3 w-3" />
                                  <span>{new Date(application.submitted_at).toLocaleDateString()}</span>
                                </div>
                              </div>
                            </div>
                          </div>

                          <div className="flex items-center space-x-2">
                            <Button
                              onClick={() => handleReviewApplication(application.id, 'approve', 'admin')}
                              disabled={isLoading}
                              className="bg-green-600/20 border border-green-500/50 text-green-400 hover:bg-green-600/30"
                              size="sm"
                            >
                              <CheckCircle className="h-3 w-3 mr-1" />
                              Approve
                            </Button>
                            
                            <Button
                              onClick={() => handleReviewApplication(application.id, 'deny')}
                              disabled={isLoading}
                              className="bg-red-600/20 border border-red-500/50 text-red-400 hover:bg-red-600/30"
                              size="sm"
                            >
                              <XCircle className="h-3 w-3 mr-1" />
                              Reject
                            </Button>
                          </div>
                        </div>

                        {application.application_statement && (
                          <div className="mt-4 p-3 bg-gray-900/40 rounded-lg border border-gray-700/30">
                            <div className="flex items-center space-x-2 mb-2">
                              <AlertCircle className="h-4 w-4 text-gray-400" />
                              <span className="text-sm text-gray-400">Application Statement</span>
                            </div>
                            <p className="text-sm text-gray-300">{application.application_statement}</p>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
};

export default StaffTools;
