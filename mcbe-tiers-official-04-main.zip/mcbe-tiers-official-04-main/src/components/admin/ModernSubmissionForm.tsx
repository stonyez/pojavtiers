
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { Upload, User } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { calculatePoints } from '@/lib/pointsCalculation';
import { GameModeIcon } from '@/components/GameModeIcon';

interface GamemodeTier {
  gamemode: string;
  tier: string;
}

interface SubmissionForm {
  ign: string;
  java_username: string;
  region: string;
  device: string;
  gamemode_tiers: { [key: string]: string };
}

const gamemodes = ['Crystal', 'Sword', 'Axe', 'UHC', 'Mace', 'SMP', 'Bedwars', 'NethPot'];
// Updated regions - only NA, AS, EU
const regions = ['NA', 'EU', 'AS'];
const devices = ['Mobile', 'PC', 'Console'];
const tiers = ['RHT1', 'RLT1', 'RHT2', 'RLT2', 'HT1', 'LT1', 'HT2', 'LT2', 'HT3', 'LT3', 'HT4', 'LT4', 'HT5', 'LT5'];

export const ModernSubmissionForm = () => {
  const [form, setForm] = useState<SubmissionForm>({
    ign: '',
    java_username: '',
    region: '',
    device: '',
    gamemode_tiers: {}
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  const handleTierChange = (gamemode: string, tier: string) => {
    setForm({
      ...form,
      gamemode_tiers: {
        ...form.gamemode_tiers,
        [gamemode]: tier
      }
    });
  };

  const handleSubmit = async () => {
    if (!form.ign.trim()) {
      toast({
        title: "Validation Error",
        description: "Player IGN is required",
        variant: "destructive"
      });
      return;
    }

    const validTiers = Object.entries(form.gamemode_tiers).filter(([_, tier]) => tier);
    if (validTiers.length === 0) {
      toast({
        title: "Validation Error",
        description: "At least one gamemode tier is required",
        variant: "destructive"
      });
      return;
    }

    setIsSubmitting(true);
    try {
      // Search for existing player by IGN
      const { data: existingPlayer, error: searchError } = await supabase
        .from('players')
        .select('id')
        .eq('ign', form.ign.trim())
        .maybeSingle();

      if (searchError) {
        console.error('Error searching for player:', searchError);
        throw new Error('Failed to search for existing player');
      }

      let playerId: string;

      if (existingPlayer) {
        // Update existing player
        playerId = existingPlayer.id;
        const { error: updateError } = await supabase
          .from('players')
          .update({
            java_username: form.java_username.trim() || null,
            region: form.region as "NA" | "EU" | "AS" || null,
            device: form.device as "Mobile" | "PC" | "Console" || null,
            updated_at: new Date().toISOString()
          })
          .eq('id', playerId);

        if (updateError) throw updateError;
      } else {
        // Create new player
        const { data: newPlayer, error: createError } = await supabase
          .from('players')
          .insert({
            ign: form.ign.trim(),
            java_username: form.java_username.trim() || null,
            region: form.region as "NA" | "EU" | "AS" || null,
            device: form.device as "Mobile" | "PC" | "Console" || null,
            global_points: 0,
            banned: false
          })
          .select('id')
          .single();

        if (createError) throw createError;
        playerId = newPlayer.id;
      }

      // Submit gamemode scores with automatic point calculation
      for (const [gamemode, tier] of validTiers) {
        const points = calculatePoints(tier);
        const { error: scoreError } = await supabase
          .from('gamemode_scores')
          .upsert({
            player_id: playerId,
            gamemode: gamemode as "Crystal" | "Sword" | "Mace" | "Axe" | "SMP" | "UHC" | "NethPot" | "Bedwars",
            internal_tier: tier as any,
            display_tier: tier as any,
            points,
            updated_at: new Date().toISOString()
          });

        if (scoreError) throw scoreError;
      }

      // Reset form
      setForm({
        ign: '',
        java_username: '',
        region: '',
        device: '',
        gamemode_tiers: {}
      });

      toast({
        title: "Submission Successful",
        description: `Results submitted for ${form.ign} in ${validTiers.length} gamemode(s)`,
      });
    } catch (error: any) {
      toast({
        title: "Submission Failed",
        description: error.message,
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Card className="bg-gray-900/40 backdrop-blur-xl border-gray-700/50">
      <CardHeader>
        <CardTitle className="text-white flex items-center space-x-2">
          <Upload className="h-5 w-5 text-green-400" />
          <span>Result Submission System</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Player Information */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label className="text-gray-300 font-medium">IGN *</Label>
            <Input
              value={form.ign}
              onChange={(e) => setForm({ ...form, ign: e.target.value })}
              placeholder="Enter player IGN"
              className="bg-gray-800/60 border-gray-600/50 text-white"
            />
          </div>
          <div className="space-y-2">
            <Label className="text-gray-300 font-medium">Java IGN</Label>
            <div className="relative">
              <Input
                value={form.java_username}
                onChange={(e) => setForm({ ...form, java_username: e.target.value })}
                placeholder="Enter Java IGN"
                className="bg-gray-800/60 border-gray-600/50 text-white pl-10"
              />
              <User className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label className="text-gray-300 font-medium">Device</Label>
            <Select value={form.device} onValueChange={(value) => setForm({ ...form, device: value })}>
              <SelectTrigger className="bg-gray-800/60 border-gray-600/50 text-white">
                <SelectValue placeholder="Select device" />
              </SelectTrigger>
              <SelectContent className="bg-gray-800 border-gray-600">
                {devices.map(device => (
                  <SelectItem key={device} value={device}>{device}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label className="text-gray-300 font-medium">Region</Label>
            <Select value={form.region} onValueChange={(value) => setForm({ ...form, region: value })}>
              <SelectTrigger className="bg-gray-800/60 border-gray-600/50 text-white">
                <SelectValue placeholder="Select region" />
              </SelectTrigger>
              <SelectContent className="bg-gray-800 border-gray-600">
                {regions.map(region => (
                  <SelectItem key={region} value={region}>{region}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Gamemode Tiers */}
        <div className="space-y-4">
          <Label className="text-gray-300 font-medium text-lg">Gamemode Tiers</Label>
          
          {/* Top Row */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {gamemodes.slice(0, 4).map((gamemode) => (
              <div key={gamemode} className="space-y-2">
                <div className="flex items-center space-x-2">
                  <GameModeIcon mode={gamemode} className="h-5 w-5" />
                  <Label className="text-gray-300 text-sm">{gamemode}</Label>
                </div>
                <Select 
                  value={form.gamemode_tiers[gamemode] || ''}
                  onValueChange={(value) => handleTierChange(gamemode, value)}
                >
                  <SelectTrigger className="bg-gray-800/60 border-gray-600/50 text-white h-9">
                    <SelectValue placeholder="Select tier" />
                  </SelectTrigger>
                  <SelectContent className="bg-gray-800 border-gray-600">
                    <SelectItem value="no_tier">No tier</SelectItem>
                    {tiers.map(tier => (
                      <SelectItem key={tier} value={tier}>
                        {tier} ({calculatePoints(tier)} pts)
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            ))}
          </div>

          {/* Bottom Row */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {gamemodes.slice(4, 8).map((gamemode) => (
              <div key={gamemode} className="space-y-2">
                <div className="flex items-center space-x-2">
                  <GameModeIcon mode={gamemode} className="h-5 w-5" />
                  <Label className="text-gray-300 text-sm">{gamemode}</Label>
                </div>
                <Select 
                  value={form.gamemode_tiers[gamemode] || ''}
                  onValueChange={(value) => handleTierChange(gamemode, value)}
                >
                  <SelectTrigger className="bg-gray-800/60 border-gray-600/50 text-white h-9">
                    <SelectValue placeholder="Select tier" />
                  </SelectTrigger>
                  <SelectContent className="bg-gray-800 border-gray-600">
                    <SelectItem value="no_tier">No tier</SelectItem>
                    {tiers.map(tier => (
                      <SelectItem key={tier} value={tier}>
                        {tier} ({calculatePoints(tier)} pts)
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            ))}
          </div>
        </div>

        <Button
          onClick={handleSubmit}
          disabled={isSubmitting}
          className="w-full bg-green-600/20 border border-green-500/50 text-green-400 hover:bg-green-600/30 hover:border-green-400/60"
        >
          <Upload className="h-4 w-4 mr-2" />
          {isSubmitting ? 'Submitting...' : 'Submit Results'}
        </Button>
      </CardContent>
    </Card>
  );
};
