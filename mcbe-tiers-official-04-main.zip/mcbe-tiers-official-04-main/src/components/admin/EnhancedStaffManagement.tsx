
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Users, UserCheck, UserX, Shield, Circle, RotateCcw, Trash2 } from 'lucide-react';
import { cn } from '@/lib/utils';
import { staffOnboardingService } from '@/services/staffOnboardingService';

interface StaffMember {
  username: string;
  role: string;
  status: 'active' | 'offline';
  lastActive: string;
  firstLogin: string;
  deviceFingerprint: string;
}

export const EnhancedStaffManagement: React.FC = () => {
  const [activeStaff, setActiveStaff] = useState<StaffMember[]>([]);
  const [offlineStaff, setOfflineStaff] = useState<StaffMember[]>([]);
  const [currentUser, setCurrentUser] = useState(staffOnboardingService.getStaffData());

  useEffect(() => {
    loadStaffData();
    
    const interval = setInterval(loadStaffData, 30000);
    return () => clearInterval(interval);
  }, []);

  const loadStaffData = () => {
    const current = staffOnboardingService.getStaffData();
    setCurrentUser(current);

    const mockActiveStaff: StaffMember[] = [];
    const mockOfflineStaff: StaffMember[] = [];

    // Only add current user to active staff if they exist and are properly onboarded
    if (current && current.onboardingComplete) {
      mockActiveStaff.push({
        username: current.username,
        role: current.role,
        status: 'active',
        lastActive: current.lastActiveDate,
        firstLogin: current.firstLoginDate,
        deviceFingerprint: staffOnboardingService.getDeviceFingerprint()
      });
    }

    setActiveStaff(mockActiveStaff);
    setOfflineStaff(mockOfflineStaff);
  };

  const getRoleColor = (role: string): string => {
    switch (role.toLowerCase()) {
      case 'owner': return 'bg-red-500';
      case 'admin': return 'bg-purple-500';
      case 'moderator': return 'bg-blue-500';
      case 'tester': return 'bg-green-500';
      default: return 'bg-gray-500';
    }
  };

  const getRoleIcon = (role: string) => {
    return <Shield className="h-3 w-3" />;
  };

  const getInitials = (username: string): string => {
    return username.slice(0, 2).toUpperCase();
  };

  const handleResetAllSessions = () => {
    staffOnboardingService.resetAllSessions();
    setActiveStaff([]);
    setOfflineStaff([]);
    setCurrentUser(null);
    
    setTimeout(() => {
      window.location.reload();
    }, 1000);
  };

  const getTimeAgo = (dateString: string): string => {
    const now = new Date();
    const date = new Date(dateString);
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMins / 60);
    const diffDays = Math.floor(diffHours / 24);

    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffHours < 24) return `${diffHours}h ago`;
    return `${diffDays}d ago`;
  };

  const StaffCard: React.FC<{ member: StaffMember; showActions?: boolean }> = ({ member, showActions = false }) => (
    <Card className="p-4">
      <div className="flex items-center space-x-3">
        <div className={cn("h-10 w-10 rounded-full flex items-center justify-center relative", getRoleColor(member.role))}>
          <span className="text-white font-semibold text-sm">
            {getInitials(member.username)}
          </span>
          {member.status === 'active' && (
            <div className="absolute -bottom-0.5 -right-0.5 h-3 w-3 bg-green-500 border-2 border-background rounded-full" />
          )}
        </div>
        
        <div className="flex-1 min-w-0">
          <div className="flex items-center space-x-2">
            <p className="text-sm font-medium truncate">{member.username}</p>
            <Badge variant="outline" className="text-xs">
              {getRoleIcon(member.role)}
              <span className="ml-1 capitalize">{member.role}</span>
            </Badge>
          </div>
          
          <div className="flex items-center space-x-2 mt-1">
            <Circle className={cn("h-2 w-2", member.status === 'active' ? 'fill-green-500 text-green-500' : 'fill-gray-400 text-gray-400')} />
            <span className="text-xs text-muted-foreground">
              {member.status === 'active' ? 'Online' : `Offline • ${getTimeAgo(member.lastActive)}`}
            </span>
          </div>
        </div>
        
        {showActions && (
          <div className="flex items-center space-x-1">
            <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
              <Trash2 className="h-3 w-3" />
            </Button>
          </div>
        )}
      </div>
    </Card>
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Staff Management</h2>
          <p className="text-muted-foreground">Monitor active and offline staff members</p>
        </div>
        
        <div className="flex items-center space-x-2">
          <Button onClick={loadStaffData} variant="outline" size="sm">
            <RotateCcw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
          <Button onClick={handleResetAllSessions} variant="destructive" size="sm">
            <Trash2 className="h-4 w-4 mr-2" />
            Reset All Sessions
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Staff</CardTitle>
            <UserCheck className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{activeStaff.length}</div>
            <p className="text-xs text-muted-foreground">Currently online</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Offline Staff</CardTitle>
            <UserX className="h-4 w-4 text-gray-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-gray-600">{offlineStaff.length}</div>
            <p className="text-xs text-muted-foreground">Recently seen</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Staff</CardTitle>
            <Users className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">{activeStaff.length + offlineStaff.length}</div>
            <p className="text-xs text-muted-foreground">All registered</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="active" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="active" className="flex items-center space-x-2">
            <UserCheck className="h-4 w-4" />
            <span>Active Staff ({activeStaff.length})</span>
          </TabsTrigger>
          <TabsTrigger value="offline" className="flex items-center space-x-2">
            <UserX className="h-4 w-4" />
            <span>Offline Staff ({offlineStaff.length})</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="active" className="space-y-3">
          {activeStaff.length === 0 ? (
            <Card className="p-8 text-center">
              <UserCheck className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2">No Active Staff</h3>
              <p className="text-muted-foreground">No staff members are currently online</p>
            </Card>
          ) : (
            <div className="space-y-3">
              {activeStaff.map((member, index) => (
                <StaffCard key={index} member={member} showActions={false} />
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="offline" className="space-y-3">
          {offlineStaff.length === 0 ? (
            <Card className="p-8 text-center">
              <UserX className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2">No Offline Staff</h3>
              <p className="text-muted-foreground">No recently seen staff members</p>
            </Card>
          ) : (
            <div className="space-y-3">
              {offlineStaff.map((member, index) => (
                <StaffCard key={index} member={member} showActions={true} />
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
};
