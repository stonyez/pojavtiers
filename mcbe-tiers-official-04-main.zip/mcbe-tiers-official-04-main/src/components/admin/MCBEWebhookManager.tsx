
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Switch } from '@/components/ui/switch';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { 
  MessageSquare, 
  Trophy, 
  TestTube, 
  Save, 
  AlertCircle, 
  CheckCircle, 
  Clock,
  Activity,
  Settings
} from 'lucide-react';

interface WebhookConfig {
  id: string;
  webhook_type: 'tier' | 'logbox';
  webhook_url: string;
  is_active: boolean;
  last_tested_at?: string;
  test_status?: string;
}

interface WebhookLog {
  id: string;
  webhook_type: 'tier' | 'logbox';
  success: boolean;
  http_status?: number;
  delivery_time_ms?: number;
  sent_at: string;
}

const MCBEWebhookManager = () => {
  const [configs, setConfigs] = useState<WebhookConfig[]>([]);
  const [logs, setLogs] = useState<WebhookLog[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isTesting, setIsTesting] = useState<string | null>(null);
  const { toast } = useToast();

  const [tierUrl, setTierUrl] = useState('');
  const [logboxUrl, setLogboxUrl] = useState('');
  const [tierActive, setTierActive] = useState(true);
  const [logboxActive, setLogboxActive] = useState(true);

  useEffect(() => {
    loadConfigs();
    loadLogs();
  }, []);

  const loadConfigs = async () => {
    try {
      const { data, error } = await supabase
        .from('mcbe_webhook_configs')
        .select('*')
        .order('webhook_type');

      if (error) throw error;

      setConfigs(data || []);
      
      // Set form values
      const tierConfig = data?.find(c => c.webhook_type === 'tier');
      const logboxConfig = data?.find(c => c.webhook_type === 'logbox');
      
      setTierUrl(tierConfig?.webhook_url || '');
      setLogboxUrl(logboxConfig?.webhook_url || '');
      setTierActive(tierConfig?.is_active ?? true);
      setLogboxActive(logboxConfig?.is_active ?? true);
    } catch (error: any) {
      toast({
        title: "Error",
        description: `Failed to load webhook configs: ${error.message}`,
        variant: "destructive"
      });
    }
  };

  const loadLogs = async () => {
    try {
      const { data, error } = await supabase
        .from('mcbe_webhook_logs')
        .select('*')
        .order('sent_at', { ascending: false })
        .limit(20);

      if (error) throw error;
      setLogs(data || []);
    } catch (error: any) {
      console.error('Error loading logs:', error);
    }
  };

  const saveConfig = async (type: 'tier' | 'logbox', url: string, active: boolean) => {
    if (!url.trim()) {
      toast({
        title: "Validation Error",
        description: "Webhook URL cannot be empty",
        variant: "destructive"
      });
      return;
    }

    if (!isValidDiscordWebhook(url)) {
      toast({
        title: "Validation Error",
        description: "Please enter a valid Discord webhook URL",
        variant: "destructive"
      });
      return;
    }

    setIsLoading(true);
    try {
      const { error } = await supabase
        .from('mcbe_webhook_configs')
        .upsert({
          webhook_type: type,
          webhook_url: url,
          is_active: active,
          updated_at: new Date().toISOString()
        });

      if (error) throw error;

      toast({
        title: "Success",
        description: `${type.charAt(0).toUpperCase() + type.slice(1)} webhook configuration saved`,
      });

      loadConfigs();
    } catch (error: any) {
      toast({
        title: "Error",
        description: `Failed to save configuration: ${error.message}`,
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const testWebhook = async (type: 'tier' | 'logbox', url: string) => {
    if (!url.trim() || !isValidDiscordWebhook(url)) {
      toast({
        title: "Validation Error",
        description: "Please enter a valid Discord webhook URL first",
        variant: "destructive"
      });
      return;
    }

    setIsTesting(type);
    try {
      const { data, error } = await supabase.functions.invoke('webhook-management', {
        body: {
          action: 'test_webhook',
          data: { type, url }
        }
      });

      if (error) throw error;

      if (data.success) {
        toast({
          title: "Test Successful",
          description: "Test webhook sent successfully to Discord",
        });

        // Update test status
        await supabase
          .from('mcbe_webhook_configs')
          .update({
            last_tested_at: new Date().toISOString(),
            test_status: 'success'
          })
          .eq('webhook_type', type);
      } else {
        toast({
          title: "Test Failed",
          description: data.message || "Failed to send test webhook",
          variant: "destructive"
        });
      }

      loadConfigs();
    } catch (error: any) {
      toast({
        title: "Test Error",
        description: `Failed to test webhook: ${error.message}`,
        variant: "destructive"
      });
    } finally {
      setIsTesting(null);
    }
  };

  const isValidDiscordWebhook = (url: string): boolean => {
    return url.includes('discord.com/api/webhooks/') || url.includes('discordapp.com/api/webhooks/');
  };

  const getStatusBadge = (config: WebhookConfig) => {
    if (!config.is_active) {
      return <Badge variant="secondary">Disabled</Badge>;
    }

    if (config.test_status === 'success') {
      return <Badge className="bg-green-600/20 text-green-400 border-green-500/50">Active</Badge>;
    }

    if (config.last_tested_at) {
      return <Badge variant="destructive">Failed</Badge>;
    }

    return <Badge variant="outline">Untested</Badge>;
  };

  const formatTime = (timestamp: string) => {
    return new Date(timestamp).toLocaleString();
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center space-x-2">
        <Settings className="h-5 w-5 text-blue-400" />
        <h3 className="text-lg font-bold text-white">MCBE Webhook Management</h3>
        <Badge variant="outline" className="border-blue-600 text-blue-400">
          Live System
        </Badge>
      </div>

      <Card className="bg-gray-900/40 backdrop-blur-xl border-gray-700/50">
        <CardHeader>
          <CardTitle className="text-white">Webhook Configuration</CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="tier" className="w-full">
            <TabsList className="grid w-full grid-cols-3 bg-gray-800/50">
              <TabsTrigger value="tier" className="flex items-center space-x-2">
                <Trophy className="h-4 w-4" />
                <span>Tier Logs</span>
              </TabsTrigger>
              <TabsTrigger value="logbox" className="flex items-center space-x-2">
                <MessageSquare className="h-4 w-4" />
                <span>Logbox Logs</span>
              </TabsTrigger>
              <TabsTrigger value="monitoring" className="flex items-center space-x-2">
                <Activity className="h-4 w-4" />
                <span>Monitoring</span>
              </TabsTrigger>
            </TabsList>

            <TabsContent value="tier" className="space-y-4">
              <div className="space-y-4 p-4 bg-gray-800/30 rounded-lg">
                <div className="flex items-center justify-between">
                  <h4 className="text-white font-medium">Tier Logs Webhook</h4>
                  {configs.find(c => c.webhook_type === 'tier') && 
                    getStatusBadge(configs.find(c => c.webhook_type === 'tier')!)
                  }
                </div>
                
                <div className="space-y-3">
                  <div>
                    <label className="text-sm text-gray-400 block mb-2">Discord Webhook URL</label>
                    <Input
                      placeholder="https://discord.com/api/webhooks/..."
                      value={tierUrl}
                      onChange={(e) => setTierUrl(e.target.value)}
                      className="bg-gray-800/60 border-gray-600/50 text-white"
                    />
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Switch
                      checked={tierActive}
                      onCheckedChange={setTierActive}
                    />
                    <span className="text-sm text-gray-400">Enable tier logs webhook</span>
                  </div>

                  <div className="flex space-x-2">
                    <Button
                      onClick={() => saveConfig('tier', tierUrl, tierActive)}
                      disabled={isLoading}
                      className="bg-blue-600/20 border border-blue-500/50 text-blue-400 hover:bg-blue-600/30"
                    >
                      <Save className="h-4 w-4 mr-2" />
                      Save Configuration
                    </Button>
                    
                    <Button
                      onClick={() => testWebhook('tier', tierUrl)}
                      disabled={isTesting === 'tier' || !tierUrl}
                      variant="outline"
                      className="border-gray-600 text-gray-300 hover:bg-gray-700"
                    >
                      <TestTube className="h-4 w-4 mr-2" />
                      {isTesting === 'tier' ? 'Testing...' : 'Test Webhook'}
                    </Button>
                  </div>
                </div>

                <div className="text-xs text-gray-500 p-3 bg-gray-900/50 rounded">
                  <strong>Tier Logs:</strong> Automatically triggered when players earn or update their tier results. 
                  Messages include player IGN, game mode, tier, and player skin thumbnail.
                </div>
              </div>
            </TabsContent>

            <TabsContent value="logbox" className="space-y-4">
              <div className="space-y-4 p-4 bg-gray-800/30 rounded-lg">
                <div className="flex items-center justify-between">
                  <h4 className="text-white font-medium">Logbox Logs Webhook</h4>
                  {configs.find(c => c.webhook_type === 'logbox') && 
                    getStatusBadge(configs.find(c => c.webhook_type === 'logbox')!)
                  }
                </div>
                
                <div className="space-y-3">
                  <div>
                    <label className="text-sm text-gray-400 block mb-2">Discord Webhook URL</label>
                    <Input
                      placeholder="https://discord.com/api/webhooks/..."
                      value={logboxUrl}
                      onChange={(e) => setLogboxUrl(e.target.value)}
                      className="bg-gray-800/60 border-gray-600/50 text-white"
                    />
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Switch
                      checked={logboxActive}
                      onCheckedChange={setLogboxActive}
                    />
                    <span className="text-sm text-gray-400">Enable logbox logs webhook</span>
                  </div>

                  <div className="flex space-x-2">
                    <Button
                      onClick={() => saveConfig('logbox', logboxUrl, logboxActive)}
                      disabled={isLoading}
                      className="bg-blue-600/20 border border-blue-500/50 text-blue-400 hover:bg-blue-600/30"
                    >
                      <Save className="h-4 w-4 mr-2" />
                      Save Configuration
                    </Button>
                    
                    <Button
                      onClick={() => testWebhook('logbox', logboxUrl)}
                      disabled={isTesting === 'logbox' || !logboxUrl}
                      variant="outline"
                      className="border-gray-600 text-gray-300 hover:bg-gray-700"
                    >
                      <TestTube className="h-4 w-4 mr-2" />
                      {isTesting === 'logbox' ? 'Testing...' : 'Test Webhook'}
                    </Button>
                  </div>
                </div>

                <div className="text-xs text-gray-500 p-3 bg-gray-900/50 rounded">
                  <strong>Logbox Logs:</strong> Real-time forwarding of all system logs exactly as they appear internally. 
                  Includes info, warning, and error logs from the Black Box Monitor.
                </div>
              </div>
            </TabsContent>

            <TabsContent value="monitoring" className="space-y-4">
              <div className="space-y-4">
                <h4 className="text-white font-medium">Recent Webhook Activity</h4>
                
                <div className="grid gap-2 max-h-64 overflow-y-auto">
                  {logs.map((log) => (
                    <div key={log.id} className="flex items-center justify-between p-3 bg-gray-800/30 rounded">
                      <div className="flex items-center space-x-3">
                        {log.webhook_type === 'tier' ? (
                          <Trophy className="h-4 w-4 text-yellow-400" />
                        ) : (
                          <MessageSquare className="h-4 w-4 text-blue-400" />
                        )}
                        
                        <div>
                          <span className="text-white text-sm font-medium capitalize">
                            {log.webhook_type} Webhook
                          </span>
                          <div className="text-xs text-gray-400">
                            {formatTime(log.sent_at)}
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex items-center space-x-2">
                        {log.delivery_time_ms && (
                          <span className="text-xs text-gray-400">
                            {log.delivery_time_ms}ms
                          </span>
                        )}
                        
                        {log.success ? (
                          <CheckCircle className="h-4 w-4 text-green-400" />
                        ) : (
                          <AlertCircle className="h-4 w-4 text-red-400" />
                        )}
                        
                        <Badge variant={log.success ? "default" : "destructive"} className="text-xs">
                          {log.http_status || 'N/A'}
                        </Badge>
                      </div>
                    </div>
                  ))}
                  
                  {logs.length === 0 && (
                    <div className="text-center text-gray-400 py-8">
                      No webhook activity yet
                    </div>
                  )}
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      <div className="text-xs text-gray-500 text-center">
        Webhook system operates 24/7 independently • Real-time delivery • Automatic retry with exponential backoff
      </div>
    </div>
  );
};

export default MCBEWebhookManager;
