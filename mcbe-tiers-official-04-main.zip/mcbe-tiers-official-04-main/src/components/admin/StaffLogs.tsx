
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { newAdminService } from '@/services/newAdminService';
import { staffLoggingService } from '@/services/staffLoggingService';
import { useStaffLogging } from '@/hooks/useStaffLogging';
import { MobileOptimizedPopup } from '@/components/ui/MobileOptimizedPopup';
import { 
  FileText, 
  Check, 
  X, 
  Clock, 
  User,
  RefreshCw,
  Activity,
  Shield,
  AlertTriangle
} from 'lucide-react';

const StaffLogs = () => {
  const [approvalRemarks, setApprovalRemarks] = useState('');
  const [selectedLogId, setSelectedLogId] = useState<string | null>(null);
  const [showRemarksModal, setShowRemarksModal] = useState(false);
  const [actionType, setActionType] = useState<'approve' | 'deny'>('approve');
  
  const { 
    logs, 
    pendingApprovals, 
    isLoading, 
    refreshLogs, 
    approveOperation, 
    denyOperation 
  } = useStaffLogging();
  
  const { toast } = useToast();

  console.log('StaffLogs component - checking permissions');
  console.log('Current role:', newAdminService.getCurrentRole());
  console.log('Can view staff logs:', newAdminService.canViewStaffLogs());
  console.log('Is owner:', newAdminService.isOwner());

  // Check if user has permission to view staff logs
  if (!newAdminService.canViewStaffLogs()) {
    return (
      <div className="text-center py-12">
        <div className="mx-auto w-24 h-24 bg-gradient-to-br from-red-500/20 to-orange-500/20 rounded-2xl flex items-center justify-center mb-6">
          <Shield className="h-12 w-12 text-red-400" />
        </div>
        <h3 className="text-xl font-bold text-white mb-2">Access Restricted</h3>
        <p className="text-gray-400">Staff Logs are only available to authorized administrators.</p>
        <p className="text-gray-500 text-sm mt-2">Current role: {newAdminService.getCurrentRole() || 'None'}</p>
      </div>
    );
  }

  const handleLogAction = async (logId: string, action: 'approve' | 'deny') => {
    // Only owners can approve/deny operations
    if (!newAdminService.isOwner()) {
      toast({
        title: "Access Denied",
        description: "Only owners can approve or deny staff operations.",
        variant: "destructive"
      });
      return;
    }

    setSelectedLogId(logId);
    setActionType(action);
    setShowRemarksModal(true);
  };

  const executeAction = async () => {
    if (!selectedLogId) return;

    try {
      let result;
      if (actionType === 'approve') {
        result = await approveOperation(selectedLogId, approvalRemarks);
      } else {
        result = await denyOperation(selectedLogId, approvalRemarks);
      }

      if (result.success) {
        toast({
          title: actionType === 'approve' ? "Operation Approved" : "Operation Denied",
          description: `Staff operation has been ${actionType === 'approve' ? 'approved' : 'denied'}.`,
        });
      }
    } catch (error: any) {
      toast({
        title: "Action Failed",
        description: `Failed to ${actionType} operation: ${error.message}`,
        variant: "destructive"
      });
    } finally {
      setShowRemarksModal(false);
      setSelectedLogId(null);
      setApprovalRemarks('');
    }
  };

  useEffect(() => {
    console.log('StaffLogs useEffect - fetching logs');
    refreshLogs();
  }, [refreshLogs]);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'approved':
        return 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30';
      case 'denied':
        return 'bg-red-500/20 text-red-300 border border-red-500/30';
      case 'pending':
        return 'bg-amber-500/20 text-amber-300 border border-amber-500/30';
      case 'error':
        return 'bg-orange-500/20 text-orange-300 border border-orange-500/30';
      default:
        return 'bg-gray-500/20 text-gray-300 border border-gray-500/30';
    }
  };

  const getActionIcon = (action: string) => {
    if (action.includes('Tier')) return <Activity className="h-4 w-4" />;
    if (action.includes('Result')) return <FileText className="h-4 w-4" />;
    if (action.includes('Player')) return <User className="h-4 w-4" />;
    return <FileText className="h-4 w-4" />;
  };

  return (
    <div className="space-y-6">
      {/* Header Section */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <div className="w-12 h-12 bg-gradient-to-br from-blue-500/20 to-purple-500/20 rounded-xl border border-blue-500/30 flex items-center justify-center">
            <FileText className="h-6 w-6 text-blue-400" />
          </div>
          <div>
            <h3 className="text-2xl font-bold text-white">Staff Activity Logs</h3>
            <p className="text-gray-400">Monitor and review verified staff actions</p>
          </div>
        </div>

        <Button
          onClick={refreshLogs}
          disabled={isLoading}
          className="bg-blue-600/20 border border-blue-500/50 text-blue-400 hover:bg-blue-600/30 transition-all duration-200"
        >
          <RefreshCw className={`h-4 w-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
          Refresh
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-gradient-to-br from-blue-500/10 to-blue-600/10 border-blue-500/20">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-blue-300 text-sm font-medium">Total Logs</p>
                <p className="text-2xl font-bold text-white">{logs.length}</p>
              </div>
              <FileText className="h-8 w-8 text-blue-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-amber-500/10 to-amber-600/10 border-amber-500/20">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-amber-300 text-sm font-medium">Pending</p>
                <p className="text-2xl font-bold text-white">{pendingApprovals.length}</p>
              </div>
              <Clock className="h-8 w-8 text-amber-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-emerald-500/10 to-emerald-600/10 border-emerald-500/20">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-emerald-300 text-sm font-medium">Approved</p>
                <p className="text-2xl font-bold text-white">{logs.filter(l => l.status === 'approved').length}</p>
              </div>
              <Check className="h-8 w-8 text-emerald-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-red-500/10 to-red-600/10 border-red-500/20">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-red-300 text-sm font-medium">Denied</p>
                <p className="text-2xl font-bold text-white">{logs.filter(l => l.status === 'denied').length}</p>
              </div>
              <X className="h-8 w-8 text-red-400" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Logs List */}
      <Card className="bg-gray-900/40 backdrop-blur-xl border-gray-700/50">
        <CardHeader className="pb-3">
          <CardTitle className="text-white text-lg flex items-center">
            <Activity className="h-5 w-5 mr-2" />
            Recent Activity {newAdminService.isOwner() && pendingApprovals.length > 0 && (
              <Badge className="ml-2 bg-amber-500/20 text-amber-300">
                {pendingApprovals.length} Pending
              </Badge>
            )}
          </CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="text-center text-gray-400 py-12">
              <RefreshCw className="h-8 w-8 animate-spin mx-auto mb-4" />
              Loading staff logs...
            </div>
          ) : logs.length === 0 ? (
            <div className="text-center text-gray-400 py-12">
              <FileText className="h-8 w-8 mx-auto mb-4 opacity-50" />
              No staff activities found.
            </div>
          ) : (
            <div className="space-y-3 max-h-96 overflow-y-auto">
              {logs.map((log) => (
                <div key={log.log_id} className="bg-gray-800/40 rounded-xl p-4 border border-gray-700/40 hover:border-gray-600/50 transition-all duration-200">
                  <div className="flex items-start justify-between">
                    <div className="flex items-start space-x-3 flex-1">
                      <div className="w-10 h-10 bg-gradient-to-br from-blue-500/20 to-purple-500/20 border border-blue-500/30 rounded-xl flex items-center justify-center flex-shrink-0">
                        {getActionIcon(log.operation_type)}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center space-x-2 mb-2">
                          <span className="text-white font-semibold">{log.username}</span>
                          <Badge className={`text-xs px-2 py-1 ${getStatusColor(log.status)}`}>
                            {log.status}
                          </Badge>
                          {log.error_flag && (
                            <Badge className="text-xs px-2 py-1 bg-orange-500/20 text-orange-300">
                              <AlertTriangle className="h-3 w-3 mr-1" />
                              Error
                            </Badge>
                          )}
                        </div>
                        <p className="text-gray-300 font-medium mb-2">{log.operation_type}</p>
                        {log.operation_details && typeof log.operation_details === 'object' && (
                          <div className="text-sm text-gray-400 space-y-1 mb-3">
                            {Object.entries(log.operation_details).slice(0, 3).map(([key, value]) => (
                              <div key={key} className="flex">
                                <span className="font-medium min-w-[80px]">{key}:</span>
                                <span className="text-gray-300 truncate">{String(value)}</span>
                              </div>
                            ))}
                          </div>
                        )}
                        {log.owner_remarks && (
                          <div className="text-sm text-blue-300 bg-blue-500/10 rounded p-2 mb-2">
                            <span className="font-medium">Owner Remarks:</span> {log.owner_remarks}
                          </div>
                        )}
                        <div className="text-xs text-gray-500">
                          {new Date(log.timestamp).toLocaleString()}
                          {log.executed_at && (
                            <span className="ml-2">• Executed: {new Date(log.executed_at).toLocaleString()}</span>
                          )}
                        </div>
                      </div>
                    </div>
                    
                    {log.status === 'pending' && newAdminService.isOwner() && (
                      <div className="flex items-center space-x-2 flex-shrink-0 ml-4">
                        <Button
                          onClick={() => handleLogAction(log.log_id, 'approve')}
                          size="sm"
                          className="bg-emerald-600/20 border border-emerald-500/50 text-emerald-400 hover:bg-emerald-600/30 transition-all duration-200"
                        >
                          <Check className="h-3 w-3" />
                        </Button>
                        <Button
                          onClick={() => handleLogAction(log.log_id, 'deny')}
                          size="sm"
                          className="bg-red-600/20 border border-red-500/50 text-red-400 hover:bg-red-600/30 transition-all duration-200"
                        >
                          <X className="h-3 w-3" />
                        </Button>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Approval/Denial Modal */}
      <MobileOptimizedPopup
        isOpen={showRemarksModal}
        onClose={() => {
          setShowRemarksModal(false);
          setApprovalRemarks('');
          setSelectedLogId(null);
        }}
        title={`${actionType === 'approve' ? 'Approve' : 'Deny'} Operation`}
      >
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Remarks (Optional)
            </label>
            <textarea
              value={approvalRemarks}
              onChange={(e) => setApprovalRemarks(e.target.value)}
              placeholder={`Add remarks for this ${actionType}...`}
              className="w-full p-3 bg-gray-800/50 border border-gray-600/50 rounded-lg text-white placeholder-gray-400 focus:border-blue-500/50"
              rows={3}
            />
          </div>
          <div className="flex space-x-3">
            <Button
              onClick={executeAction}
              className={`flex-1 ${
                actionType === 'approve' 
                  ? 'bg-emerald-600 hover:bg-emerald-700' 
                  : 'bg-red-600 hover:bg-red-700'
              }`}
            >
              {actionType === 'approve' ? 'Approve' : 'Deny'}
            </Button>
            <Button
              onClick={() => {
                setShowRemarksModal(false);
                setApprovalRemarks('');
                setSelectedLogId(null);
              }}
              variant="outline"
              className="flex-1"
            >
              Cancel
            </Button>
          </div>
        </div>
      </MobileOptimizedPopup>
    </div>
  );
};

export default StaffLogs;
