import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { 
  Archive, 
  Download, 
  FileText, 
  Settings, 
  Trash2, 
  Clock,
  AlertTriangle,
  CheckCircle,
  RefreshCw
} from 'lucide-react';

interface BackupFile {
  name: string;
  created_at: string;
  updated_at: string;
  last_accessed_at: string;
  metadata: any;
  id: string;
}

interface BackupResult {
  success: boolean;
  backup_name?: string;
  data?: any;
  error?: string;
}

interface BackupManagerProps {
  activeOperation?: string;
}

const BackupManager: React.FC<BackupManagerProps> = ({ activeOperation }) => {
  const [isLoading, setIsLoading] = useState(false);
  const [backupFiles, setBackupFiles] = useState<BackupFile[]>([]);
  const [autoBackupEnabled, setAutoBackupEnabled] = useState(true);
  const [lastBackupDate, setLastBackupDate] = useState<string | null>(null);
  const { toast } = useToast();

  const fetchBackupFiles = async () => {
    try {
      const { data, error } = await supabase.storage
        .from('backups')
        .list('', {
          limit: 20,
          offset: 0,
          sortBy: { column: 'updated_at', order: 'desc' }
        });

      if (error) throw error;
      setBackupFiles(data || []);
    } catch (error: any) {
      console.error('Error fetching backup files:', error);
      toast({
        title: "Fetch Failed",
        description: `Failed to fetch backup files: ${error.message}`,
        variant: "destructive"
      });
    }
  };

  const createBackup = async () => {
    setIsLoading(true);
    try {
      const { data: backupResult, error: backupError } = await supabase
        .rpc('create_daily_backup');

      if (backupError) throw backupError;

      // Type assertion to properly handle the Json type
      const result = backupResult as unknown as BackupResult;
      if (!result?.success) {
        throw new Error('Failed to generate backup data');
      }

      // Delete old backup file
      await supabase.storage
        .from('backups')
        .remove(['latest-backup.json']);

      // Upload new backup
      const backupData = JSON.stringify(result.data, null, 2);
      const { error: uploadError } = await supabase.storage
        .from('backups')
        .upload('latest-backup.json', new Blob([backupData], { type: 'application/json' }), {
          cacheControl: '3600',
          upsert: true
        });

      if (uploadError) throw uploadError;

      setLastBackupDate(new Date().toISOString());
      await fetchBackupFiles();
      
      toast({
        title: "Backup Created",
        description: "Database backup created and uploaded successfully",
      });
    } catch (error: any) {
      toast({
        title: "Backup Failed",
        description: `Failed to create backup: ${error.message}`,
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const downloadBackup = async (fileName: string = 'latest-backup.json') => {
    setIsLoading(true);
    try {
      const { data, error } = await supabase.storage
        .from('backups')
        .download(fileName);

      if (error) throw error;

      const url = window.URL.createObjectURL(data);
      const a = document.createElement('a');
      a.href = url;
      a.download = fileName;
      a.click();
      window.URL.revokeObjectURL(url);

      toast({
        title: "Download Complete",
        description: `${fileName} downloaded successfully`,
      });
    } catch (error: any) {
      toast({
        title: "Download Failed",
        description: `Failed to download backup: ${error.message}`,
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const deleteBackupFile = async (fileName: string) => {
    if (!confirm(`Are you sure you want to delete ${fileName}? This action cannot be undone.`)) {
      return;
    }

    setIsLoading(true);
    try {
      const { error } = await supabase.storage
        .from('backups')
        .remove([fileName]);

      if (error) throw error;

      await fetchBackupFiles();
      toast({
        title: "File Deleted",
        description: `${fileName} has been deleted successfully`,
      });
    } catch (error: any) {
      toast({
        title: "Delete Failed",
        description: `Failed to delete file: ${error.message}`,
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const exportToCSV = async () => {
    setIsLoading(true);
    try {
      const { data: players, error } = await supabase
        .from('players')
        .select('*')
        .order('overall_rank', { ascending: true });

      if (error) throw error;

      const csv = [
        ['IGN', 'Java Username', 'UUID', 'Region', 'Device', 'Global Points', 'Rank', 'Banned', 'Created At'].join(','),
        ...(players || []).map(player => [
          player.ign,
          player.java_username || '',
          player.uuid || '',
          player.region || '',
          player.device || '',
          player.global_points,
          player.overall_rank || '',
          player.banned ? 'Yes' : 'No',
          new Date(player.created_at).toLocaleDateString()
        ].join(','))
      ].join('\n');

      const blob = new Blob([csv], { type: 'text/csv' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `players_export_${new Date().toISOString().split('T')[0]}.csv`;
      a.click();
      window.URL.revokeObjectURL(url);

      toast({
        title: "Export Successful",
        description: "Player data has been exported to CSV",
      });
    } catch (error: any) {
      toast({
        title: "Export Failed",
        description: `Failed to export data: ${error.message}`,
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchBackupFiles();
    const lastBackup = localStorage.getItem('last-backup-date');
    if (lastBackup) {
      setLastBackupDate(lastBackup);
    }
  }, []);

  if (activeOperation === 'db-export' || activeOperation === 'db-download') {
    return (
      <div className="space-y-6">
        <div className="text-center space-y-4">
          <div className="flex items-center justify-center space-x-4">
            <FileText className="h-12 w-12 text-green-400" />
            <Download className="h-8 w-8 text-gray-400" />
          </div>
          <h3 className="text-xl font-semibold text-white">Export & Download Center</h3>
          <p className="text-gray-400">Export player data to CSV or download existing backups</p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              onClick={exportToCSV}
              disabled={isLoading}
              className="bg-green-600/20 border border-green-500/50 text-green-400 hover:bg-green-600/30"
            >
              <FileText className="h-4 w-4 mr-2" />
              {isLoading ? 'Exporting...' : 'Export to CSV'}
            </Button>
            
            <Button
              onClick={() => downloadBackup()}
              disabled={isLoading}
              className="bg-blue-600/20 border border-blue-500/50 text-blue-400 hover:bg-blue-600/30"
            >
              <Download className="h-4 w-4 mr-2" />
              {isLoading ? 'Downloading...' : 'Download Latest Backup'}
            </Button>
          </div>
        </div>

        {backupFiles.length > 0 && (
          <Card className="bg-gray-800/30 border-gray-700/40">
            <CardHeader className="pb-3">
              <CardTitle className="text-white text-sm flex items-center space-x-2">
                <Archive className="h-4 w-4" />
                <span>Available Backup Files</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 max-h-48 overflow-y-auto">
                {backupFiles.map((file) => (
                  <div key={file.id} className="flex items-center justify-between p-2 bg-gray-700/30 rounded border border-gray-600/40">
                    <div className="flex-1 min-w-0">
                      <p className="text-white text-sm truncate">{file.name}</p>
                      <p className="text-gray-400 text-xs">
                        {new Date(file.updated_at).toLocaleString()}
                      </p>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Button
                        onClick={() => downloadBackup(file.name)}
                        size="sm"
                        className="bg-blue-600/20 border border-blue-500/50 text-blue-400 hover:bg-blue-600/30"
                      >
                        <Download className="h-3 w-3" />
                      </Button>
                      <Button
                        onClick={() => deleteBackupFile(file.name)}
                        size="sm"
                        className="bg-red-600/20 border border-red-500/50 text-red-400 hover:bg-red-600/30"
                      >
                        <Trash2 className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="text-center space-y-4">
        <Archive className="h-12 w-12 mx-auto text-purple-400" />
        <h3 className="text-xl font-semibold text-white">Backup Management</h3>
        <p className="text-gray-400">Create, manage, and configure automatic database backups</p>
      </div>

      {/* Auto Backup Settings */}
      <Card className="bg-gray-800/30 border-gray-700/40">
        <CardHeader className="pb-3">
          <CardTitle className="text-white text-sm flex items-center space-x-2">
            <Settings className="h-4 w-4" />
            <span>Automatic Backup Settings</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-white text-sm">Daily Auto Backup</p>
              <p className="text-gray-400 text-xs">Automatically create backups every 24 hours</p>
            </div>
            <div className={`w-12 h-6 rounded-full ${autoBackupEnabled ? 'bg-green-600' : 'bg-gray-600'} relative cursor-pointer`}
                 onClick={() => setAutoBackupEnabled(!autoBackupEnabled)}>
              <div className={`w-5 h-5 bg-white rounded-full absolute top-0.5 transition-transform ${autoBackupEnabled ? 'translate-x-6' : 'translate-x-0.5'}`} />
            </div>
          </div>
          
          {lastBackupDate && (
            <div className="flex items-center space-x-2 text-sm">
              <Clock className="h-4 w-4 text-gray-400" />
              <span className="text-gray-400">Last backup:</span>
              <span className="text-white">{new Date(lastBackupDate).toLocaleString()}</span>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Manual Backup Controls */}
      <div className="flex flex-col sm:flex-row gap-4">
        <Button
          onClick={createBackup}
          disabled={isLoading}
          className="flex-1 bg-purple-600/20 border border-purple-500/50 text-purple-400 hover:bg-purple-600/30"
        >
          <Archive className="h-4 w-4 mr-2" />
          {isLoading ? 'Creating Backup...' : 'Create Backup Now'}
        </Button>
        
        <Button
          onClick={fetchBackupFiles}
          disabled={isLoading}
          className="flex-1 bg-blue-600/20 border border-blue-500/50 text-blue-400 hover:bg-blue-600/30"
        >
          <RefreshCw className="h-4 w-4 mr-2" />
          Refresh Files
        </Button>
      </div>

      {/* Backup Files List */}
      {backupFiles.length > 0 && (
        <Card className="bg-gray-800/30 border-gray-700/40">
          <CardHeader className="pb-3">
            <CardTitle className="text-white text-sm flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Archive className="h-4 w-4" />
                <span>Stored Backup Files ({backupFiles.length})</span>
              </div>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 max-h-64 overflow-y-auto">
              {backupFiles.map((file) => (
                <div key={file.id} className="flex items-center justify-between p-3 bg-gray-700/30 rounded border border-gray-600/40">
                  <div className="flex-1 min-w-0">
                    <p className="text-white text-sm font-medium truncate">{file.name}</p>
                    <p className="text-gray-400 text-xs">
                      Created: {new Date(file.updated_at).toLocaleString()}
                    </p>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Button
                      onClick={() => downloadBackup(file.name)}
                      size="sm"
                      className="bg-blue-600/20 border border-blue-500/50 text-blue-400 hover:bg-blue-600/30"
                    >
                      <Download className="h-3 w-3" />
                    </Button>
                    <Button
                      onClick={() => deleteBackupFile(file.name)}
                      size="sm"
                      className="bg-red-600/20 border border-red-500/50 text-red-400 hover:bg-red-600/30"
                    >
                      <Trash2 className="h-3 w-3" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default BackupManager;
