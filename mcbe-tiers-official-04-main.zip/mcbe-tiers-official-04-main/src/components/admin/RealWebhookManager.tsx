
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { enhancedWebhookService } from '@/services/enhancedWebhookService';
import { MessageSquare, TestTube, Save, AlertCircle, CheckCircle, RefreshCw } from 'lucide-react';

const RealWebhookManager = () => {
  const [tierWebhookUrl, setTierWebhookUrl] = useState('');
  const [logboxWebhookUrl, setLogboxWebhookUrl] = useState('');
  const [isTestingTier, setIsTestingTier] = useState(false);
  const [isTestingLogbox, setIsTestingLogbox] = useState(false);
  const [isSavingTier, setIsSavingTier] = useState(false);
  const [isSavingLogbox, setIsSavingLogbox] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [serviceHealth, setServiceHealth] = useState(null);
  const { toast } = useToast();

  useEffect(() => {
    loadCurrentConfigs();
    // Refresh configs every 30 seconds to ensure sync
    const interval = setInterval(loadCurrentConfigs, 30000);
    return () => clearInterval(interval);
  }, []);

  const loadCurrentConfigs = async () => {
    try {
      setIsLoading(true);
      console.log('Loading current webhook configurations...');
      
      // Force refresh to get latest data
      await enhancedWebhookService.forceReloadConfigs();
      
      const configs = await enhancedWebhookService.getConfigs();
      const tierConfig = configs.find(c => c.webhook_type === 'tier');
      const logboxConfig = configs.find(c => c.webhook_type === 'logbox');
      
      setTierWebhookUrl(tierConfig?.webhook_url || '');
      setLogboxWebhookUrl(logboxConfig?.webhook_url || '');
      
      // Get service health
      const health = enhancedWebhookService.getServiceHealth();
      setServiceHealth(health);
      
      console.log('Loaded configurations:', { tierConfig, logboxConfig, health });
    } catch (error) {
      console.error('Error loading webhook configs:', error);
      toast({
        title: "Loading Error",
        description: "Failed to load webhook configurations",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleSaveWebhookUrl = async (type: 'tier' | 'logbox') => {
    const setSaving = type === 'tier' ? setIsSavingTier : setIsSavingLogbox;
    const url = type === 'tier' ? tierWebhookUrl : logboxWebhookUrl;
    
    if (!url.trim()) {
      toast({
        title: "Validation Error",
        description: "Please enter a webhook URL",
        variant: "destructive"
      });
      return;
    }

    setSaving(true);
    try {
      console.log(`Saving ${type} webhook URL:`, url);
      
      const result = await enhancedWebhookService.updateWebhookUrl(type, url.trim());
      
      if (result.success) {
        toast({
          title: "Success",
          description: `${type.charAt(0).toUpperCase() + type.slice(1)} webhook URL saved successfully`,
        });
        
        // Reload configurations to verify save
        await loadCurrentConfigs();
      } else {
        toast({
          title: "Save Failed",
          description: result.error || "Failed to save webhook URL",
          variant: "destructive"
        });
      }
    } catch (error) {
      console.error('Error saving webhook URL:', error);
      toast({
        title: "Error",
        description: "An unexpected error occurred while saving",
        variant: "destructive"
      });
    } finally {
      setSaving(false);
    }
  };

  const handleTestWebhook = async (type: 'tier' | 'logbox') => {
    const setTesting = type === 'tier' ? setIsTestingTier : setIsTestingLogbox;
    
    setTesting(true);
    try {
      console.log(`Testing ${type} webhook...`);
      
      const result = await enhancedWebhookService.testWebhook(type);
      
      toast({
        title: result.success ? "Test Successful" : "Test Failed",
        description: result.message,
        variant: result.success ? "default" : "destructive"
      });
      
      if (result.success) {
        // Refresh health status
        const health = enhancedWebhookService.getServiceHealth();
        setServiceHealth(health);
      }
    } catch (error) {
      console.error('Error testing webhook:', error);
      toast({
        title: "Test Error",
        description: "An error occurred while testing the webhook",
        variant: "destructive"
      });
    } finally {
      setTesting(false);
    }
  };

  const isValidDiscordUrl = (url: string) => {
    const patterns = [
      /^https:\/\/discord\.com\/api\/webhooks\/\d+\/[\w-]+\/?$/,
      /^https:\/\/discordapp\.com\/api\/webhooks\/\d+\/[\w-]+\/?$/,
    ];
    return patterns.some(pattern => pattern.test(url));
  };

  const getValidationStatus = (url: string) => {
    if (!url) return { valid: false, message: 'URL required' };
    if (isValidDiscordUrl(url)) return { valid: true, message: 'Valid Discord webhook' };
    return { valid: false, message: 'Invalid Discord webhook URL' };
  };

  const tierValidation = getValidationStatus(tierWebhookUrl);
  const logboxValidation = getValidationStatus(logboxWebhookUrl);

  if (isLoading) {
    return (
      <div className="space-y-3">
        <div className="flex items-center space-x-2">
          <RefreshCw className="h-4 w-4 text-purple-400 animate-spin" />
          <h4 className="text-base font-bold text-white">Loading Webhook Configuration...</h4>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <MessageSquare className="h-4 w-4 text-purple-400" />
          <h4 className="text-base font-bold text-white">Discord Webhooks</h4>
          <Badge variant="outline" className="border-green-600 text-green-400 text-xs">
            <CheckCircle className="h-3 w-3 mr-1" />
            Enhanced & Fixed
          </Badge>
        </div>
        <Button
          onClick={loadCurrentConfigs}
          size="sm"
          variant="outline"
          className="border-gray-600 text-gray-300 hover:bg-gray-700 h-6 px-2 text-xs"
        >
          <RefreshCw className="h-3 w-3 mr-1" />
          Refresh
        </Button>
      </div>

      {serviceHealth && (
        <div className="text-xs text-gray-400 bg-gray-800/30 rounded p-2">
          <strong>Service Status:</strong> {serviceHealth.isInitialized ? 'Ready' : 'Initializing'} • 
          Configs: {serviceHealth.configCount} • 
          Queue: {serviceHealth.retryQueueSize} • 
          Active: Tier({serviceHealth.activeConfigs.tier ? '✓' : '✗'}) Logbox({serviceHealth.activeConfigs.logbox ? '✓' : '✗'})
        </div>
      )}

      <div className="grid gap-3">
        {/* Tier Webhook Configuration */}
        <Card className="bg-gray-800/50 border-gray-600/50">
          <CardHeader className="pb-3">
            <CardTitle className="text-white text-sm flex items-center">
              🎖️ Tier Updates Webhook
              <Badge 
                variant="outline" 
                className={`ml-2 text-xs ${
                  tierValidation.valid 
                    ? 'border-green-600 text-green-400' 
                    : 'border-red-600 text-red-400'
                }`}
              >
                {tierValidation.valid ? 'Valid' : 'Invalid'}
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="space-y-2">
              <label className="text-xs text-gray-300">Discord Webhook URL</label>
              <Input
                value={tierWebhookUrl}
                onChange={(e) => setTierWebhookUrl(e.target.value)}
                placeholder="https://discord.com/api/webhooks/..."
                className="bg-gray-700/50 border-gray-600 text-white text-sm h-7"
              />
              {!tierValidation.valid && tierWebhookUrl && (
                <p className="text-xs text-red-400 flex items-center">
                  <AlertCircle className="h-3 w-3 mr-1" />
                  {tierValidation.message}
                </p>
              )}
            </div>
            <div className="flex space-x-2">
              <Button
                onClick={() => handleSaveWebhookUrl('tier')}
                disabled={isSavingTier || !tierWebhookUrl.trim()}
                size="sm"
                className="bg-blue-600/20 border border-blue-500/50 text-blue-400 hover:bg-blue-600/30 h-6 px-2 text-xs"
              >
                <Save className="h-3 w-3 mr-1" />
                {isSavingTier ? 'Saving...' : 'Save'}
              </Button>
              <Button
                onClick={() => handleTestWebhook('tier')}
                disabled={isTestingTier || !tierValidation.valid}
                size="sm"
                variant="outline"
                className="border-gray-600 text-gray-300 hover:bg-gray-700 h-6 px-2 text-xs"
              >
                <TestTube className="h-3 w-3 mr-1" />
                {isTestingTier ? 'Testing...' : 'Test'}
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Logbox Webhook Configuration */}
        <Card className="bg-gray-800/50 border-gray-600/50">
          <CardHeader className="pb-3">
            <CardTitle className="text-white text-sm flex items-center">
              📋 System Logs Webhook
              <Badge 
                variant="outline" 
                className={`ml-2 text-xs ${
                  logboxValidation.valid 
                    ? 'border-green-600 text-green-400' 
                    : 'border-red-600 text-red-400'
                }`}
              >
                {logboxValidation.valid ? 'Valid' : 'Invalid'}
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="space-y-2">
              <label className="text-xs text-gray-300">Discord Webhook URL</label>
              <Input
                value={logboxWebhookUrl}
                onChange={(e) => setLogboxWebhookUrl(e.target.value)}
                placeholder="https://discord.com/api/webhooks/..."
                className="bg-gray-700/50 border-gray-600 text-white text-sm h-7"
              />
              {!logboxValidation.valid && logboxWebhookUrl && (
                <p className="text-xs text-red-400 flex items-center">
                  <AlertCircle className="h-3 w-3 mr-1" />
                  {logboxValidation.message}
                </p>
              )}
            </div>
            <div className="flex space-x-2">
              <Button
                onClick={() => handleSaveWebhookUrl('logbox')}
                disabled={isSavingLogbox || !logboxWebhookUrl.trim()}
                size="sm"
                className="bg-blue-600/20 border border-blue-500/50 text-blue-400 hover:bg-blue-600/30 h-6 px-2 text-xs"
              >
                <Save className="h-3 w-3 mr-1" />
                {isSavingLogbox ? 'Saving...' : 'Save'}
              </Button>
              <Button
                onClick={() => handleTestWebhook('logbox')}
                disabled={isTestingLogbox || !logboxValidation.valid}
                size="sm"
                variant="outline"
                className="border-gray-600 text-gray-300 hover:bg-gray-700 h-6 px-2 text-xs"
              >
                <TestTube className="h-3 w-3 mr-1" />
                {isTestingLogbox ? 'Testing...' : 'Test'}
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="text-xs text-gray-500 text-center">
        Bulletproof webhook system • Real-time validation • Auto-retry on failure • Zero downtime
      </div>
    </div>
  );
};

export default RealWebhookManager;
