
import React from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  User, 
  Users, 
  UsersRound, 
  BarChart3, 
  Database, 
  RefreshCw, 
  Download, 
  Wrench, 
  BookOpen, 
  UserCheck, 
  Clipboard,
  CheckCircle2,
  Shield
} from 'lucide-react';
import { newAdminService } from '@/services/newAdminService';

export type AdminTab = 
  | 'player-single' 
  | 'player-manage' 
  | 'player-mass'
  | 'db-analytics' 
  | 'db-player-database' 
  | 'db-refresh' 
  | 'db-backup' 
  | 'db-download' 
  | 'db-maintenance'
  | 'staff-logs' 
  | 'staff-active' 
  | 'staff-applications' 
  | 'staff-approval';

interface AdminNavigationProps {
  activeTab: AdminTab;
  setActiveTab: (tab: AdminTab) => void;
  userRole: string;
  isMobile: boolean;
  mobileMenuOpen: boolean;
  setMobileMenuOpen: (open: boolean) => void;
}

const AdminNavigation: React.FC<AdminNavigationProps> = ({
  activeTab,
  setActiveTab,
  userRole,
  isMobile,
  mobileMenuOpen,
  setMobileMenuOpen
}) => {
  const navigationSections = [
    {
      title: 'Player Operations',
      items: [
        {
          id: 'player-single' as AdminTab,
          label: 'Single Submission',
          icon: User,
          description: 'Submit individual player results',
          allowedRoles: ['owner', 'staff'], // Both owner and staff can access
        },
        {
          id: 'player-manage' as AdminTab,
          label: 'User Management',
          icon: Users,
          description: 'Manage player accounts and data',
          allowedRoles: ['owner', 'staff'], // Both owner and staff can access
        },
        {
          id: 'player-mass' as AdminTab,
          label: 'Mass Submission',
          icon: UsersRound,
          description: 'Bulk submit multiple results',
          allowedRoles: ['owner'], // Only owner can access
        },
      ]
    },
    {
      title: 'Database & Analytics',
      items: [
        {
          id: 'db-analytics' as AdminTab,
          label: 'Analytics Dashboard',
          icon: BarChart3,
          description: 'View system analytics and insights',
          allowedRoles: ['owner'], // Only owner can access
        },
        {
          id: 'db-player-database' as AdminTab,
          label: 'Player Database',
          icon: Database,
          description: 'Direct database access and queries',
          allowedRoles: ['owner'], // Only owner can access
        },
        {
          id: 'db-refresh' as AdminTab,
          label: 'Refresh Data',
          icon: RefreshCw,
          description: 'Refresh and sync database',
          allowedRoles: ['owner'], // Only owner can access
        },
        {
          id: 'db-backup' as AdminTab,
          label: 'Backup & Restore',
          icon: Download,
          description: 'Database backup operations',
          allowedRoles: ['owner'], // Only owner can access
        },
        {
          id: 'db-maintenance' as AdminTab,
          label: 'Maintenance',
          icon: Wrench,
          description: 'System maintenance tools',
          allowedRoles: ['owner'], // Only owner can access
        },
      ]
    },
    {
      title: 'Staff Management',
      items: [
        {
          id: 'staff-logs' as AdminTab,
          label: 'Staff Logs',
          icon: BookOpen,
          description: 'View staff activity logs',
          allowedRoles: ['owner'], // Only owner can access
        },
        {
          id: 'staff-active' as AdminTab,
          label: 'Active Staff',
          icon: UserCheck,
          description: 'Manage active staff members',
          allowedRoles: ['owner'], // Only owner can access
        },
        {
          id: 'staff-applications' as AdminTab,
          label: 'Staff Applications',
          icon: Clipboard,
          description: 'Review staff applications',
          allowedRoles: ['owner'], // Only owner can access
        },
        {
          id: 'staff-approval' as AdminTab,
          label: 'Operation Approval',
          icon: CheckCircle2,
          description: 'Approve pending operations',
          allowedRoles: ['owner'], // Only owner can access
        },
      ]
    }
  ];

  const isTabAllowed = (allowedRoles: string[]) => {
    return allowedRoles.includes(userRole);
  };

  const handleTabClick = (tabId: AdminTab) => {
    setActiveTab(tabId);
    if (isMobile) {
      setMobileMenuOpen(false);
    }
  };

  const navigationContent = (
    <div className="space-y-6 p-2">
      {/* Role indicator */}
      <div className="flex items-center gap-2 p-3 bg-primary/10 rounded-lg">
        <Shield className={`h-4 w-4 ${userRole === 'owner' ? 'text-red-400' : 'text-blue-400'}`} />
        <span className="text-sm font-medium">
          {userRole === 'owner' ? 'Owner Access' : 'Staff Access (Limited)'}
        </span>
        {userRole === 'staff' && (
          <Badge variant="outline" className="text-xs">
            Limited
          </Badge>
        )}
      </div>

      {navigationSections.map((section) => {
        // Filter items based on user role
        const allowedItems = section.items.filter(item => isTabAllowed(item.allowedRoles));
        
        // Skip entire section if no items are allowed
        if (allowedItems.length === 0) return null;

        return (
          <div key={section.title}>
            <h3 className="text-sm font-semibold text-muted-foreground mb-3 px-2">
              {section.title}
            </h3>
            <div className="space-y-1">
              {allowedItems.map((item) => {
                const Icon = item.icon;
                const isActive = activeTab === item.id;
                
                return (
                  <Button
                    key={item.id}
                    onClick={() => handleTabClick(item.id)}
                    variant={isActive ? "secondary" : "ghost"}
                    className={`
                      w-full justify-start text-left h-auto p-3 
                      ${isActive 
                        ? 'bg-primary/20 text-primary border-l-2 border-primary' 
                        : 'hover:bg-primary/5 text-muted-foreground hover:text-foreground'
                      }
                    `}
                  >
                    <div className="flex items-start gap-3 w-full">
                      <Icon className={`h-4 w-4 mt-0.5 flex-shrink-0 ${isActive ? 'text-primary' : ''}`} />
                      <div className="flex-1 min-w-0">
                        <div className="font-medium text-sm">{item.label}</div>
                        <div className="text-xs text-muted-foreground mt-0.5 leading-tight">
                          {item.description}
                        </div>
                      </div>
                    </div>
                  </Button>
                );
              })}
            </div>
          </div>
        );
      })}

      {/* Staff access notice */}
      {userRole === 'staff' && (
        <div className="p-3 bg-blue-500/10 border border-blue-500/20 rounded-lg">
          <div className="flex items-start gap-2">
            <Shield className="h-4 w-4 text-blue-400 mt-0.5 flex-shrink-0" />
            <div className="text-xs text-blue-300">
              <div className="font-medium mb-1">Staff Access</div>
              <div className="text-blue-400/80">
                You have limited access to User Management and Single Submission only. 
                Contact the owner for additional permissions.
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );

  if (isMobile) {
    return (
      <>
        {mobileMenuOpen && (
          <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm">
            <div className="fixed inset-y-0 left-0 w-80 bg-background border-r shadow-xl">
              <div className="flex items-center justify-between p-4 border-b">
                <h2 className="font-semibold">Admin Navigation</h2>
                <Button
                  onClick={() => setMobileMenuOpen(false)}
                  variant="ghost"
                  size="sm"
                >
                  ×
                </Button>
              </div>
              <ScrollArea className="h-[calc(100vh-70px)]">
                {navigationContent}
              </ScrollArea>
            </div>
          </div>
        )}
      </>
    );
  }

  return (
    <div className="bg-card rounded-lg border shadow-sm">
      <ScrollArea className="h-[600px]">
        {navigationContent}
      </ScrollArea>
    </div>
  );
};

export default AdminNavigation;
