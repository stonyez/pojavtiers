
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { Shield, Lock, Eye, EyeOff, Sparkles, Crown, Zap, CheckCircle } from 'lucide-react';
import { authService } from '@/services/authService';
import { motion } from 'framer-motion';
import { shouldDisableEffects } from '@/utils/mobileOptimization';

interface AdminAuthProps {
  onAuthSuccess: () => void;
}

export const AdminAuth: React.FC<AdminAuthProps> = ({ onAuthSuccess }) => {
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const { toast } = useToast();
  const disableEffects = shouldDisableEffects();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!password.trim()) {
      toast({
        title: "Validation Error",
        description: "Please enter a password",
        variant: "destructive"
      });
      return;
    }

    setIsLoading(true);
    try {
      const result = await authService.authenticate(password);
      
      if (result.success) {
        const role = authService.getRole();
        toast({
          title: "Access Granted",
          description: `Welcome back, ${role}!`,
        });
        onAuthSuccess();
      } else {
        toast({
          title: "Access Denied",
          description: result.error || "Invalid credentials",
          variant: "destructive"
        });
      }
    } catch (error: any) {
      toast({
        title: "Authentication Error",
        description: error.message || "An unexpected error occurred",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0a0b14] via-[#0f111a] to-[#1a1b2a] flex items-center justify-center p-4 relative overflow-hidden">
      {/* Background Elements - Desktop Only */}
      {!disableEffects && (
        <div className="absolute inset-0 overflow-hidden">
          {/* Main gradient orbs */}
          <motion.div
            className="absolute top-1/4 left-1/4 w-96 h-96 bg-purple-500/20 rounded-full blur-3xl"
            animate={{
              scale: [1, 1.3, 1],
              opacity: [0.4, 0.7, 0.4],
              x: [0, 50, 0],
              y: [0, -30, 0]
            }}
            transition={{
              duration: 8,
              repeat: Infinity,
              ease: "easeInOut"
            }}
          />
          <motion.div
            className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-blue-500/20 rounded-full blur-3xl"
            animate={{
              scale: [1.2, 1, 1.2],
              opacity: [0.6, 0.3, 0.6],
              x: [0, -40, 0],
              y: [0, 40, 0]
            }}
            transition={{
              duration: 8,
              repeat: Infinity,
              ease: "easeInOut",
              delay: 2
            }}
          />
          <motion.div
            className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-indigo-500/10 rounded-full blur-3xl"
            animate={{
              rotate: [0, 360],
              scale: [0.8, 1.1, 0.8]
            }}
            transition={{
              rotate: { duration: 20, repeat: Infinity, ease: "linear" },
              scale: { duration: 12, repeat: Infinity, ease: "easeInOut" }
            }}
          />

          {/* Floating Particles */}
          {Array.from({ length: 25 }).map((_, i) => (
            <motion.div
              key={i}
              className="absolute w-1 h-1 bg-white/30 rounded-full"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
              }}
              animate={{
                y: [-30, -120, -30],
                x: [0, Math.random() * 40 - 20, 0],
                opacity: [0, 1, 0],
                scale: [0.5, 1.2, 0.5]
              }}
              transition={{
                duration: 4 + Math.random() * 3,
                repeat: Infinity,
                delay: Math.random() * 3,
                ease: "easeInOut"
              }}
            />
          ))}
        </div>
      )}

      <motion.div
        initial={!disableEffects ? { opacity: 0, y: 30, scale: 0.95 } : {}}
        animate={!disableEffects ? { opacity: 1, y: 0, scale: 1 } : {}}
        transition={!disableEffects ? { duration: 0.8, ease: "easeOut" } : {}}
        className="relative z-10"
      >
        <Card className="w-full max-w-lg bg-gray-900/70 backdrop-blur-3xl border border-gray-700/60 shadow-2xl shadow-purple-500/20 relative overflow-hidden">
          {/* Enhanced Card Effects - Desktop Only */}
          {!disableEffects && (
            <>
              <div className="absolute inset-0 bg-gradient-to-r from-purple-500/15 via-transparent to-blue-500/15 opacity-60" />
              <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-gray-900/30" />
              
              {/* Animated border effect */}
              <motion.div
                className="absolute inset-0 rounded-lg border-2 border-transparent bg-gradient-to-r from-purple-500/50 via-blue-500/50 to-purple-500/50 opacity-20"
                animate={{
                  backgroundPosition: ['0% 50%', '100% 50%', '0% 50%']
                }}
                transition={{
                  duration: 3,
                  repeat: Infinity,
                  ease: "linear"
                }}
                style={{
                  backgroundSize: '200% 200%',
                  mask: 'linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0)',
                  maskComposite: 'exclude'
                }}
              />
            </>
          )}
          
          <CardHeader className="text-center space-y-6 pb-8 relative z-10">
            <motion.div 
              className="flex justify-center"
              whileHover={!disableEffects ? { scale: 1.1, rotate: 5 } : {}}
              transition={!disableEffects ? { type: "spring", stiffness: 300, damping: 20 } : {}}
            >
              <div className="relative p-5 bg-gradient-to-br from-purple-600 via-blue-600 to-indigo-700 rounded-3xl shadow-2xl">
                <Shield className="h-12 w-12 text-white" />
                
                {/* Enhanced icon effects - Desktop Only */}
                {!disableEffects && (
                  <>
                    <div className="absolute inset-0 bg-gradient-to-br from-purple-600 to-blue-600 rounded-3xl blur-xl opacity-60 -z-10 animate-pulse" />
                    
                    {/* Floating decorative elements */}
                    <motion.div
                      className="absolute -top-1 -right-1"
                      animate={{
                        rotate: [0, 360],
                        scale: [1, 1.2, 1]
                      }}
                      transition={{
                        duration: 2,
                        repeat: Infinity,
                        ease: "linear"
                      }}
                    >
                      <Sparkles className="h-4 w-4 text-yellow-300" />
                    </motion.div>
                    
                    <motion.div
                      className="absolute -bottom-1 -left-1"
                      animate={{
                        rotate: [360, 0],
                        scale: [1, 1.3, 1]
                      }}
                      transition={{
                        duration: 2.5,
                        repeat: Infinity,
                        ease: "linear",
                        delay: 0.5
                      }}
                    >
                      <Crown className="h-4 w-4 text-yellow-400" />
                    </motion.div>
                    
                    <motion.div
                      className="absolute -top-1 -left-1"
                      animate={{
                        scale: [1, 1.4, 1],
                        opacity: [0.7, 1, 0.7]
                      }}
                      transition={{
                        duration: 1.5,
                        repeat: Infinity,
                        ease: "easeInOut",
                        delay: 1
                      }}
                    >
                      <Zap className="h-4 w-4 text-blue-300" />
                    </motion.div>
                  </>
                )}
              </div>
            </motion.div>
            
            <div className="space-y-3">
              <CardTitle className="text-4xl font-bold bg-gradient-to-r from-white via-purple-200 to-blue-200 bg-clip-text text-transparent">
                MCBE-Tiers Admin
              </CardTitle>
              <CardDescription className="text-gray-400 text-lg font-medium">
                Secure Administrative Access Portal
              </CardDescription>
              <div className="flex items-center justify-center gap-2 text-sm text-green-400">
                <CheckCircle className="h-4 w-4" />
                <span>Enterprise-grade Security</span>
              </div>
            </div>
          </CardHeader>
          
          <CardContent className="pt-0 space-y-8 relative z-10 px-8">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-4">
                <label htmlFor="password" className="text-base font-semibold text-gray-300 flex items-center gap-3">
                  <Lock className="h-5 w-5 text-purple-400" />
                  Administrative Password
                </label>
                <div className="relative group">
                  <Input
                    id="password"
                    type={showPassword ? "text" : "password"}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Enter your secure password"
                    className="pl-14 pr-14 h-14 bg-gray-800/60 border-gray-600/60 text-white text-lg placeholder:text-gray-500 focus:border-purple-500/80 focus:ring-purple-500/40 focus:ring-2 transition-all duration-300 group-hover:border-gray-500/70 rounded-xl"
                    disabled={isLoading}
                  />
                  <Lock className="absolute left-5 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400 group-focus-within:text-purple-400 transition-colors" />
                  <motion.button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-5 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-white transition-colors"
                    disabled={isLoading}
                    whileHover={!disableEffects ? { scale: 1.1 } : {}}
                    whileTap={!disableEffects ? { scale: 0.95 } : {}}
                  >
                    {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                  </motion.button>
                </div>
              </div>
              
              <motion.div
                whileHover={!disableEffects ? { scale: 1.02 } : {}}
                whileTap={!disableEffects ? { scale: 0.98 } : {}}
              >
                <Button 
                  type="submit" 
                  className="w-full h-14 bg-gradient-to-r from-purple-600 via-blue-600 to-indigo-700 hover:from-purple-700 hover:via-blue-700 hover:to-indigo-800 text-white font-semibold text-lg shadow-2xl shadow-purple-500/30 border border-purple-500/40 relative overflow-hidden group rounded-xl"
                  disabled={isLoading}
                >
                  {/* Loading animation - Desktop Only */}
                  {isLoading && !disableEffects && (
                    <motion.div
                      className="absolute inset-0 bg-gradient-to-r from-purple-400/30 to-blue-400/30"
                      animate={{
                        x: [-100, 100],
                      }}
                      transition={{
                        duration: 1.5,
                        repeat: Infinity,
                        ease: "linear"
                      }}
                    />
                  )}
                  <div className="relative z-10 flex items-center justify-center gap-3">
                    {isLoading ? (
                      <>
                        <motion.div
                          className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full"
                          animate={!disableEffects ? { rotate: 360 } : {}}
                          transition={!disableEffects ? { duration: 1, repeat: Infinity, ease: "linear" } : {}}
                        />
                        Authenticating...
                      </>
                    ) : (
                      <>
                        <Shield className="h-5 w-5" />
                        Access Control Panel
                      </>
                    )}
                  </div>
                </Button>
              </motion.div>
            </form>
            
            {/* Enhanced Security Info */}
            <div className="text-center pt-6 border-t border-gray-700/60">
              <div className="flex items-center justify-center gap-2 text-sm text-gray-500 mb-2">
                <Shield className="h-4 w-4" />
                <span>Protected by Advanced Encryption</span>
              </div>
              <p className="text-xs text-gray-600">
                All communications are secured with enterprise-grade protocols
              </p>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
};
