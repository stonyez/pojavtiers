
import React from 'react';

export function ModeToggle() {
  // This is a placeholder component to satisfy imports
  // It doesn't do anything since we're not changing UI
  return null;
}
