
import React from 'react';

// This component is now deprecated in favor of PlayerResultPopup
// All functionality has been moved to PlayerResultPopup
export function ResultPopup() {
  // Don't render anything - PlayerResultPopup handles the display
  return null;
}
