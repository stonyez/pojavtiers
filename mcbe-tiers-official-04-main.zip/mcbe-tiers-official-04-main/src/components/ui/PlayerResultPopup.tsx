
import React from 'react';
import { MobileOptimizedResultPopup } from './MobileOptimizedResultPopup';

// Use MobileOptimizedResultPopup as the primary popup component
export const PlayerResultPopup = MobileOptimizedResultPopup;
