import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Monitor, Smartphone, Gamepad, Trophy, Crown, AlertTriangle } from 'lucide-react';
import { GameModeIcon } from '@/components/GameModeIcon';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { usePopup } from '@/contexts/PopupContext';
import { GameMode } from '@/services/playerService';
import { useIsMobile } from '@/hooks/use-mobile';
import { getSkinUrl, handleAvatarError } from '@/utils/skinUtils';
import { getPlayerRank } from '@/utils/rankUtils';

// Device icon component
const DeviceIcon = ({ device }: { device?: string }) => {
  const iconSize = "w-5 h-5";
  
  switch(device?.toLowerCase()) {
    case 'mobile':
    case 'bedrock':
      return <Smartphone className={`${iconSize} text-blue-400`} />;
    case 'console':
      return <Gamepad className={`${iconSize} text-green-400`} />;
    case 'pc':
    case 'java':
    default:
      return <Monitor className={`${iconSize} text-gray-300`} />;
  }
};

// Custom region graphics
const RegionIcon = ({ region }: { region?: string }) => {
  const regionCode = region || 'NA';
  
  switch(regionCode) {
    case 'EU':
      return (
        <div className="w-5 h-5 rounded-full bg-purple-500/20 border border-purple-400/50 flex items-center justify-center">
          <div className="w-3 h-3 rounded-full bg-purple-400" />
        </div>
      );
    case 'AS':
    case 'ASIA':
      return (
        <div className="w-5 h-5 rounded-full bg-red-500/20 border border-red-400/50 flex items-center justify-center">
          <div className="w-3 h-3 rounded-full bg-red-400" />
        </div>
      );
    case 'NA':
    default:
      return (
        <div className="w-5 h-5 rounded-full bg-blue-500/20 border border-blue-400/50 flex items-center justify-center">
          <div className="w-3 h-3 rounded-full bg-blue-400" />
        </div>
      );
  }
};

// Region theming system
const getRegionTheme = (region: string = 'NA') => {
  const themes: Record<string, {
    name: string;
    primary: string;
    gradient: string;
    border: string;
    glow: string;
  }> = {
    'NA': {
      name: 'North America',
      primary: '#3b82f6',
      gradient: 'from-blue-500/30 to-blue-600/20',
      border: 'border-blue-400/50',
      glow: 'shadow-blue-500/25'
    },
    'EU': {
      name: 'Europe',
      primary: '#8b5cf6',
      gradient: 'from-purple-500/30 to-purple-600/20',
      border: 'border-purple-400/50',
      glow: 'shadow-purple-500/25'
    },
    'AS': {
      name: 'Asia',
      primary: '#ef4444',
      gradient: 'from-red-500/30 to-red-600/20',
      border: 'border-red-400/50',
      glow: 'shadow-red-500/25'
    },
    'ASIA': {
      name: 'Asia',
      primary: '#ef4444',
      gradient: 'from-red-500/30 to-red-600/20',
      border: 'border-red-400/50',
      glow: 'shadow-red-500/25'
    }
  };
  
  return themes[region] || themes['NA'];
};

// Rank system with FX
const getRankInfo = (points: number) => {
  const playerRank = getPlayerRank(points);
  
  if (points >= 500) return { 
    title: 'Combat Grandmaster', 
    fx: 'grandmaster',
    gradient: 'from-purple-500 via-pink-500 to-purple-600',
    glow: 'shadow-purple-500/50',
    iconPath: playerRank.iconPath
  };
  if (points >= 400) return { 
    title: 'Combat Master', 
    fx: 'master',
    gradient: 'from-orange-500 via-red-500 to-orange-600',
    glow: 'shadow-orange-500/50',
    iconPath: playerRank.iconPath
  };
  if (points >= 300) return { 
    title: 'Combat Ace', 
    fx: 'ace',
    gradient: 'from-blue-400 via-cyan-500 to-blue-600',
    glow: 'shadow-cyan-500/50',
    iconPath: playerRank.iconPath
  };
  if (points >= 200) return { 
    title: 'Combat Specialist', 
    fx: 'specialist',
    gradient: 'from-green-400 via-emerald-500 to-green-600',
    glow: 'shadow-green-500/50',
    iconPath: playerRank.iconPath
  };
  if (points >= 100) return { 
    title: 'Combat Cadet', 
    fx: 'cadet',
    gradient: 'from-yellow-400 via-amber-500 to-yellow-600',
    glow: 'shadow-yellow-500/50',
    iconPath: playerRank.iconPath
  };
  if (points >= 50) return { 
    title: 'Combat Novice', 
    fx: 'novice',
    gradient: 'from-gray-400 via-slate-500 to-gray-600',
    glow: 'shadow-gray-500/25',
    iconPath: playerRank.iconPath
  };
  return { 
    title: 'Combat Rookie', 
    fx: 'none',
    gradient: 'from-gray-500 to-gray-600',
    glow: 'shadow-gray-500/25',
    iconPath: playerRank.iconPath
  };
};

// Desktop rank effects component
const RankEffects = ({ fx, isDesktop }: { fx: string; isDesktop: boolean }) => {
  if (!isDesktop || fx === 'none') return null;

  switch (fx) {
    case 'grandmaster':
      return (
        <>
          <div className="absolute inset-0 pointer-events-none">
            {Array.from({ length: 8 }).map((_, i) => (
              <motion.div
                key={i}
                className="absolute w-1 h-6 bg-purple-400 opacity-60"
                style={{
                  left: `${20 + i * 10}%`,
                  top: `${10 + Math.sin(i) * 20}%`
                }}
                animate={{
                  opacity: [0.3, 1, 0.3],
                  scaleY: [0.5, 1.5, 0.5]
                }}
                transition={{
                  duration: 0.5,
                  repeat: Infinity,
                  delay: i * 0.1
                }}
              />
            ))}
          </div>
          <motion.div
            className="absolute inset-0 bg-gradient-to-r from-purple-500/20 to-pink-500/20 rounded-full"
            animate={{
              opacity: [0.3, 0.7, 0.3],
              scale: [1, 1.05, 1]
            }}
            transition={{
              duration: 2,
              repeat: Infinity
            }}
          />
        </>
      );
    case 'master':
      return (
        <motion.div
          className="absolute inset-0 bg-gradient-to-r from-orange-500/20 to-red-500/20 rounded-full"
          animate={{
            opacity: [0.3, 0.7, 0.3],
            scale: [1, 1.05, 1]
          }}
          transition={{
            duration: 2,
            repeat: Infinity
          }}
        />
      );
    case 'ace':
      return (
        <div className="absolute inset-0 pointer-events-none">
          {Array.from({ length: 6 }).map((_, i) => (
            <motion.div
              key={i}
              className="absolute w-2 h-2 bg-blue-400 rounded-full"
              style={{
                left: `${30 + i * 8}%`,
                top: `${20 + i * 10}%`
              }}
              animate={{
                opacity: [0, 1, 0],
                scale: [0.5, 1, 0.5]
              }}
              transition={{
                duration: 1.5,
                repeat: Infinity,
                delay: i * 0.2
              }}
            />
          ))}
        </div>
      );
    case 'specialist':
      return (
        <motion.div
          className="absolute inset-0 border-2 border-green-400/40 rounded-full"
          animate={{
            opacity: [0.2, 0.8, 0.2],
            scale: [0.9, 1.1, 0.9]
          }}
          transition={{
            duration: 3,
            repeat: Infinity
          }}
        />
      );
    case 'cadet':
      return (
        <motion.div
          className="absolute inset-0 bg-yellow-400/10 rounded-full"
          animate={{
            opacity: [0.2, 0.5, 0.2]
          }}
          transition={{
            duration: 2.5,
            repeat: Infinity
          }}
        />
      );
    case 'novice':
      return (
        <motion.div
          className="absolute inset-0 bg-gray-400/10 rounded-full"
          animate={{
            opacity: [0.1, 0.3, 0.1]
          }}
          transition={{
            duration: 4,
            repeat: Infinity
          }}
        />
      );
    default:
      return null;
  }
};

// Position badge for top 10
const PositionBadge = ({ position }: { position: number }) => {
  if (position > 10) return null;

  const getBadgeConfig = () => {
    if (position === 1) return { icon: Crown, color: 'text-yellow-400', bg: 'bg-yellow-500/20' };
    if (position === 2) return { icon: Trophy, color: 'text-gray-300', bg: 'bg-gray-500/20' };
    if (position === 3) return { icon: Trophy, color: 'text-amber-600', bg: 'bg-amber-500/20' };
    return { icon: Trophy, color: 'text-blue-400', bg: 'bg-blue-500/20' };
  };

  const config = getBadgeConfig();
  const IconComponent = config.icon;

  return (
    <div className={`flex items-center gap-2 px-3 py-1.5 rounded-lg ${config.bg} border border-white/20`}>
      <IconComponent className={`w-4 h-4 ${config.color}`} />
      <span className="text-white font-bold text-sm">#{position} Overall</span>
    </div>
  );
};

// Banned player popup content
const BannedPlayerContent = ({ player, theme }: { player: any; theme: any }) => (
  <div className="text-center space-y-4">
    <div className="w-20 h-20 mx-auto flex items-center justify-center bg-red-500/20 rounded-full border-2 border-red-400">
      <AlertTriangle className="w-10 h-10 text-red-400" />
    </div>
    
    <div>
      <h2 className="text-xl font-bold text-white mb-2">{player.ign}</h2>
      <div className="px-4 py-2 bg-red-600/20 border border-red-500/50 rounded-lg">
        <p className="text-red-400 font-bold text-sm">⚠️ This player has been banned</p>
        {player.ban_reason && (
          <p className="text-red-300 text-xs mt-1">Reason: {player.ban_reason}</p>
        )}
      </div>
    </div>
  </div>
);

export const UnifiedResultPopup = () => {
  const { showPopup, popupData, closePopup } = usePopup();
  const isMobile = useIsMobile();

  console.log('UnifiedResultPopup render:', { showPopup, hasData: !!popupData });

  // Early return if no popup should be shown
  if (!showPopup || !popupData?.player) {
    console.log('No popup or player data, returning null');
    return null;
  }

  const { player, tierAssignments = [] } = popupData;
  const region = player.region || 'NA';
  const theme = getRegionTheme(region);
  const rankInfo = getRankInfo(player.global_points || 0);

  console.log('Rendering popup for player:', player.ign, 'banned:', player.banned);

  // If player is banned, show banned content
  if (player.banned) {
    return (
      <AnimatePresence>
        <motion.div
          className="fixed inset-0 z-[9999] flex items-center justify-center p-4"
          style={{
            backgroundColor: 'rgba(0, 0, 0, 0.8)',
            backdropFilter: 'blur(8px)'
          }}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={(e) => {
            console.log('Overlay clicked, closing popup');
            closePopup();
          }}
        >
          <motion.div
            className={`relative w-full max-w-sm bg-slate-900 border-2 border-red-500/50 rounded-2xl overflow-hidden shadow-2xl shadow-red-500/25`}
            initial={{ scale: 0.8, opacity: 0, y: 50 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.8, opacity: 0, y: 50 }}
            transition={{ type: "spring", stiffness: 300, damping: 25 }}
            onClick={(e) => e.stopPropagation()}
          >
            <button 
              onClick={() => {
                console.log('Close button clicked');
                closePopup();
              }}
              className="absolute top-3 right-3 z-20 text-gray-400 hover:text-white transition-colors"
            >
              <X className="h-5 w-5" />
            </button>

            <div className="absolute inset-0 bg-gradient-to-br from-red-500/30 to-red-600/20 opacity-70" />

            <div className="relative z-10 p-6">
              <div className="text-center space-y-4">
                <div className="w-20 h-20 mx-auto flex items-center justify-center bg-red-500/20 rounded-full border-2 border-red-400">
                  <AlertTriangle className="w-10 h-10 text-red-400" />
                </div>
                
                <div>
                  <h2 className="text-xl font-bold text-white mb-2">{player.ign}</h2>
                  <div className="px-4 py-2 bg-red-600/20 border border-red-500/50 rounded-lg">
                    <p className="text-red-400 font-bold text-sm">⚠️ This player has been banned</p>
                    {player.ban_reason && (
                      <p className="text-red-300 text-xs mt-1">Reason: {player.ban_reason}</p>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </motion.div>
      </AnimatePresence>
    );
  }

  // Gamemode layout: 2 rows of 4
  const gamemodeRows = [
    ['Crystal', 'Sword', 'Axe', 'Mace'] as GameMode[],
    ['SMP', 'NethPot', 'Bedwars', 'UHC'] as GameMode[]
  ];

  const handleOverlayClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) {
      console.log('Overlay clicked, closing popup');
      closePopup();
    }
  };

  return (
    <AnimatePresence>
      <motion.div
        className="fixed inset-0 z-[9999] flex items-center justify-center p-4"
        style={{
          backgroundColor: 'rgba(0, 0, 0, 0.8)',
          backdropFilter: 'blur(8px)'
        }}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={handleOverlayClick}
      >
        <motion.div
          className={`relative w-full max-w-sm bg-slate-900 border-2 ${theme.border} rounded-2xl overflow-hidden shadow-2xl ${theme.glow} ${rankInfo.glow}`}
          style={{
            boxShadow: `0 0 40px ${theme.primary}40, 0 20px 60px rgba(0, 0, 0, 0.8), 0 0 20px ${rankInfo.glow}`
          }}
          initial={{ scale: 0.8, opacity: 0, y: 50 }}
          animate={{ scale: 1, opacity: 1, y: 0 }}
          exit={{ scale: 0.8, opacity: 0, y: 50 }}
          transition={{ type: "spring", stiffness: 300, damping: 25 }}
          onClick={(e) => e.stopPropagation()}
        >
          <button 
            onClick={() => {
              console.log('Close button clicked');
              closePopup();
            }}
            className="absolute top-3 right-3 z-20 text-gray-400 hover:text-white transition-colors"
          >
            <X className="h-5 w-5" />
          </button>

          {/* Regional gradient overlay */}
          <div className={`absolute inset-0 bg-gradient-to-br ${theme.gradient} opacity-70`} />

          <div className="relative z-10 p-6 text-center space-y-4">
            {/* Avatar */}
            <div className="relative inline-block">
              <Avatar className="w-20 h-20 mx-auto">
                <AvatarImage 
                  src={`https://visage.surgeplay.com/bust/128/${player.ign}`}
                  alt={player.ign}
                  onError={(e) => {
                    e.currentTarget.src = `https://crafatar.com/avatars/${player.ign}?size=128&overlay=true`;
                  }}
                />
                <AvatarFallback className="bg-slate-700 text-white font-bold text-xl">
                  {player.ign.charAt(0)}
                </AvatarFallback>
              </Avatar>
            </div>

            {/* Player Info */}
            <div>
              <div className="flex items-center justify-center gap-2 mb-2">
                <DeviceIcon device={player.device} />
                <RegionIcon region={region} />
                <h2 className="text-xl font-bold text-white">{player.ign}</h2>
              </div>
              
              <div className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-lg bg-gradient-to-r ${rankInfo.gradient} text-white text-sm font-bold`}>
                <img 
                  src={rankInfo.iconPath}
                  alt={`${rankInfo.title} icon`}
                  className="w-4 h-4 object-contain"
                />
                <span>{rankInfo.title}</span>
              </div>
              
              <div className="text-gray-400 text-sm mt-2">{theme.name}</div>
            </div>

            {/* Position */}
            <div className="flex justify-center">
              <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-blue-500/20 border border-white/20">
                <Trophy className="w-4 h-4 text-blue-400" />
                <span className="text-white font-bold text-sm">#{player.overall_rank || 1} Overall</span>
              </div>
            </div>

            {/* Tiers */}
            <div>
              <h3 className="text-gray-400 text-sm font-bold mb-3">Gamemode Tiers</h3>
              {gamemodeRows.map((row, rowIndex) => (
                <div key={rowIndex} className={`flex justify-center gap-3 ${rowIndex === 0 ? 'mb-3' : ''}`}>
                  {row.map((gamemode) => {
                    const assignment = tierAssignments.find(a => a.gamemode === gamemode);
                    const tier = assignment?.tier || 'NR';
                    const points = assignment?.score || 0;
                    
                    return (
                      <div key={gamemode} className="group relative flex flex-col items-center space-y-1">
                        <div className="w-10 h-10 bg-slate-700 rounded-lg flex items-center justify-center">
                          <GameModeIcon mode={gamemode.toLowerCase()} className="h-5 w-5" />
                        </div>
                        <span className="text-xs text-gray-300 font-bold">{tier}</span>
                        
                        {/* Desktop hover tooltip */}
                        {!isMobile && (
                          <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 px-2 py-1 bg-black/90 text-white text-xs rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap z-30">
                            {gamemode}: {points} pts
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              ))}
            </div>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
};
