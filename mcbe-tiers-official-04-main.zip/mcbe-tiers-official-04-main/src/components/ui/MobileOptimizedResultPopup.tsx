
import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { X } from 'lucide-react';
import { getPlayerRank } from '@/utils/rankUtils';
import { usePopup } from '@/contexts/PopupContext';

export const MobileOptimizedResultPopup: React.FC = () => {
  const { showPopup, popupData, isMobile, closePopup } = usePopup();
  
  if (!showPopup || !popupData) return null;

  const rank = getPlayerRank(popupData.player.global_points || 0);

  // Mobile: no effects, instant display
  const containerClass = isMobile 
    ? "fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4"
    : "fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4";

  const cardClass = isMobile
    ? "w-full max-w-sm bg-gray-900 text-white rounded-lg"
    : `w-full max-w-sm bg-gray-900 text-white rounded-lg border-2 ${rank.borderColor} shadow-2xl`;

  return (
    <div className={containerClass} onClick={closePopup}>
      <Card className={cardClass} onClick={(e) => e.stopPropagation()}>
        <CardContent className="p-6">
          <div className="flex justify-between items-start mb-4">
            <div className="flex items-center space-x-3">
              <img
                src={popupData.player.avatar_url || '/default-avatar.png'}
                alt={popupData.player.ign}
                className="w-12 h-12 rounded-full"
              />
              <div>
                <h3 className="text-lg font-bold">{popupData.player.ign}</h3>
                {popupData.player.java_username && (
                  <p className="text-sm text-gray-400">{popupData.player.java_username}</p>
                )}
              </div>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={closePopup}
              className="text-gray-400 hover:text-white"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>

          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-gray-400">Rank:</span>
              <span className={isMobile ? "text-white font-medium" : `${rank.color} font-medium`}>
                {rank.icon} {rank.title}
              </span>
            </div>
            
            <div className="flex justify-between items-center">
              <span className="text-gray-400">Total Points:</span>
              <span className="text-white font-medium">{popupData.player.global_points || 0}</span>
            </div>

            {popupData.tierAssignments && popupData.tierAssignments.length > 0 && (
              <div className="mt-4">
                <h4 className="text-sm font-medium text-gray-300 mb-2">Gamemode Results</h4>
                <div className="space-y-2">
                  {popupData.tierAssignments.map((assignment, index) => (
                    <div key={index} className="flex justify-between items-center text-sm">
                      <span className="text-gray-400 capitalize">{assignment.gamemode}</span>
                      <div className="text-right">
                        <div className="text-white">{assignment.tier}</div>
                        <div className="text-xs text-gray-500">{assignment.score} pts</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
