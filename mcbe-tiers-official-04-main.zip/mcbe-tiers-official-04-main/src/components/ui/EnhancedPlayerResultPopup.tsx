
import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Monitor, Smartphone, Gamepad, Trophy, Crown } from 'lucide-react';
import { GameModeIcon } from '@/components/GameModeIcon';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { usePopup } from '@/contexts/PopupContext';
import { GameMode } from '@/services/playerService';
import { getAvatarUrl, handleAvatarError } from '@/utils/avatarUtils';
import { getPlayerRank } from '@/utils/rankUtils';

// Device icon component
const DeviceIcon = ({ device }: { device?: string }) => {
  const iconSize = "w-4 h-4";
  
  switch(device?.toLowerCase()) {
    case 'mobile':
    case 'bedrock':
      return <Smartphone className={`${iconSize} text-blue-400`} />;
    case 'console':
      return <Gamepad className={`${iconSize} text-green-400`} />;
    case 'pc':
    case 'java':
    default:
      return <Monitor className={`${iconSize} text-gray-400`} />;
  }
};

// Regional theming system
const getRegionTheme = (region: string = 'NA') => {
  const themes: Record<string, {
    name: string;
    primary: string;
    gradient: string;
    border: string;
    glow: string;
    accent: string;
  }> = {
    'NA': {
      name: 'North America',
      primary: '#3b82f6',
      gradient: 'from-blue-500/30 to-blue-600/20',
      border: 'border-blue-400/50',
      glow: 'shadow-blue-500/25',
      accent: 'text-blue-300'
    },
    'EU': {
      name: 'Europe',
      primary: '#8b5cf6',
      gradient: 'from-purple-500/30 to-purple-600/20',
      border: 'border-purple-400/50',
      glow: 'shadow-purple-500/25',
      accent: 'text-purple-300'
    },
    'ASIA': {
      name: 'Asia',
      primary: '#ef4444',
      gradient: 'from-red-500/30 to-red-600/20',
      border: 'border-red-400/50',
      glow: 'shadow-red-500/25',
      accent: 'text-red-300'
    },
    'AS': {
      name: 'Asia',
      primary: '#ef4444',
      gradient: 'from-red-500/30 to-red-600/20',
      border: 'border-red-400/50',
      glow: 'shadow-red-500/25',
      accent: 'text-red-300'
    },
    'SA': {
      name: 'South America',
      primary: '#f59e0b',
      gradient: 'from-amber-500/30 to-amber-600/20',
      border: 'border-amber-400/50',
      glow: 'shadow-amber-500/25',
      accent: 'text-amber-300'
    },
    'AF': {
      name: 'Africa',
      primary: '#ec4899',
      gradient: 'from-pink-500/30 to-pink-600/20',
      border: 'border-pink-400/50',
      glow: 'shadow-pink-500/25',
      accent: 'text-pink-300'
    },
    'OCE': {
      name: 'Oceania',
      primary: '#06b6d4',
      gradient: 'from-cyan-500/30 to-cyan-600/20',
      border: 'border-cyan-400/50',
      glow: 'shadow-cyan-500/25',
      accent: 'text-cyan-300'
    }
  };
  
  return themes[region] || themes['NA'];
};

// Tier styling function
const getTierStyle = (tier: string) => {
  const tierStyles: Record<string, { bg: string; text: string; border: string }> = {
    'HT1': { bg: 'bg-yellow-500/20', text: 'text-yellow-300', border: 'border-yellow-500/40' },
    'LT1': { bg: 'bg-green-500/20', text: 'text-green-300', border: 'border-green-500/40' },
    'HT2': { bg: 'bg-orange-500/20', text: 'text-orange-300', border: 'border-orange-500/40' },
    'LT2': { bg: 'bg-blue-500/20', text: 'text-blue-300', border: 'border-blue-500/40' },
    'HT3': { bg: 'bg-purple-500/20', text: 'text-purple-300', border: 'border-purple-500/40' },
    'LT3': { bg: 'bg-pink-500/20', text: 'text-pink-300', border: 'border-pink-500/40' },
    'Retired': { bg: 'bg-gray-500/20', text: 'text-gray-400', border: 'border-gray-500/40' }
  };
  
  return tierStyles[tier] || { bg: 'bg-gray-600/20', text: 'text-gray-400', border: 'border-gray-600/40' };
};

export const EnhancedPlayerResultPopup = () => {
  const { showPopup, popupData, closePopup } = usePopup();

  if (!showPopup || !popupData) return null;

  const { player, tierAssignments } = popupData;
  const region = player.region || 'NA';
  const theme = getRegionTheme(region);
  const rankInfo = getPlayerRank(player.global_points || 0);

  // Organized gamemode layout in two rows
  const gamemodeRows = [
    ['Crystal', 'Sword', 'Axe', 'Mace'] as GameMode[],
    ['SMP', 'NethPot', 'Bedwars', 'UHC'] as GameMode[]
  ];

  const handleOverlayClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) {
      closePopup();
    }
  };

  return (
    <AnimatePresence>
      {showPopup && (
        <motion.div
          className="fixed inset-0 z-[9999] flex items-center justify-center p-3"
          style={{
            background: 'rgba(0, 0, 0, 0.85)',
            backdropFilter: 'blur(8px)'
          }}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={handleOverlayClick}
        >
          <motion.div
            className={`relative w-full max-w-sm bg-gradient-to-br from-slate-900/95 to-slate-800/95 
                       border-2 ${theme.border} rounded-2xl overflow-hidden ${theme.glow} shadow-2xl backdrop-blur-xl`}
            style={{
              boxShadow: `0 0 30px ${theme.primary}40, 0 8px 32px rgba(0, 0, 0, 0.6)`
            }}
            initial={{ scale: 0.8, opacity: 0, y: 50 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.8, opacity: 0, y: 50 }}
            transition={{ type: "spring", stiffness: 300, damping: 25 }}
            onClick={(e) => e.stopPropagation()}
          >
            {/* Regional gradient overlay */}
            <div className={`absolute inset-0 bg-gradient-to-br ${theme.gradient} opacity-50`} />

            {/* Close button */}
            <button 
              onClick={closePopup}
              className="absolute top-3 right-3 z-20 text-gray-400 hover:text-white transition-colors 
                         bg-black/40 rounded-full p-2 hover:bg-black/60"
            >
              <X className="h-4 w-4" />
            </button>

            {/* Content */}
            <div className="relative z-10 p-5">
              {/* Header Section */}
              <div className="text-center mb-5">
                {/* Avatar */}
                <div className="relative inline-block mb-3">
                  <Avatar 
                    className={`w-20 h-20 border-3 ${theme.border} shadow-lg`}
                    style={{
                      boxShadow: `0 0 20px ${theme.primary}30`
                    }}
                  >
                    <AvatarImage 
                      src={player.avatar_url || getAvatarUrl(player.ign, player.java_username)}
                      alt={player.ign}
                      onError={(e) => handleAvatarError(e, player.ign, player.java_username)}
                    />
                    <AvatarFallback className="bg-gradient-to-br from-blue-500 to-purple-600 text-white font-bold text-xl">
                      {player.ign.charAt(0)}
                    </AvatarFallback>
                  </Avatar>
                </div>

                {/* Player Name with Device Icon */}
                <div className="flex items-center justify-center space-x-2 mb-2">
                  <DeviceIcon device={player.device} />
                  <h2 className="text-xl font-bold text-white">{player.ign}</h2>
                </div>

                {/* Rank Badge */}
                <Badge 
                  className={`px-3 py-1 text-sm font-bold mb-2 border ${theme.border}`}
                  style={{
                    background: `linear-gradient(135deg, ${theme.primary}20, ${theme.primary}10)`,
                    color: theme.accent.replace('text-', '')
                  }}
                >
                  <Crown className="h-4 w-4 mr-1" />
                  {rankInfo.title}
                </Badge>

                {/* Region */}
                <div className={`${theme.accent} text-sm font-medium`}>
                  🌍 {theme.name}
                </div>
              </div>

              {/* Position Section */}
              <div className="mb-5">
                <h3 className="text-gray-400 text-xs font-bold uppercase tracking-wider mb-3 text-center">
                  Position
                </h3>
                <div 
                  className={`bg-gradient-to-r ${theme.gradient} border ${theme.border} rounded-xl p-3 
                             flex items-center justify-between backdrop-blur-sm`}
                >
                  <div className="flex items-center space-x-3">
                    <div 
                      className="text-white rounded-lg px-3 py-2 text-lg font-bold shadow-lg"
                      style={{
                        background: `linear-gradient(135deg, ${theme.primary}, ${theme.primary}CC)`
                      }}
                    >
                      #{player.overall_rank || 1}
                    </div>
                    <div className="flex items-center space-x-2">
                      <Trophy className="h-5 w-5 text-yellow-400" />
                      <span className="text-white font-bold">OVERALL</span>
                    </div>
                  </div>
                  <div className="text-gray-300 text-sm font-medium">
                    {player.global_points || 0} pts
                  </div>
                </div>
              </div>

              {/* Tiers Section */}
              <div>
                <h3 className="text-gray-400 text-xs font-bold uppercase tracking-wider mb-3 text-center">
                  Gamemode Tiers
                </h3>
                <div className={`bg-black/20 border ${theme.border} rounded-xl p-3 backdrop-blur-sm`}>
                  {gamemodeRows.map((row, rowIndex) => (
                    <div key={rowIndex} className={`flex justify-center gap-2 ${rowIndex === 0 ? 'mb-2' : ''}`}>
                      {row.map((gamemode) => {
                        const assignment = tierAssignments.find(a => a.gamemode === gamemode);
                        const tier = assignment?.tier || 'Not Ranked';
                        const tierStyle = getTierStyle(tier);
                        const points = assignment?.score || 0;
                        
                        return (
                          <div key={gamemode} className="group relative">
                            <div className="flex flex-col items-center space-y-1.5">
                              <div 
                                className={`w-10 h-10 rounded-full border-2 ${theme.border} 
                                           flex items-center justify-center backdrop-blur-sm transition-transform 
                                           group-hover:scale-110`}
                                style={{
                                  background: `rgba(255, 255, 255, 0.1)`,
                                  boxShadow: `0 0 10px ${theme.primary}20`
                                }}
                              >
                                <GameModeIcon mode={gamemode.toLowerCase()} className="h-5 w-5" />
                              </div>
                              <Badge 
                                className={`text-xs px-2 py-0.5 font-bold ${tierStyle.bg} ${tierStyle.text} 
                                           ${tierStyle.border} transition-all group-hover:scale-105`}
                              >
                                {tier === 'Not Ranked' ? 'NR' : tier}
                              </Badge>
                            </div>
                            
                            {/* Tooltip */}
                            <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 
                                           px-2 py-1 bg-black/90 text-white text-xs rounded opacity-0 
                                           group-hover:opacity-100 transition-opacity whitespace-nowrap z-30">
                              {gamemode}: {points} pts
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  ))}
                </div>
              </div>

              {/* Footer */}
              <div className="text-center text-gray-500 text-xs mt-4 pt-3 border-t border-gray-700/50">
                Tap outside to close
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
