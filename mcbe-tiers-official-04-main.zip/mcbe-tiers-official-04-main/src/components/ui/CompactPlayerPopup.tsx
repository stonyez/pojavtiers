import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Monitor, Smartphone, Gamepad, Trophy, Crown, Star, Shield, Gem, Award } from 'lucide-react';
import { GameModeIcon } from '@/components/GameModeIcon';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { usePopup } from '@/contexts/PopupContext';
import { GameMode } from '@/services/playerService';
import { getAvatarUrl, handleAvatarError } from '@/utils/avatarUtils';
import { getPlayerRank } from '@/utils/rankUtils';

// Enhanced region graphics component
const RegionDisplay = ({ region }: { region?: string }) => {
  const regionCode = region || 'NA';
  
  const regionConfig: Record<string, { name: string; color: string; icon: string }> = {
    'NA': { name: 'North America', color: '#3b82f6', icon: '🇺🇸' },
    'EU': { name: 'Europe', color: '#8b5cf6', icon: '🇪🇺' },
    'ASIA': { name: 'Asia', color: '#ef4444', icon: '🌏' },
    'AS': { name: 'Asia', color: '#ef4444', icon: '🌏' },
    'SA': { name: 'South America', color: '#f97316', icon: '🌎' },
    'AF': { name: 'Africa', color: '#ec4899', icon: '🌍' },
    'OCE': { name: 'Oceania', color: '#06b6d4', icon: '🇦🇺' }
  };
  
  const config = regionConfig[regionCode] || regionConfig['NA'];
  
  return (
    <div className="flex items-center gap-2">
      <div 
        className="w-5 h-5 rounded-full flex items-center justify-center text-xs border"
        style={{ 
          backgroundColor: `${config.color}20`,
          borderColor: `${config.color}50`
        }}
      >
        <span>{config.icon}</span>
      </div>
      <span className="text-gray-300 text-sm font-medium">{config.name}</span>
    </div>
  );
};

// Enhanced rank icon with effects
const RankIcon = ({ points }: { points: number }) => {
  const getRankConfig = () => {
    if (points >= 400) {
      return { 
        icon: Gem, 
        gradient: 'from-purple-500 via-pink-500 to-purple-600',
        text: 'Combat Grandmaster',
        effectType: 'legendary'
      };
    } else if (points >= 250) {
      return { 
        icon: Crown, 
        gradient: 'from-yellow-400 via-amber-500 to-orange-500',
        text: 'Combat Master',
        effectType: 'royal'
      };
    } else if (points >= 100) {
      return { 
        icon: Star, 
        gradient: 'from-blue-400 via-cyan-500 to-blue-600',
        text: 'Combat Ace',
        effectType: 'stellar'
      };
    } else if (points >= 50) {
      return { 
        icon: Shield, 
        gradient: 'from-green-400 via-emerald-500 to-green-600',
        text: 'Combat Specialist',
        effectType: 'guardian'
      };
    } else if (points >= 20) {
      return { 
        icon: Award, 
        gradient: 'from-orange-400 via-amber-500 to-orange-600',
        text: 'Combat Cadet',
        effectType: 'warrior'
      };
    }
    return { 
      icon: Trophy, 
      gradient: 'from-gray-400 to-gray-600',
      text: 'Rookie',
      effectType: 'novice'
    };
  };

  const config = getRankConfig();
  const IconComponent = config.icon;

  return (
    <div className={`flex items-center gap-2 px-4 py-2 rounded-lg bg-gradient-to-r ${config.gradient} text-white shadow-lg`}>
      <IconComponent className="w-5 h-5" />
      <span className="text-sm font-bold">{config.text}</span>
    </div>
  );
};

// Device icon component
const DeviceIcon = ({ device }: { device?: string }) => {
  switch(device?.toLowerCase()) {
    case 'mobile':
    case 'bedrock':
      return <Smartphone className="w-5 h-5 text-blue-400" />;
    case 'console':
      return <Gamepad className="w-5 h-5 text-green-400" />;
    case 'pc':
    case 'java':
    default:
      return <Monitor className="w-5 h-5 text-gray-300" />;
  }
};

// Regional theming system
const getRegionTheme = (region: string = 'NA') => {
  const themes: Record<string, {
    primary: string;
    bg: string;
    border: string;
  }> = {
    'NA': {
      primary: '#3b82f6',
      bg: 'from-blue-900/20 to-slate-900/40',
      border: 'border-blue-500/30'
    },
    'EU': {
      primary: '#8b5cf6',
      bg: 'from-purple-900/20 to-slate-900/40',
      border: 'border-purple-500/30'
    },
    'ASIA': {
      primary: '#ef4444',
      bg: 'from-red-900/20 to-slate-900/40',
      border: 'border-red-500/30'
    },
    'AS': {
      primary: '#ef4444',
      bg: 'from-red-900/20 to-slate-900/40',
      border: 'border-red-500/30'
    },
    'SA': {
      primary: '#f97316',
      bg: 'from-orange-900/20 to-slate-900/40',
      border: 'border-orange-500/30'
    },
    'AF': {
      primary: '#ec4899',
      bg: 'from-pink-900/20 to-slate-900/40',
      border: 'border-pink-500/30'
    },
    'OCE': {
      primary: '#06b6d4',
      bg: 'from-cyan-900/20 to-slate-900/40',
      border: 'border-cyan-500/30'
    }
  };
  
  return themes[region] || themes['NA'];
};

// Tier styling function
const getTierStyle = (tier: string) => {
  const tierStyles: Record<string, { code: string; color: string }> = {
    'HT1': { code: 'HT1', color: '#fbbf24' },
    'LT1': { code: 'LT1', color: '#fbbf24' },
    'HT2': { code: 'HT2', color: '#fbbf24' },
    'LT2': { code: 'LT2', color: '#fbbf24' },
    'HT3': { code: 'HT3', color: '#fbbf24' },
    'LT3': { code: 'LT3', color: '#fbbf24' },
    'HT4': { code: 'HT4', color: '#fbbf24' },
    'LT4': { code: 'LT4', color: '#fbbf24' },
    'HT5': { code: 'HT5', color: '#fbbf24' },
    'LT5': { code: 'LT5', color: '#fbbf24' },
    'Retired': { code: 'RT', color: '#6b7280' }
  };
  
  return tierStyles[tier] || { code: 'NR', color: '#6b7280' };
};

// Rank-based particle effects
const RankEffects = ({ points }: { points: number }) => {
  if (points >= 400) {
    // Legendary effects - fire + lightning
    return (
      <>
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          {Array.from({ length: 12 }).map((_, i) => (
            <motion.div
              key={i}
              className="absolute w-2 h-2 bg-gradient-to-t from-purple-500 to-pink-400 rounded-full"
              initial={{ x: Math.random() * 400, y: 400 }}
              animate={{
                x: Math.random() * 400,
                y: -50,
                opacity: [0, 1, 0],
                scale: [0.5, 1.5, 0.5]
              }}
              transition={{
                duration: 3,
                repeat: Infinity,
                delay: i * 0.3,
                ease: "easeOut"
              }}
            />
          ))}
        </div>
        <motion.div
          className="absolute inset-0 bg-gradient-to-br from-purple-500/20 to-pink-500/20 rounded-xl"
          animate={{ 
            opacity: [0.3, 0.8, 0.3],
            scale: [1, 1.02, 1]
          }}
          transition={{ duration: 2, repeat: Infinity }}
        />
        <motion.div
          className="absolute -inset-1 bg-gradient-to-r from-purple-600 via-pink-600 to-purple-600 rounded-xl opacity-75 blur-sm"
          animate={{ rotate: 360 }}
          transition={{ duration: 8, repeat: Infinity, ease: "linear" }}
        />
      </>
    );
  } else if (points >= 250) {
    // Royal effects - golden fire
    return (
      <>
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          {Array.from({ length: 8 }).map((_, i) => (
            <motion.div
              key={i}
              className="absolute w-1.5 h-1.5 bg-gradient-to-t from-yellow-500 to-orange-400 rounded-full"
              initial={{ x: Math.random() * 350, y: 350 }}
              animate={{
                x: Math.random() * 350,
                y: -30,
                opacity: [0, 1, 0]
              }}
              transition={{
                duration: 2.5,
                repeat: Infinity,
                delay: i * 0.4,
                ease: "easeOut"
              }}
            />
          ))}
        </div>
        <motion.div
          className="absolute inset-0 bg-gradient-to-br from-yellow-500/15 to-orange-500/15 rounded-xl"
          animate={{ opacity: [0.2, 0.6, 0.2] }}
          transition={{ duration: 2.5, repeat: Infinity }}
        />
      </>
    );
  } else if (points >= 100) {
    // Stellar effects - water/ice
    return (
      <>
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          {Array.from({ length: 6 }).map((_, i) => (
            <motion.div
              key={i}
              className="absolute w-1 h-1 bg-blue-400 rounded-full opacity-70"
              initial={{ x: Math.random() * 300, y: 300 }}
              animate={{
                x: Math.random() * 300,
                y: -20,
                opacity: [0, 0.8, 0]
              }}
              transition={{
                duration: 3,
                repeat: Infinity,
                delay: i * 0.5,
                ease: "easeOut"
              }}
            />
          ))}
        </div>
        <motion.div
          className="absolute inset-0 bg-gradient-to-br from-blue-500/10 to-cyan-500/10 rounded-xl"
          animate={{ opacity: [0.1, 0.4, 0.1] }}
          transition={{ duration: 3, repeat: Infinity }}
        />
      </>
    );
  } else if (points >= 50) {
    // Guardian effects - earth/nature
    return (
      <motion.div
        className="absolute inset-0 bg-gradient-to-br from-green-500/8 to-emerald-500/8 rounded-xl"
        animate={{ opacity: [0.1, 0.3, 0.1] }}
        transition={{ duration: 3.5, repeat: Infinity }}
      />
    );
  }
  return null;
};

export const CompactPlayerPopup = () => {
  const { showPopup, popupData, closePopup } = usePopup();

  if (!showPopup || !popupData) return null;

  const { player, tierAssignments } = popupData;
  const region = player.region || 'NA';
  const theme = getRegionTheme(region);
  const rankInfo = getPlayerRank(player.global_points || 0);

  // Split gamemodes into two rows (4 each)
  const allGamemodes: GameMode[] = ['Crystal', 'Sword', 'Axe', 'Mace', 'SMP', 'NethPot', 'Bedwars', 'UHC'];
  const firstRow = allGamemodes.slice(0, 4);
  const secondRow = allGamemodes.slice(4, 8);

  const handleOverlayClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) {
      closePopup();
    }
  };

  return (
    <AnimatePresence>
      {showPopup && (
        <motion.div
          className="fixed inset-0 z-[9999] flex items-center justify-center p-4"
          style={{
            background: 'rgba(0, 0, 0, 0.95)',
            backdropFilter: 'blur(20px)'
          }}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={handleOverlayClick}
        >
          <motion.div
            className={`relative w-full max-w-lg bg-slate-800 border-2 ${theme.border} rounded-xl overflow-hidden shadow-2xl`}
            style={{
              boxShadow: `0 0 40px ${theme.primary}40, 0 20px 60px rgba(0, 0, 0, 0.8)`
            }}
            initial={{ scale: 0.8, opacity: 0, y: 30 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.8, opacity: 0, y: 30 }}
            transition={{ type: "spring", stiffness: 300, damping: 25 }}
            onClick={(e) => e.stopPropagation()}
          >
            {/* Rank-based effects */}
            <RankEffects points={player.global_points || 0} />

            {/* Regional gradient overlay */}
            <div className={`absolute inset-0 bg-gradient-to-br ${theme.bg} opacity-70`} />

            {/* Close button */}
            <motion.button 
              onClick={closePopup}
              className="absolute top-4 right-4 z-20 text-gray-400 hover:text-white transition-colors 
                         bg-black/40 rounded-full p-2 hover:bg-black/60"
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
            >
              <X className="h-5 w-5" />
            </motion.button>

            {/* Content */}
            <div className="relative z-10 p-6 space-y-4">
              {/* Player Header */}
              <div className="flex flex-col items-center space-y-3">
                {/* Avatar */}
                <motion.div
                  className="relative"
                  initial={{ scale: 0.8, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  transition={{ delay: 0.2 }}
                >
                  <div 
                    className="w-20 h-20 rounded-full p-1"
                    style={{
                      background: `linear-gradient(135deg, ${theme.primary}, ${theme.primary}CC)`,
                      boxShadow: `0 0 30px ${theme.primary}50`
                    }}
                  >
                    <Avatar className="w-full h-full">
                      <AvatarImage 
                        src={player.avatar_url || getAvatarUrl(player.ign, player.java_username)}
                        alt={player.ign}
                        onError={(e) => handleAvatarError(e, player.ign, player.java_username)}
                      />
                      <AvatarFallback className="bg-gradient-to-br from-blue-500 to-purple-600 text-white font-bold text-xl">
                        {player.ign.charAt(0)}
                      </AvatarFallback>
                    </Avatar>
                  </div>
                </motion.div>

                {/* Player name with device icon */}
                <motion.div 
                  className="flex items-center gap-2"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 }}
                >
                  <DeviceIcon device={player.device} />
                  <h2 className="text-xl font-bold text-white">{player.ign}</h2>
                </motion.div>

                {/* Rank badge */}
                <motion.div
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: 0.4 }}
                >
                  <RankIcon points={player.global_points || 0} />
                </motion.div>

                {/* Region */}
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.5 }}
                >
                  <RegionDisplay region={region} />
                </motion.div>
              </div>

              {/* Position Section */}
              <motion.div
                className="text-center"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.6 }}
              >
                <div className="text-gray-400 text-sm font-medium uppercase tracking-wider mb-2">Position</div>
                <div 
                  className="flex items-center justify-center gap-3 text-white rounded-lg px-4 py-3 text-lg font-bold"
                  style={{
                    background: `linear-gradient(135deg, ${theme.primary}40, ${theme.primary}20)`,
                    border: `1px solid ${theme.primary}50`
                  }}
                >
                  <Trophy className="w-5 h-5 text-yellow-400" />
                  <span>#{player.overall_rank || 1} OVERALL</span>
                  <span className="text-gray-300">({player.global_points || 0} Points)</span>
                </div>
              </motion.div>

              {/* Tiers Section */}
              <motion.div
                className="space-y-3"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.7 }}
              >
                <div className="text-gray-400 text-sm font-medium uppercase tracking-wider text-center">
                  Tiers
                </div>
                
                {/* First row of gamemodes */}
                <div className="grid grid-cols-4 gap-3">
                  {firstRow.map((gamemode, index) => {
                    const assignment = tierAssignments.find(a => a.gamemode === gamemode);
                    const tier = assignment?.tier || 'Not Ranked';
                    const tierStyle = getTierStyle(tier);
                    const points = assignment?.score || 0;
                    
                    return (
                      <motion.div 
                        key={gamemode} 
                        className="group relative flex flex-col items-center"
                        whileHover={{ scale: 1.05, y: -2 }}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.8 + index * 0.05, type: "spring", stiffness: 400, damping: 10 }}
                      >
                        <div className="flex flex-col items-center space-y-2">
                          <div 
                            className="w-10 h-10 rounded-lg border flex items-center justify-center backdrop-blur-sm transition-all"
                            style={{
                              borderColor: `${theme.primary}50`,
                              background: `rgba(255,255,255,0.1)`
                            }}
                          >
                            <GameModeIcon mode={gamemode.toLowerCase()} className="h-6 w-6" />
                          </div>
                          <div 
                            className="text-xs px-2 py-1 font-bold rounded border"
                            style={{
                              color: tierStyle.color,
                              borderColor: `${tierStyle.color}50`,
                              background: `${tierStyle.color}20`
                            }}
                          >
                            {tierStyle.code}
                          </div>
                        </div>
                        
                        {/* Tooltip */}
                        <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 
                                       px-2 py-1 bg-black/95 text-white text-xs rounded opacity-0 
                                       group-hover:opacity-100 transition-all duration-200 whitespace-nowrap z-30
                                       border border-white/20 shadow-xl">
                          <div className="font-bold">{gamemode}</div>
                          <div className="text-gray-300">{points} points</div>
                          <div className="absolute top-full left-1/2 transform -translate-x-1/2 w-0 h-0 
                                         border-l-2 border-r-2 border-t-2 border-transparent border-t-black/95"></div>
                        </div>
                      </motion.div>
                    );
                  })}
                </div>

                {/* Second row of gamemodes */}
                <div className="grid grid-cols-4 gap-3">
                  {secondRow.map((gamemode, index) => {
                    const assignment = tierAssignments.find(a => a.gamemode === gamemode);
                    const tier = assignment?.tier || 'Not Ranked';
                    const tierStyle = getTierStyle(tier);
                    const points = assignment?.score || 0;
                    
                    return (
                      <motion.div 
                        key={gamemode} 
                        className="group relative flex flex-col items-center"
                        whileHover={{ scale: 1.05, y: -2 }}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.9 + index * 0.05, type: "spring", stiffness: 400, damping: 10 }}
                      >
                        <div className="flex flex-col items-center space-y-2">
                          <div 
                            className="w-10 h-10 rounded-lg border flex items-center justify-center backdrop-blur-sm transition-all"
                            style={{
                              borderColor: `${theme.primary}50`,
                              background: `rgba(255,255,255,0.1)`
                            }}
                          >
                            <GameModeIcon mode={gamemode.toLowerCase()} className="h-6 w-6" />
                          </div>
                          <div 
                            className="text-xs px-2 py-1 font-bold rounded border"
                            style={{
                              color: tierStyle.color,
                              borderColor: `${tierStyle.color}50`,
                              background: `${tierStyle.color}20`
                            }}
                          >
                            {tierStyle.code}
                          </div>
                        </div>
                        
                        {/* Tooltip */}
                        <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 
                                       px-2 py-1 bg-black/95 text-white text-xs rounded opacity-0 
                                       group-hover:opacity-100 transition-all duration-200 whitespace-nowrap z-30
                                       border border-white/20 shadow-xl">
                          <div className="font-bold">{gamemode}</div>
                          <div className="text-gray-300">{points} points</div>
                          <div className="absolute top-full left-1/2 transform -translate-x-1/2 w-0 h-0 
                                         border-l-2 border-r-2 border-t-2 border-transparent border-t-black/95"></div>
                        </div>
                      </motion.div>
                    );
                  })}
                </div>
              </motion.div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
