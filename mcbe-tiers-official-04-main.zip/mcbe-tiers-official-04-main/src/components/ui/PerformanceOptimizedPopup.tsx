
import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { X } from 'lucide-react';
import { shouldDisableEffects, shouldReduceMotion } from '@/utils/mobilePerformanceOptimizer';

interface PerformanceOptimizedPopupProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  children: React.ReactNode;
  className?: string;
}

export function PerformanceOptimizedPopup({ 
  isOpen, 
  onClose, 
  title, 
  children, 
  className = "" 
}: PerformanceOptimizedPopupProps) {
  const [shouldUseOptimizedMode, setShouldUseOptimizedMode] = useState(false);

  useEffect(() => {
    setShouldUseOptimizedMode(shouldDisableEffects());
  }, []);

  // For mobile devices, use a performance-optimized modal
  if (shouldUseOptimizedMode) {
    return (
      <>
        {isOpen && (
          <div 
            className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4"
            style={{ 
              // Use CSS transforms for better mobile performance
              transform: 'translateZ(0)',
              willChange: 'opacity',
              backfaceVisibility: 'hidden'
            }}
          >
            <div 
              className={`bg-gray-900 rounded-lg w-full max-w-md max-h-[90vh] overflow-y-auto ${className}`}
              style={{
                transform: 'translateZ(0)',
                willChange: 'transform',
                backfaceVisibility: 'hidden'
              }}
            >
              <div className="flex items-center justify-between p-4 border-b border-gray-700">
                <h3 className="text-lg font-semibold text-white">{title}</h3>
                <Button
                  onClick={onClose}
                  size="sm"
                  variant="ghost"
                  className="text-gray-400 hover:text-white"
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
              <div className="p-4">
                {children}
              </div>
            </div>
          </div>
        )}
      </>
    );
  }

  // For desktop, use the regular dialog with animations
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className={`bg-gray-900 border-gray-700 ${className}`}>
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-white">{title}</h3>
          <Button
            onClick={onClose}
            size="sm"
            variant="ghost"
            className="text-gray-400 hover:text-white"
          >
            <X className="h-4 w-4" />
          </Button>
        </div>
        {children}
      </DialogContent>
    </Dialog>
  );
}
