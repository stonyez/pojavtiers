
import { Database } from '@/integrations/supabase/types';

type TierLevel = Database['public']['Enums']['tier_level'];

export const TIER_POINTS: Record<string, number> = {
  'RHT1': 50,
  'RLT1': 45,
  'RHT2': 40,
  'RLT2': 35,
  'HT1': 50,
  'LT1': 45,
  'HT2': 40,
  'LT2': 35,
  'HT3': 30,
  'LT3': 25,
  'HT4': 20,
  'LT4': 15,
  'HT5': 10,
  'LT5': 5,
  'Retired': 0
};

export const calculatePoints = (tier: string): number => {
  console.log('Calculating points for tier:', tier);
  const points = TIER_POINTS[tier] || 0;
  console.log('Points calculated:', points);
  return points;
};

export const getTierDisplayName = (tier: string): string => {
  const displayNames: Record<string, string> = {
    'RHT1': 'Retired HT1',
    'RLT1': 'Retired LT1', 
    'RHT2': 'Retired HT2',
    'RLT2': 'Retired LT2',
    'HT1': 'High Tier 1',
    'LT1': 'Low Tier 1',
    'HT2': 'High Tier 2',
    'LT2': 'Low Tier 2',
    'HT3': 'High Tier 3',
    'LT3': 'Low Tier 3',
    'HT4': 'High Tier 4',
    'LT4': 'Low Tier 4',
    'HT5': 'High Tier 5',
    'LT5': 'Low Tier 5',
    'Retired': 'Retired'
  };
  
  return displayNames[tier] || tier;
};

export const getAllTiers = (): string[] => {
  return Object.keys(TIER_POINTS);
};

export const getActiveTiers = (): string[] => {
  return getAllTiers().filter(tier => tier !== 'Retired');
};
