
# MCBE-Tiers Backend Overhaul & Admin Panel Redesign

## 🎯 Project Overview
Complete rebuild of the MCBE-Tiers admin backend system with modern architecture, AI-powered assistance, and professional-grade controls.

## 📊 Current System Assessment
- Multiple TypeScript errors in player services
- Inconsistent database schema relationships
- Legacy webhook and logging systems
- Fragmented admin UI components
- Manual point calculation issues

## 🔧 Phase 1: Database Schema Redesign
### Tables to Recreate:
1. **players** - Core player data with proper foreign keys
2. **gamemode_scores** - Tier assignments with automated point calculation
3. **admin_users** - Enhanced admin access control
4. **system_backups** - Google Drive integration tracking
5. **ai_chat_sessions** - Chatbot interaction logs

### Key Improvements:
- Proper foreign key relationships
- Automated tier point calculation triggers
- Better indexing for search performance
- Audit trails for all data changes

## 🤖 Phase 2: AI Integration (Deepseek via OpenRouter)
### Chatbot 1: Carlos Hathcock (Admin Assistant)
- **Model**: `deepseek/deepseek-chat-v3-0324:free`
- **Personality**: Military/Tactical
- **Functions**: System debugging, admin assistance, command execution

### Chatbot 2: Knowledge Base Assistant
- **Model**: `deepseek/deepseek-r1-0528:free`
- **Functions**: Documentation queries, rule explanations, system help

### API Configuration:
```typescript
const OPENROUTER_API_KEY = "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";
const API_BASE = "https://openrouter.ai/api/v1/chat/completions";
```

## 🎨 Phase 3: Admin Panel UI Redesign
### Features to Remove:
- Welcome landing messages
- System monitoring logs
- Legacy webhooks
- Old popup notifications
- Outdated styling components

### Features to Add:
- Dark/Light mode toggle
- Modern component library (shadcn/ui)
- Responsive design
- AI chat interfaces
- Advanced search with instant edit

## 📤 Phase 4: Submission System Overhaul
### Single Submission Enhancement:
- Multi-gamemode tier assignment in one form
- Real-time point calculation preview
- Validation and error handling
- Success confirmation with details

### Mass Submission Improvement:
- CSV/JSON import support
- Batch processing with progress tracking
- Error reporting per entry
- Rollback capabilities

## 👤 Phase 5: User Management System
### Enhanced Edit Capabilities:
- All attributes except UUID
- Multi-gamemode tier editing
- Instant search → edit workflow
- Change history tracking

### Search Index Integration:
- Fast IGN-based search
- Click-to-edit functionality
- Modal-based editing interface
- Real-time updates

## ☁️ Phase 6: Google Drive Integration
### Daily Backup System:
- Automated database exports
- Google Drive API integration
- Admin Google account linking
- Backup verification and reporting

## 🗂️ Implementation Timeline
1. **Week 1**: Database schema redesign and migration
2. **Week 2**: AI chatbot integration and testing
3. **Week 3**: Admin panel UI redesign
4. **Week 4**: Submission system overhaul
5. **Week 5**: User management enhancement
6. **Week 6**: Google Drive integration and final testing

## 🎖️ Success Metrics
- Zero TypeScript compilation errors
- 100% functional admin features
- <200ms search response times
- Automated daily backups
- AI response accuracy >95%
- Admin satisfaction score >9/10

## 🚀 Next Steps
1. Fix immediate TypeScript errors
2. Begin database schema analysis
3. Set up development environment for new architecture
4. Create migration scripts for data preservation
