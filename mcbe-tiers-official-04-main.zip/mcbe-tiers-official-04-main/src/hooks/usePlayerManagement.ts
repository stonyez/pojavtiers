
import { useState, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { Database } from '@/integrations/supabase/types';
import { calculatePoints } from '@/lib/pointsCalculation';

type Player = Database['public']['Tables']['players']['Row'] & {
  gamemode_scores: Database['public']['Tables']['gamemode_scores']['Row'][];
};

type GameMode = Database['public']['Enums']['gamemode_type'];
type TierLevel = Database['public']['Enums']['tier_level'];

interface PlayerSubmission {
  ign: string;
  gamemode: string;
  tier: string;
  score: number;
  javaUsername?: string;
  region?: string;
  device?: string;
}

export function usePlayerManagement() {
  const [players, setPlayers] = useState<Player[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();

  const refreshPlayers = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    
    try {
      const { data, error: fetchError } = await supabase
        .from('players')
        .select(`
          *,
          gamemode_scores (*)
        `)
        .order('global_points', { ascending: false });

      if (fetchError) throw fetchError;
      
      setPlayers(data || []);
    } catch (err: any) {
      setError(err.message);
      toast({
        title: "Error",
        description: "Failed to fetch players",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  }, [toast]);

  const submitPlayerResults = useCallback(async (submissions: PlayerSubmission[]) => {
    try {
      console.log('Submitting player results:', submissions);
      
      for (const submission of submissions) {
        if (!submission.ign || !submission.region || !submission.device) {
          throw new Error('IGN, Region, and Device are required fields');
        }

        console.log('Processing submission for:', submission.ign);

        let { data: existingPlayer } = await supabase
          .from('players')
          .select('id')
          .eq('ign', submission.ign)
          .single();

        let playerId: string;

        if (!existingPlayer) {
          console.log('Creating new player:', submission.ign);
          const { data: newPlayer, error: playerError } = await supabase
            .from('players')
            .insert({
              ign: submission.ign,
              java_username: submission.javaUsername,
              region: submission.region as "NA" | "EU" | "AS",
              device: submission.device as "Mobile" | "PC" | "Console",
              global_points: 0
            })
            .select('id')
            .single();

          if (playerError) {
            console.error('Player creation error:', playerError);
            throw playerError;
          }
          playerId = newPlayer.id;
        } else {
          playerId = existingPlayer.id;
          console.log('Updating existing player:', submission.ign);
          
          if (submission.region || submission.device) {
            const { error: updateError } = await supabase
              .from('players')
              .update({
                region: submission.region as "NA" | "EU" | "AS",
                device: submission.device as "Mobile" | "PC" | "Console",
                updated_at: new Date().toISOString()
              })
              .eq('id', playerId);

            if (updateError) {
              console.error('Player update error:', updateError);
              throw updateError;
            }
          }
        }

        console.log('Upserting gamemode score for:', submission.gamemode, 'tier:', submission.tier);
        
        const points = calculatePoints(submission.tier);
        console.log('Calculated points:', points);

        const { error: scoreError } = await supabase
          .from('gamemode_scores')
          .upsert({
            player_id: playerId,
            gamemode: submission.gamemode as GameMode,
            internal_tier: submission.tier as TierLevel,
            display_tier: submission.tier as TierLevel,
            score: submission.score,
            points: points
          });

        if (scoreError) {
          console.error('Gamemode score error:', scoreError);
          throw scoreError;
        }

        console.log('Successfully processed submission for:', submission.ign);
      }

      await refreshPlayers();
      return { success: true };
    } catch (error: any) {
      console.error('Submit player results error:', error);
      return { success: false, error: error.message };
    }
  }, [refreshPlayers]);

  const updatePlayerTier = useCallback(async (
    playerId: string,
    gamemode: GameMode,
    tier: TierLevel,
    score: number
  ) => {
    try {
      const { error } = await supabase
        .from('gamemode_scores')
        .upsert({
          player_id: playerId,
          gamemode,
          internal_tier: tier,
          display_tier: tier,
          score,
          points: calculatePoints(tier)
        });

      if (error) throw error;

      await refreshPlayers();
      return { success: true };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }, [refreshPlayers]);

  const deletePlayer = useCallback(async (playerId: string) => {
    try {
      const { error } = await supabase
        .from('players')
        .delete()
        .eq('id', playerId);

      if (error) throw error;

      await refreshPlayers();
      toast({
        title: "Success",
        description: "Player deleted successfully"
      });
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive"
      });
    }
  }, [refreshPlayers, toast]);

  const banPlayer = useCallback(async (playerId: string, banned: boolean, reason?: string) => {
    try {
      const { error } = await supabase
        .from('players')
        .update({ 
          banned,
          ban_reason: banned ? reason : null
        })
        .eq('id', playerId);

      if (error) throw error;

      await refreshPlayers();
      toast({
        title: "Success",
        description: `Player ${banned ? 'banned' : 'unbanned'} successfully`
      });
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive"
      });
    }
  }, [refreshPlayers, toast]);

  return {
    players,
    isLoading,
    error,
    refreshPlayers,
    submitPlayerResults,
    updatePlayerTier,
    deletePlayer,
    banPlayer
  };
}
