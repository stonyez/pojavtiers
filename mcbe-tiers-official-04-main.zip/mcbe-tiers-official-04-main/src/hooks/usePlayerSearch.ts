
import { useState, useEffect, useMemo } from 'react';
import { useDebounce } from './useDebounce';
import { supabase } from '@/integrations/supabase/client';

export interface Player {
  id: string;
  ign: string;
  java_username?: string;
  region: string;
  device?: string;
  global_points: number;
  overall_rank: number;
  avatar_url?: string;
  banned: boolean;
  created_at: string;
  updated_at: string;
  gamemode_scores?: Array<{
    gamemode: string;
    internal_tier: string;
    display_tier: string;
    points: number;
  }>;
}

export function usePlayerSearch() {
  const [query, setQuery] = useState<string>('');
  const debouncedQuery = useDebounce(query, 300);
  const [results, setResults] = useState<Player[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  
  const performSearch = useMemo(() => async (searchQuery: string) => {
    if (!searchQuery || searchQuery.length < 2) {
      setResults([]);
      setIsLoading(false);
      return;
    }
    
    setIsLoading(true);
    setError(null);
    
    try {
      console.log('Searching for players with query:', searchQuery);
      
      const { data, error: searchError } = await supabase
        .from('players')
        .select(`
          *,
          gamemode_scores (
            gamemode,
            internal_tier,
            display_tier,
            points
          )
        `)
        .or(`ign.ilike.%${searchQuery}%,java_username.ilike.%${searchQuery}%`)
        .order('global_points', { ascending: false })
        .limit(10);

      if (searchError) {
        console.error('Search error:', searchError);
        throw searchError;
      }
      
      console.log('Search results:', data);
      
      const processedResults = (data || []).map(player => ({
        ...player,
        region: player.region || 'NA',
        overall_rank: player.overall_rank || 0
      }));
      
      setResults(processedResults);
    } catch (err) {
      console.error('Player search error:', err);
      setError(err instanceof Error ? err.message : 'Search failed');
      setResults([]);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    performSearch(debouncedQuery);
  }, [debouncedQuery, performSearch]);

  const clearSearch = () => {
    setQuery('');
    setResults([]);
    setError(null);
  };

  return {
    query,
    setQuery,
    results,
    isLoading,
    error,
    clearSearch
  };
}
