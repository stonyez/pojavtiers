
import { useEffect, useRef } from 'react';
import { realTimeLogger, RealLogEntry } from '@/services/realTimeLogger';

export function useRealTimeLogger() {
  const apiCallCounter = useRef(0);

  useEffect(() => {
    console.log('Real-time logger hook initialized');
    
    // Intercept fetch requests to log real API calls
    const originalFetch = window.fetch;
    window.fetch = async (...args) => {
      const startTime = Date.now();
      const url = args[0] as string;
      const options = args[1] as RequestInit;
      
      try {
        const response = await originalFetch(...args);
        const endTime = Date.now();
        const responseTime = endTime - startTime;
        
        // Only log API calls, not webhook calls
        if (url.includes('/rest/v1/') || url.includes('/api/')) {
          realTimeLogger.logApiCall(
            url.split('?')[0], // Remove query params
            options?.method || 'GET',
            response.status,
            responseTime
          );
        }
        
        return response;
      } catch (error) {
        const endTime = Date.now();
        const responseTime = endTime - startTime;
        
        realTimeLogger.logApiCall(
          url.split('?')[0],
          options?.method || 'GET',
          0, // Error status
          responseTime
        );
        
        throw error;
      }
    };

    return () => {
      window.fetch = originalFetch;
    };
  }, []);

  // Manual logging functions for components
  const logDatabaseOperation = (action: string, table: string, details?: any) => {
    realTimeLogger.logDatabaseOperation(action, table, details);
  };

  const getRecentLogs = (): RealLogEntry[] => {
    return realTimeLogger.getRecentRealLogs();
  };

  const getPerformanceData = () => {
    return realTimeLogger.getRealPerformanceData();
  };

  return {
    logDatabaseOperation,
    getRecentLogs,
    getPerformanceData
  };
}
