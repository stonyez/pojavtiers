import { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { realTimeLogger } from '@/services/realTimeLogger';
import { enhancedWebhookService } from '@/services/enhancedWebhookService';
import { staffLoggingService } from '@/services/staffLoggingService';
import { newAdminService } from '@/services/newAdminService';

export const useAdminPanel = () => {
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const submitResult = async (playerData: any) => {
    setIsLoading(true);
    try {
      const startTime = Date.now();
      
      // Log the staff operation to staff_logs table
      const currentRole = newAdminService.getCurrentRole();
      const deviceId = localStorage.getItem('admin_device_id') || 'unknown';
      const username = `${currentRole}#MCBETIERS.com`;
      
      await staffLoggingService.logStaffOperation(
        'system-generated-id',
        deviceId,
        username,
        'Player Result Submitted',
        {
          player: playerData.ign,
          gamemode: playerData.gamemode,
          tier: playerData.tier,
          score: playerData.score,
          submittedBy: currentRole
        }
      );

      // Create structured log
      const apiLog = {
        category: 'api_call',
        log: `[${new Date().toISOString()}] API_CALL: POST /api/admin/submit-result - Processing player result for ${playerData.ign}`,
        timestamp: new Date().toISOString(),
        verified: true,
        metadata: {
          endpoint: '/api/admin/submit-result',
          method: 'POST',
          status: 200,
          contentLength: JSON.stringify(playerData).length,
          userAgent: navigator.userAgent,
          ipAddress: 'admin-panel'
        }
      };

      await enhancedWebhookService.sendWebhook('logbox', apiLog);

      let playerId: string;

      // Check if player exists
      const { data: existingPlayer } = await supabase
        .from('players')
        .select('id, ign, java_username, uuid, region, device, global_points, overall_rank, avatar_url')
        .eq('ign', playerData.ign)
        .single();

      if (existingPlayer) {
        playerId = existingPlayer.id;
        
        // Update existing player
        const { error: updateError } = await supabase
          .from('players')
          .update({
            java_username: playerData.javaUsername || existingPlayer.java_username,
            uuid: playerData.uuid || existingPlayer.uuid,
            region: playerData.region || existingPlayer.region,
            device: playerData.device || existingPlayer.device,
            updated_at: new Date().toISOString()
          })
          .eq('id', playerId);

        if (updateError) throw updateError;
      } else {
        // Create new player
        const { data: newPlayer, error: insertError } = await supabase
          .from('players')
          .insert({
            ign: playerData.ign,
            java_username: playerData.javaUsername,
            uuid: playerData.uuid,
            region: playerData.region,
            device: playerData.device,
            avatar_url: `https://mc-heads.net/avatar/${playerData.javaUsername || playerData.ign}/100`
          })
          .select('id, ign, java_username, uuid, region, device, global_points, overall_rank, avatar_url')
          .single();

        if (insertError) throw insertError;
        if (!newPlayer) throw new Error('Failed to create player');

        playerId = newPlayer.id;
      }

      // Get current player data for webhook
      const { data: currentPlayer } = await supabase
        .from('players')
        .select('*')
        .eq('id', playerId)
        .single();

      // Check if gamemode score exists
      const { data: existingScore } = await supabase
        .from('gamemode_scores')
        .select('*')
        .eq('player_id', playerId)
        .eq('gamemode', playerData.gamemode)
        .single();

      let previousTier = null;
      if (existingScore) {
        previousTier = existingScore.internal_tier;
        
        // Update existing score
        const { error: updateScoreError } = await supabase
          .from('gamemode_scores')
          .update({
            score: playerData.score,
            internal_tier: playerData.tier,
            display_tier: playerData.tier,
            updated_at: new Date().toISOString()
          })
          .eq('id', existingScore.id);

        if (updateScoreError) throw updateScoreError;
      } else {
        // Insert new score
        const { error: insertScoreError } = await supabase
          .from('gamemode_scores')
          .insert({
            player_id: playerId,
            gamemode: playerData.gamemode,
            score: playerData.score,
            internal_tier: playerData.tier,
            display_tier: playerData.tier
          });

        if (insertScoreError) throw insertScoreError;
      }

      // Send structured tier webhook
      if (currentPlayer) {
        const tierLog = {
          category: 'tier_update',
          log: `[${new Date().toISOString()}] TIER_UPDATE: Player ${currentPlayer.ign} assigned tier ${playerData.tier} in ${playerData.gamemode} with score ${playerData.score}`,
          timestamp: new Date().toISOString(),
          verified: true,
          metadata: {
            player: currentPlayer.ign,
            javaUsername: currentPlayer.java_username,
            playerUuid: currentPlayer.uuid,
            gamemode: playerData.gamemode,
            previousTier: previousTier,
            tier: playerData.tier,
            score: playerData.score,
            globalPoints: currentPlayer.global_points,
            overallRank: currentPlayer.overall_rank,
            region: currentPlayer.region,
            device: currentPlayer.device,
            avatarUrl: currentPlayer.avatar_url,
            action: previousTier ? 'Result Updated' : 'Result Posted'
          }
        };

        await enhancedWebhookService.sendWebhook('tier', tierLog);
      }

      // Log staff action
      const staffLog = {
        category: 'staff_action',
        log: `[${new Date().toISOString()}] STAFF_ACTION: Admin submitted result for player ${playerData.ign} - ${playerData.gamemode} ${playerData.tier}`,
        timestamp: new Date().toISOString(),
        verified: true,
        metadata: {
          action: 'Submit Player Result',
          adminUser: 'Admin',
          target: playerData.ign,
          actionCategory: 'Player Management',
          reason: 'Result submission via admin panel',
          affectedRecords: 2,
          severity: 'Medium'
        }
      };

      await enhancedWebhookService.sendWebhook('logbox', staffLog);

      toast({
        title: "Success",
        description: `Result submitted successfully for ${playerData.ign}. Operation logged for owner approval.`,
      });

      return { success: true };
    } catch (error: any) {
      console.error('Submit result error:', error);
      
      // Log error operation
      const currentRole = newAdminService.getCurrentRole();
      const deviceId = localStorage.getItem('admin_device_id') || 'unknown';
      const username = `${currentRole}#MCBETIERS.com`;
      
      await staffLoggingService.logStaffOperation(
        'system-generated-id',
        deviceId,
        username,
        'Player Result Submission Failed',
        {
          player: playerData.ign,
          error: error.message,
          submittedBy: currentRole
        }
      );

      toast({
        title: "Error",
        description: error.message || "Failed to submit result",
        variant: "destructive"
      });
      
      return { success: false, error: error.message };
    } finally {
      setIsLoading(false);
    }
  };

  const banPlayer = async (ign: string, reason: string) => {
    setIsLoading(true);
    try {
      const banLog = {
        category: 'staff_action',
        log: `[${new Date().toISOString()}] STAFF_ACTION: Admin banned player ${ign} - Reason: ${reason}`,
        timestamp: new Date().toISOString(),
        verified: true,
        metadata: {
          action: 'Ban Player',
          adminUser: 'Admin',
          target: ign,
          actionCategory: 'Player Management',
          reason: reason,
          affectedRecords: 1,
          severity: 'High'
        }
      };

      await enhancedWebhookService.sendWebhook('logbox', banLog);

      toast({
        title: "Success",
        description: `Player ${ign} has been banned.`,
      });

      return { success: true };
    } catch (error: any) {
      console.error('Ban player error:', error);
      
      toast({
        title: "Error",
        description: error.message || "Failed to ban player",
        variant: "destructive"
      });
      
      return { success: false, error: error.message };
    } finally {
      setIsLoading(false);
    }
  };

  const pardonPlayer = async (ign: string) => {
    setIsLoading(true);
    try {
      const pardonLog = {
        category: 'staff_action',
        log: `[${new Date().toISOString()}] STAFF_ACTION: Admin pardoned player ${ign} - Ban revoked`,
        timestamp: new Date().toISOString(),
        verified: true,
        metadata: {
          action: 'Pardon Player',
          adminUser: 'Admin',
          target: ign,
          actionCategory: 'Player Management',
          reason: 'Ban revoked via admin panel',
          affectedRecords: 1,
          severity: 'Low'
        }
      };

      await enhancedWebhookService.sendWebhook('logbox', pardonLog);

      toast({
        title: "Success",
        description: `Player ${ign} has been pardoned.`,
      });

      return { success: true };
    } catch (error: any) {
      console.error('Pardon player error:', error);
      
      toast({
        title: "Error",
        description: error.message || "Failed to pardon player",
        variant: "destructive"
      });
      
      return { success: false, error: error.message };
    } finally {
      setIsLoading(false);
    }
  };

  return {
    isLoading,
    submitResult,
    banPlayer,
    pardonPlayer
  };
};
