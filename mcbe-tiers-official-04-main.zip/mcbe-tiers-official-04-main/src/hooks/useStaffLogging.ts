
import { useState, useCallback } from 'react';
import { staffLoggingService, StaffLogEntry } from '@/services/staffLoggingService';
import { useToast } from '@/hooks/use-toast';

export function useStaffLogging() {
  const [logs, setLogs] = useState<StaffLogEntry[]>([]);
  const [pendingApprovals, setPendingApprovals] = useState<StaffLogEntry[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();

  const refreshLogs = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    
    try {
      const [allLogs, pending] = await Promise.all([
        staffLoggingService.getAllStaffLogs(),
        staffLoggingService.getPendingApprovals()
      ]);
      
      setLogs(allLogs);
      setPendingApprovals(pending);
    } catch (err: any) {
      setError(err.message);
      toast({
        title: "Error",
        description: "Failed to fetch staff logs",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  }, [toast]);

  const logOperation = useCallback(async (
    staffId: string,
    deviceId: string,
    username: string,
    operationType: string,
    operationDetails: any
  ) => {
    try {
      const result = await staffLoggingService.logStaffOperation(
        staffId,
        deviceId,
        username,
        operationType,
        operationDetails
      );
      
      if (result.success) {
        await refreshLogs();
        return { success: true, logId: result.logId };
      } else {
        throw new Error(result.error);
      }
    } catch (error: any) {
      toast({
        title: "Logging Failed",
        description: error.message,
        variant: "destructive"
      });
      return { success: false, error: error.message };
    }
  }, [refreshLogs, toast]);

  const approveOperation = useCallback(async (logId: string, remarks?: string) => {
    try {
      const result = await staffLoggingService.approveOperation(logId, remarks);
      
      if (result.success) {
        await refreshLogs();
        toast({
          title: "Operation Approved",
          description: "The staff operation has been approved and executed.",
        });
        return { success: true };
      } else {
        throw new Error(result.error);
      }
    } catch (error: any) {
      toast({
        title: "Approval Failed",
        description: error.message,
        variant: "destructive"
      });
      return { success: false, error: error.message };
    }
  }, [refreshLogs, toast]);

  const denyOperation = useCallback(async (logId: string, remarks?: string) => {
    try {
      const result = await staffLoggingService.denyOperation(logId, remarks);
      
      if (result.success) {
        await refreshLogs();
        toast({
          title: "Operation Denied",
          description: "The staff operation has been denied.",
        });
        return { success: true };
      } else {
        throw new Error(result.error);
      }
    } catch (error: any) {
      toast({
        title: "Denial Failed",
        description: error.message,
        variant: "destructive"
      });
      return { success: false, error: error.message };
    }
  }, [refreshLogs, toast]);

  return {
    logs,
    pendingApprovals,
    isLoading,
    error,
    refreshLogs,
    logOperation,
    approveOperation,
    denyOperation
  };
}
