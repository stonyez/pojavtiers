
import { useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { updatePlayerGlobalPoints } from '@/services/playerService';
import { autonomousWebhookService } from '@/services/autonomousWebhookService';

export function usePointsCalculation() {
  useEffect(() => {
    // Listen for changes in gamemode_scores table
    const channel = supabase
      .channel('gamemode-scores-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'gamemode_scores'
        },
        async (payload) => {
          console.log('Gamemode score changed:', payload);
          
          // Type-safe payload handling
          const newRecord = payload.new as any;
          const oldRecord = payload.old as any;
          
          // Update global points for the affected player
          if (newRecord?.player_id) {
            await updatePlayerGlobalPoints(newRecord.player_id);
            console.log('Updated global points for player:', newRecord.player_id);
          } else if (oldRecord?.player_id) {
            await updatePlayerGlobalPoints(oldRecord.player_id);
            console.log('Updated global points for player:', oldRecord.player_id);
          }

          // Enhanced tier webhook triggering with autonomous service
          if (payload.eventType === 'INSERT' || 
              (payload.eventType === 'UPDATE' && oldRecord?.internal_tier !== newRecord?.internal_tier)) {
            
            try {
              // Get player data for webhook
              const { data: playerData } = await supabase
                .from('players')
                .select('ign, java_username, uuid')
                .eq('id', newRecord.player_id)
                .single();

              if (playerData) {
                const actionType = payload.eventType === 'INSERT' ? 'Result Posted' : 'Result Updated';
                
                // Use autonomous service for reliable delivery
                await autonomousWebhookService.logTierUpdate(
                  playerData.ign,
                  newRecord.gamemode,
                  newRecord.internal_tier,
                  playerData.java_username,
                  playerData.uuid,
                  actionType
                );
                
                console.log(`Enhanced tier webhook triggered for: ${playerData.ign} - ${newRecord.internal_tier} in ${newRecord.gamemode}`);
              }
            } catch (error) {
              console.error('Error triggering enhanced tier webhook:', error);
            }
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);
}
