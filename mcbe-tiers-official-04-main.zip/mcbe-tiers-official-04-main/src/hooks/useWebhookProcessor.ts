
import { useEffect, useRef } from 'react';
import { autonomousWebhookService } from '@/services/autonomousWebhookService';
import { realTimeLogger } from '@/services/realTimeLogger';

export function useWebhookProcessor() {
  const intervalRef = useRef<NodeJS.Timeout | null>(null);
  const isInitialized = useRef(false);

  useEffect(() => {
    // Initialize the REAL autonomous service
    if (!isInitialized.current) {
      autonomousWebhookService.start().catch(console.error);
      isInitialized.current = true;
      console.log('MEGA FIX: Real autonomous webhook service initialized');
    }

    // Monitor service status (reduced frequency)
    intervalRef.current = setInterval(() => {
      const status = autonomousWebhookService.getStatus();
      if (!status.isRunning) {
        console.warn('Real autonomous webhook service stopped, restarting...');
        autonomousWebhookService.start().catch(console.error);
      }
    }, 60000); // Check every minute instead of 30 seconds

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, []);

  return {
    // Use real-time logger instead of fake autonomous service
    triggerTierLog: autonomousWebhookService.logTierUpdate.bind(autonomousWebhookService),
    getServiceStatus: autonomousWebhookService.getStatus.bind(autonomousWebhookService),
    getRecentLogs: () => realTimeLogger.getRecentRealLogs() // Use real logs
  };
}
