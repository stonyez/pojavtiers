import { supabase } from '@/integrations/supabase/client';

interface WebhookConfig {
  id: string;
  webhook_type: 'tier' | 'logbox';
  webhook_url: string;
  is_active: boolean;
  created_at?: string;
  updated_at?: string;
}

interface StructuredWebhookMessage {
  category: 'tier_update' | 'api_call' | 'database_operation' | 'system_monitor' | 'staff_action' | 'player_event';
  log: string;
  timestamp: string;
  verified: boolean;
  metadata?: any;
}

class EnhancedWebhookService {
  private configs: WebhookConfig[] = [];
  private retryQueue: Array<{ payload: any; retryCount: number; maxRetries: number; type: 'tier' | 'logbox' }> = [];
  private isInitialized = false;
  private offlineQueue: Array<{ type: 'tier' | 'logbox'; payload: any; timestamp: string }> = [];

  constructor() {
    this.initialize();
    this.startOfflineQueueProcessor();
  }

  private async initialize() {
    if (this.isInitialized) return;
    
    await this.loadConfigs();
    this.startRetryProcessor();
    this.isInitialized = true;
    console.log('Enhanced webhook service initialized successfully');
  }

  // Load webhook configurations with retry logic
  private async loadConfigs(): Promise<void> {
    try {
      console.log('Loading webhook configurations...');
      
      const { data, error } = await supabase
        .from('mcbe_webhook_configs')
        .select('*')
        .order('webhook_type');

      if (error) {
        console.error('Error loading webhook configs:', error);
        throw error;
      }

      this.configs = data || [];
      console.log('Loaded webhook configs:', this.configs.length);
      
      return;
    } catch (error) {
      console.error('Failed to load webhook configs:', error);
      // Retry after 2 seconds
      setTimeout(() => this.loadConfigs(), 2000);
    }
  }

  // Create structured webhook messages with proper categorization
  private createStructuredMessage(category: string, logData: any, realLog: string): StructuredWebhookMessage {
    return {
      category: category as any,
      log: realLog,
      timestamp: new Date().toISOString(),
      verified: true,
      metadata: logData
    };
  }

  // Create Discord embed with structured format
  private createDiscordEmbed(type: 'tier' | 'logbox', structuredMessage: StructuredWebhookMessage): any {
    const { category, log, timestamp, verified, metadata } = structuredMessage;
    
    const baseEmbed = {
      footer: { 
        text: `MCBE Tiers • ${verified ? 'Verified' : 'Unverified'} Log`,
        icon_url: 'https://mc-heads.net/avatar/notch/32'
      },
      timestamp: timestamp
    };

    switch (category) {
      case 'tier_update':
        return {
          embeds: [{
            ...baseEmbed,
            title: '🎖️ Tier Assignment Update',
            description: `**Category:** Tier Update\n**Log:** ${log}\n**Timestamp:** <t:${Math.floor(new Date(timestamp).getTime() / 1000)}:F>`,
            color: 0x00ffcc,
            fields: [
              {
                name: '👤 Player Information',
                value: `**IGN:** ${metadata.player || 'Unknown'}\n**Java Username:** ${metadata.javaUsername || 'N/A'}\n**UUID:** ${metadata.playerUuid ? metadata.playerUuid.slice(0, 8) + '...' : 'N/A'}`,
                inline: true
              },
              {
                name: '🎮 Game Details',
                value: `**Mode:** ${metadata.gamemode || 'Unknown'}\n**Previous Tier:** ${metadata.previousTier || 'None'}\n**New Tier:** ${metadata.tier || 'Unknown'}\n**Action:** ${metadata.action || 'Update'}`,
                inline: true
              },
              {
                name: '📊 Verification',
                value: `**Verified:** ${verified ? '✅ Real Log' : '❌ Unverified'}\n**Source:** Backend Database\n**Category:** ${category}`,
                inline: false
              }
            ]
          }]
        };

      case 'api_call':
        return {
          embeds: [{
            ...baseEmbed,
            title: '📡 API Request Logged',
            description: `**Category:** API Call\n**Log:** ${log}\n**Timestamp:** <t:${Math.floor(new Date(timestamp).getTime() / 1000)}:F>`,
            color: this.getStatusColor(metadata.status || 200),
            fields: [
              {
                name: '🔗 Request Details',
                value: `**Endpoint:** \`${metadata.endpoint || 'Unknown'}\`\n**Method:** \`${metadata.method || 'Unknown'}\`\n**Status:** ${metadata.status || 'Unknown'}`,
                inline: false
              },
              {
                name: '📊 Verification',
                value: `**Verified:** ${verified ? '✅ Real Log' : '❌ Unverified'}\n**Source:** Backend API\n**Category:** ${category}`,
                inline: false
              }
            ]
          }]
        };

      case 'database_operation':
        return {
          embeds: [{
            ...baseEmbed,
            title: '🗄️ Database Operation',
            description: `**Category:** Database Operation\n**Log:** ${log}\n**Timestamp:** <t:${Math.floor(new Date(timestamp).getTime() / 1000)}:F>`,
            color: 0x0099ff,
            fields: [
              {
                name: '💾 Operation Details',
                value: `**Action:** \`${metadata.action || 'Unknown'}\`\n**Table:** \`${metadata.table || 'Unknown'}\`\n**Affected Rows:** ${metadata.affectedRows || 'N/A'}`,
                inline: false
              },
              {
                name: '📊 Verification',
                value: `**Verified:** ${verified ? '✅ Real Log' : '❌ Unverified'}\n**Source:** Database Engine\n**Category:** ${category}`,
                inline: false
              }
            ]
          }]
        };

      case 'system_monitor':
        return {
          embeds: [{
            ...baseEmbed,
            title: '⚙️ System Performance',
            description: `**Category:** System Monitor\n**Log:** ${log}\n**Timestamp:** <t:${Math.floor(new Date(timestamp).getTime() / 1000)}:F>`,
            color: this.getPerformanceColor(metadata.cpuLoad || '0'),
            fields: [
              {
                name: '💻 Resource Usage',
                value: `**RAM:** ${metadata.ramUsage || 'N/A'}%\n**CPU:** ${metadata.cpuLoad || 'N/A'}%\n**Disk:** ${metadata.diskUsage || 'N/A'}%`,
                inline: true
              },
              {
                name: '📊 Verification',
                value: `**Verified:** ${verified ? '✅ Real Log' : '❌ Unverified'}\n**Source:** System Monitor\n**Category:** ${category}`,
                inline: false
              }
            ]
          }]
        };

      case 'staff_action':
        return {
          embeds: [{
            ...baseEmbed,
            title: '🔧 Staff Action',
            description: `**Category:** Staff Action\n**Log:** ${log}\n**Timestamp:** <t:${Math.floor(new Date(timestamp).getTime() / 1000)}:F>`,
            color: 0xff6600,
            fields: [
              {
                name: '👤 Staff Details',
                value: `**Admin:** ${metadata.adminUser || 'System'}\n**Action:** ${metadata.action || 'Unknown'}\n**Target:** ${metadata.target || 'N/A'}`,
                inline: false
              },
              {
                name: '📊 Verification',
                value: `**Verified:** ${verified ? '✅ Real Log' : '❌ Unverified'}\n**Source:** Admin Panel\n**Category:** ${category}`,
                inline: false
              }
            ]
          }]
        };

      default:
        return {
          embeds: [{
            ...baseEmbed,
            title: '📋 System Event',
            description: `**Category:** ${category}\n**Log:** ${log}\n**Timestamp:** <t:${Math.floor(new Date(timestamp).getTime() / 1000)}:F>`,
            color: 0x808080,
            fields: [
              {
                name: '📊 Verification',
                value: `**Verified:** ${verified ? '✅ Real Log' : '❌ Unverified'}\n**Source:** System\n**Category:** ${category}`,
                inline: false
              }
            ]
          }]
        };
    }
  }

  // Helper methods
  private getStatusColor(status: number): number {
    if (status >= 200 && status < 300) return 0x00ff00;
    if (status >= 300 && status < 400) return 0xffff00;
    if (status >= 400 && status < 500) return 0xff9900;
    return 0xff0000;
  }

  private getPerformanceColor(cpuLoad: string): number {
    const load = parseInt(cpuLoad);
    if (load < 50) return 0x00ff00;
    if (load < 80) return 0xffff00;
    return 0xff0000;
  }

  // Enhanced webhook sending with offline support
  public async sendWebhook(type: 'tier' | 'logbox', payload: any): Promise<{ success: boolean; error?: string }> {
    // Queue message for offline sending if needed
    this.offlineQueue.push({
      type,
      payload,
      timestamp: new Date().toISOString()
    });

    if (!this.isInitialized) {
      await this.initialize();
    }

    const config = this.configs.find(c => c.webhook_type === type && c.is_active);
    
    if (!config) {
      console.log(`No active ${type} webhook configured`);
      return { success: false, error: `No active ${type} webhook configured` };
    }

    try {
      // Create structured message if not already structured
      let structuredMessage: StructuredWebhookMessage;
      
      if (payload.category && payload.log && payload.timestamp) {
        structuredMessage = payload;
      } else {
        // Convert legacy payload to structured format
        const realLog = this.generateRealLog(type, payload);
        structuredMessage = this.createStructuredMessage(
          type === 'tier' ? 'tier_update' : 'system_monitor',
          payload,
          realLog
        );
      }

      const discordPayload = this.createDiscordEmbed(type, structuredMessage);
      
      const response = await fetch(config.webhook_url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(discordPayload)
      });

      if (response.ok) {
        console.log(`${type} webhook sent successfully`);
        // Remove from offline queue if successful
        this.offlineQueue = this.offlineQueue.filter(item => 
          !(item.type === type && item.timestamp === structuredMessage.timestamp)
        );
        return { success: true };
      } else {
        this.addToRetryQueue(structuredMessage, type);
        return { success: false, error: `HTTP ${response.status}` };
      }
    } catch (error: any) {
      console.error(`${type} webhook error:`, error);
      return { success: false, error: error.message };
    }
  }

  // Generate real, verified log entries
  private generateRealLog(type: 'tier' | 'logbox', payload: any): string {
    const timestamp = new Date().toISOString();
    
    if (type === 'tier') {
      return `[${timestamp}] TIER_UPDATE: Player ${payload.player || payload.ign} assigned tier ${payload.tier} in ${payload.gamemode} with score ${payload.score || 'N/A'}`;
    } else {
      if (payload.category === 'api_call') {
        return `[${timestamp}] API_CALL: ${payload.method || 'GET'} ${payload.endpoint || '/unknown'} - Status: ${payload.status || 200}`;
      } else if (payload.category === 'database_operation') {
        return `[${timestamp}] DB_OP: ${payload.action || 'UNKNOWN'} on table ${payload.table || 'unknown'} affected ${payload.affectedRows || 0} rows`;
      } else {
        return `[${timestamp}] SYSTEM_EVENT: ${payload.message || 'System event occurred'}`;
      }
    }
  }

  // Offline queue processor - works without user interaction
  private startOfflineQueueProcessor() {
    setInterval(async () => {
      if (this.offlineQueue.length === 0) return;

      console.log('Processing offline webhook queue:', this.offlineQueue.length, 'items');
      
      const itemsToProcess = [...this.offlineQueue];
      
      for (const item of itemsToProcess) {
        try {
          await this.sendWebhook(item.type, item.payload);
        } catch (error) {
          console.error('Offline queue processing error:', error);
        }
      }
    }, 30000); // Process every 30 seconds
  }

  private addToRetryQueue(payload: any, type: 'tier' | 'logbox') {
    this.retryQueue.push({
      payload,
      type,
      retryCount: 0,
      maxRetries: 3
    });
  }

  private startRetryProcessor() {
    setInterval(async () => {
      if (this.retryQueue.length === 0) return;

      const item = this.retryQueue.shift();
      if (!item) return;

      if (item.retryCount >= item.maxRetries) {
        console.error(`Webhook failed after ${item.maxRetries} retries:`, item.type);
        return;
      }

      const delay = Math.pow(2, item.retryCount) * 5000;
      
      setTimeout(async () => {
        console.log(`Retrying ${item.type} webhook (attempt ${item.retryCount + 1})`);
        const result = await this.sendWebhook(item.type, item.payload);
        
        if (!result.success) {
          item.retryCount++;
          if (item.retryCount < item.maxRetries) {
            this.retryQueue.push(item);
          }
        }
      }, delay);
    }, 10000);
  }
  
  public async updateWebhookUrl(type: 'tier' | 'logbox', newUrl: string): Promise<{ success: boolean; error?: string }> {
    try {
      if (!newUrl || !newUrl.trim()) {
        return { success: false, error: 'Webhook URL cannot be empty' };
      }

      const trimmedUrl = newUrl.trim();

      if (!this.isValidDiscordWebhookUrl(trimmedUrl)) {
        return { success: false, error: 'Invalid Discord webhook URL format' };
      }

      const { data: existingConfig, error: fetchError } = await supabase
        .from('mcbe_webhook_configs')
        .select('*')
        .eq('webhook_type', type)
        .maybeSingle();

      if (fetchError) {
        return { success: false, error: `Failed to check existing configuration: ${fetchError.message}` };
      }

      let result;
      const timestamp = new Date().toISOString();

      if (existingConfig) {
        result = await supabase
          .from('mcbe_webhook_configs')
          .update({
            webhook_url: trimmedUrl,
            is_active: true,
            updated_at: timestamp
          })
          .eq('webhook_type', type)
          .select();
      } else {
        result = await supabase
          .from('mcbe_webhook_configs')
          .insert({
            webhook_type: type,
            webhook_url: trimmedUrl,
            is_active: true,
            created_at: timestamp,
            updated_at: timestamp
          })
          .select();
      }

      if (result.error) {
        return { success: false, error: `Failed to save webhook URL: ${result.error.message}` };
      }

      await this.forceReloadConfigs();
      return { success: true };

    } catch (error: any) {
      return { success: false, error: `Unexpected error: ${error.message}` };
    }
  }

  public async forceReloadConfigs(): Promise<void> {
    this.configs = [];
    await this.loadConfigs();
  }

  private isValidDiscordWebhookUrl(url: string): boolean {
    const patterns = [
      /^https:\/\/discord\.com\/api\/webhooks\/\d+\/[\w-]+\/?$/,
      /^https:\/\/discordapp\.com\/api\/webhooks\/\d+\/[\w-]+\/?$/,
    ];
    return patterns.some(pattern => pattern.test(url));
  }

  public async testWebhook(type: 'tier' | 'logbox'): Promise<{ success: boolean; message: string }> {
    const testLog = `[${new Date().toISOString()}] TEST_WEBHOOK: Testing ${type} webhook functionality - System verification check`;
    
    const testMessage = this.createStructuredMessage(
      type === 'tier' ? 'tier_update' : 'system_monitor',
      { test: true, type },
      testLog
    );

    const result = await this.sendWebhook(type, testMessage);
    
    if (result.success) {
      return { success: true, message: 'Test webhook sent successfully!' };
    } else {
      return { success: false, message: result.error || 'Test failed' };
    }
  }

  public async getConfigs(): Promise<WebhookConfig[]> {
    if (!this.isInitialized) {
      await this.initialize();
    }
    return [...this.configs];
  }

  public getServiceHealth() {
    const tierConfig = this.configs.find(c => c.webhook_type === 'tier' && c.is_active);
    const logboxConfig = this.configs.find(c => c.webhook_type === 'logbox' && c.is_active);
    
    return {
      isInitialized: this.isInitialized,
      configCount: this.configs.length,
      retryQueueSize: this.retryQueue.length,
      offlineQueueSize: this.offlineQueue.length,
      activeConfigs: {
        tier: !!tierConfig && this.isValidDiscordWebhookUrl(tierConfig.webhook_url),
        logbox: !!logboxConfig && this.isValidDiscordWebhookUrl(logboxConfig.webhook_url)
      }
    };
  }
}

export const enhancedWebhookService = new EnhancedWebhookService();
