import { supabase } from '@/integrations/supabase/client';

export type GameMode = 'Crystal' | 'Sword' | 'Mace' | 'Axe' | 'SMP' | 'UHC' | 'NethPot' | 'Bedwars';
export type TierLevel = 'HT1' | 'LT1' | 'HT2' | 'LT2' | 'HT3' | 'LT3' | 'HT4' | 'LT4' | 'HT5' | 'LT5' | 'Retired' | 'Not Ranked';
export type PlayerRegion = 'NA' | 'EU' | 'AS' | 'OCE' | 'SA' | 'AF';
export type DeviceType = 'PC' | 'Mobile' | 'Console';

export interface Player {
  id: string;
  ign: string;
  region: string;
  device?: string;
  global_points: number;
  overall_rank: number;
  tier?: TierLevel;
  avatar_url?: string;
  java_username?: string;
  banned: boolean;
  created_at: string;
  updated_at: string;
  ban_reason?: string;
  user_id?: string;
  uuid?: string;
  gamemode_points?: {
    [key in GameMode]?: number;
  };
  tierAssignments?: {
    gamemode: GameMode;
    tier: TierLevel;
    score: number;
  }[];
}

// Fixed tier points mapping - consistent across the application
const TIER_POINTS: Record<TierLevel, number> = {
  'HT1': 50,
  'LT1': 45,
  'HT2': 40,
  'LT2': 35,
  'HT3': 30,
  'LT3': 25,
  'HT4': 20,
  'LT4': 15,
  'HT5': 10,
  'LT5': 5,
  'Retired': 0,
  'Not Ranked': 0
};

export function calculateTierPoints(tier: TierLevel): number {
  return TIER_POINTS[tier] || 0;
}

export async function updatePlayerGlobalPoints(playerId: string): Promise<void> {
  try {
    console.log(`Updating global points for player: ${playerId}`);
    
    // Get all tier assignments for the player
    const { data: tierAssignments, error } = await supabase
      .from('gamemode_scores')
      .select('internal_tier, score')
      .eq('player_id', playerId)
      .not('internal_tier', 'is', null);

    if (error) {
      console.error('Error fetching tier assignments:', error);
      return;
    }

    // Calculate total points based on tiers
    let totalPoints = 0;
    let validAssignments = 0;

    if (tierAssignments && tierAssignments.length > 0) {
      tierAssignments.forEach(assignment => {
        if (assignment.internal_tier && assignment.internal_tier in TIER_POINTS) {
          const tierPoints = calculateTierPoints(assignment.internal_tier as TierLevel);
          totalPoints += tierPoints;
          validAssignments++;
          console.log(`Tier ${assignment.internal_tier} = ${tierPoints} points`);
        }
      });
    }

    console.log(`Total calculated points for player ${playerId}: ${totalPoints} from ${validAssignments} valid assignments`);

    // Update player's global points
    const { error: updateError } = await supabase
      .from('players')
      .update({ 
        global_points: totalPoints,
        updated_at: new Date().toISOString()
      })
      .eq('id', playerId);

    if (updateError) {
      console.error('Error updating global points:', updateError);
      return;
    }

    console.log(`Successfully updated player ${playerId} global points to ${totalPoints}`);
  } catch (error) {
    console.error('Error in updatePlayerGlobalPoints:', error);
  }
}

// OPTIMIZED: Single query to get leaderboard with tier assignments
export async function getLeaderboard(): Promise<Player[]> {
  try {
    console.log('Fetching optimized leaderboard data...');
    
    // Single query to get players with their tier assignments
    const { data: playersData, error: playersError } = await supabase
      .from('players')
      .select('*')
      .eq('banned', false)
      .order('global_points', { ascending: false })
      .limit(50);

    if (playersError) {
      console.error('Supabase error fetching leaderboard:', playersError);
      throw playersError;
    }

    if (!playersData || playersData.length === 0) {
      console.log('No players found in database');
      return [];
    }

    // Get all player IDs for batch fetching tier assignments
    const playerIds = playersData.map(p => p.id);
    
    // Single query to get all tier assignments for all players
    const { data: tierData, error: tierError } = await supabase
      .from('gamemode_scores')
      .select('player_id, gamemode, internal_tier, score')
      .in('player_id', playerIds);

    if (tierError) {
      console.error('Error fetching tier assignments:', tierError);
    }

    // Group tier assignments by player ID for quick lookup
    const tierAssignmentsByPlayer = new Map<string, {gamemode: GameMode; tier: TierLevel; score: number}[]>();
    
    if (tierData) {
      tierData.forEach(tier => {
        if (!tierAssignmentsByPlayer.has(tier.player_id)) {
          tierAssignmentsByPlayer.set(tier.player_id, []);
        }
        tierAssignmentsByPlayer.get(tier.player_id)!.push({
          gamemode: tier.gamemode as GameMode,
          tier: tier.internal_tier as TierLevel,
          score: tier.score || calculateTierPoints(tier.internal_tier as TierLevel)
        });
      });
    }

    // Process players with pre-fetched tier data and correct points
    const players: Player[] = playersData.map((player, index) => {
      const tierAssignments = tierAssignmentsByPlayer.get(player.id) || [];
      const correctGlobalPoints = tierAssignments.reduce((sum, assignment) => {
        return sum + calculateTierPoints(assignment.tier);
      }, 0);
      
      return {
        id: player.id,
        ign: player.ign,
        region: player.region || 'NA',
        device: player.device || 'PC',
        global_points: correctGlobalPoints, // Use calculated points, not stored points
        overall_rank: index + 1,
        java_username: player.java_username,
        avatar_url: player.avatar_url,
        banned: player.banned || false,
        created_at: player.created_at || '',
        updated_at: player.updated_at || '',
        ban_reason: player.ban_reason,
        user_id: player.user_id,
        uuid: player.uuid,
        tierAssignments
      };
    });

    console.log('Optimized leaderboard processing complete:', players.length, 'players');
    return players;
  } catch (error) {
    console.error('Error in getLeaderboard:', error);
    throw error;
  }
}

export async function getPlayerTierAssignments(playerId: string): Promise<{gamemode: GameMode; tier: TierLevel; score: number}[]> {
  try {
    const { data, error } = await supabase
      .from('gamemode_scores')
      .select('gamemode, internal_tier, score')
      .eq('player_id', playerId);

    if (error) {
      console.error('Error fetching tier assignments:', error);
      return [];
    }

    if (!data) return [];

    return data.map(item => ({
      gamemode: item.gamemode as GameMode,
      tier: item.internal_tier as TierLevel,
      score: item.score || calculateTierPoints(item.internal_tier as TierLevel)
    }));
  } catch (error) {
    console.error('Error in getPlayerTierAssignments:', error);
    return [];
  }
}

// OPTIMIZED: Single query for gamemode tiers
export async function getGamemodeTiers(gamemode: GameMode): Promise<Player[]> {
  console.log(`Fetching optimized tiers for gamemode: ${gamemode}`);
  
  try {
    const { data, error } = await supabase
      .from('gamemode_scores')
      .select(`
        score,
        internal_tier,
        player_id,
        players!inner (
          id,
          ign,
          region,
          device,
          java_username,
          avatar_url,
          banned,
          created_at,
          updated_at,
          ban_reason,
          user_id,
          uuid
        )
      `)
      .eq('gamemode', gamemode)
      .eq('players.banned', false)
      .order('score', { ascending: false })
      .limit(50);

    if (error) {
      console.error('Error fetching gamemode tiers:', error);
      throw error;
    }

    if (!data || data.length === 0) {
      console.log(`No data found for gamemode: ${gamemode}`);
      return [];
    }

    console.log(`Found ${data.length} players for gamemode: ${gamemode}`);

    // Get all player IDs for batch fetching tier assignments
    const playerIds = data.map((item: any) => item.players.id);
    
    // Single query to get all tier assignments for these players
    const { data: tierData } = await supabase
      .from('gamemode_scores')
      .select('player_id, gamemode, internal_tier, score')
      .in('player_id', playerIds);

    // Group tier assignments by player ID
    const tierAssignmentsByPlayer = new Map<string, {gamemode: GameMode; tier: TierLevel; score: number}[]>();
    
    if (tierData) {
      tierData.forEach(tier => {
        if (!tierAssignmentsByPlayer.has(tier.player_id)) {
          tierAssignmentsByPlayer.set(tier.player_id, []);
        }
        tierAssignmentsByPlayer.get(tier.player_id)!.push({
          gamemode: tier.gamemode as GameMode,
          tier: tier.internal_tier as TierLevel,
          score: tier.score || calculateTierPoints(tier.internal_tier as TierLevel)
        });
      });
    }

    const players: Player[] = data.map((item: any, index: number) => ({
      id: item.players.id,
      ign: item.players.ign,
      region: item.players.region || 'NA',
      device: item.players.device || 'PC',
      global_points: calculateTierPoints(item.internal_tier as TierLevel),
      overall_rank: index + 1,
      tier: item.internal_tier,
      java_username: item.players.java_username,
      avatar_url: item.players.avatar_url,
      banned: item.players.banned || false,
      created_at: item.players.created_at || '',
      updated_at: item.players.updated_at || '',
      ban_reason: item.players.ban_reason,
      user_id: item.players.user_id,
      uuid: item.players.uuid,
      tierAssignments: tierAssignmentsByPlayer.get(item.players.id) || [],
      gamemode_points: {
        [gamemode]: calculateTierPoints(item.internal_tier as TierLevel)
      }
    }));

    return players;
  } catch (error) {
    console.error('Error in getGamemodeTiers:', error);
    throw error;
  }
}

// OPTIMIZED: Batch search with tier assignments
export async function searchPlayers(query: string): Promise<Player[]> {
  try {
    const { data, error } = await supabase
      .from('players')
      .select('*')
      .eq('banned', false)
      .ilike('ign', `%${query}%`)
      .limit(20);

    if (error) {
      console.error('Error searching players:', error);
      return [];
    }

    if (!data) return [];

    // Batch fetch tier assignments for all search results
    const playerIds = data.map(p => p.id);
    const { data: tierData } = await supabase
      .from('gamemode_scores')
      .select('player_id, gamemode, internal_tier, score')
      .in('player_id', playerIds);

    // Group tier assignments by player ID
    const tierAssignmentsByPlayer = new Map<string, {gamemode: GameMode; tier: TierLevel; score: number}[]>();
    
    if (tierData) {
      tierData.forEach(tier => {
        if (!tierAssignmentsByPlayer.has(tier.player_id)) {
          tierAssignmentsByPlayer.set(tier.player_id, []);
        }
        tierAssignmentsByPlayer.get(tier.player_id)!.push({
          gamemode: tier.gamemode as GameMode,
          tier: tier.internal_tier as TierLevel,
          score: tier.score || calculateTierPoints(tier.internal_tier as TierLevel)
        });
      });
    }

    const players: Player[] = data.map(player => {
      const tierAssignments = tierAssignmentsByPlayer.get(player.id) || [];
      const correctGlobalPoints = tierAssignments.reduce((sum, assignment) => {
        return sum + calculateTierPoints(assignment.tier);
      }, 0);
      
      return {
        id: player.id,
        ign: player.ign,
        region: player.region || 'NA',
        device: player.device || 'PC',
        global_points: correctGlobalPoints,
        overall_rank: 0,
        java_username: player.java_username,
        avatar_url: player.avatar_url,
        banned: player.banned || false,
        created_at: player.created_at || '',
        updated_at: player.updated_at || '',
        ban_reason: player.ban_reason,
        user_id: player.user_id,
        uuid: player.uuid,
        tierAssignments
      };
    });

    return players;
  } catch (error) {
    console.error('Error in searchPlayers:', error);
    return [];
  }
}

// Add new player function for admin use
export async function addPlayer(ign: string, gamemode: GameMode, tier: TierLevel, score: number, javaUsername?: string): Promise<void> {
  try {
    // Create player first
    const { data: playerData, error: playerError } = await supabase
      .from('players')
      .insert({
        ign,
        java_username: javaUsername,
        global_points: calculateTierPoints(tier),
        avatar_url: `https://mc-heads.net/avatar/${javaUsername || ign}/100`,
        banned: false,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      })
      .select()
      .single();

    if (playerError) throw playerError;

    console.log(`Player created with ID: ${playerData.id}, now adding gamemode score...`);
    console.log(`Player ${ign} added successfully with ${calculateTierPoints(tier)} points`);
  } catch (error) {
    console.error('Error adding player:', error);
    throw error;
  }
}

// OPTIMIZED: Single query for tier data
export async function getPlayersByTierAndGamemode(gamemode: GameMode): Promise<{
  [key in TierLevel]?: Player[]
}> {
  console.log(`Fetching optimized tier data for gamemode: ${gamemode}`);
  
  try {
    const { data, error } = await supabase
      .from('gamemode_scores')
      .select(`
        score,
        internal_tier,
        player_id,
        players!inner (
          id,
          ign,
          region,
          device,
          java_username,
          avatar_url,
          banned,
          created_at,
          updated_at,
          ban_reason,
          user_id,
          uuid
        )
      `)
      .eq('gamemode', gamemode)
      .eq('players.banned', false)
      .order('score', { ascending: false });

    if (error) {
      console.error('Error fetching gamemode tier data:', error);
      throw error;
    }

    if (!data || data.length === 0) {
      console.log(`No tier data found for gamemode: ${gamemode}`);
      return {
        'HT1': [], 'LT1': [],
        'HT2': [], 'LT2': [],
        'HT3': [], 'LT3': [],
        'HT4': [], 'LT4': [],
        'HT5': [], 'LT5': [],
        'Retired': []
      };
    }

    const tierData: { [key in TierLevel]?: Player[] } = {
      'HT1': [], 'LT1': [],
      'HT2': [], 'LT2': [],
      'HT3': [], 'LT3': [],
      'HT4': [], 'LT4': [],
      'HT5': [], 'LT5': [],
      'Retired': []
    };

    // Get all player IDs for batch fetching tier assignments
    const playerIds = data.map((item: any) => item.players.id);
    
    // Single query to get all tier assignments for these players
    const { data: allTierData } = await supabase
      .from('gamemode_scores')
      .select('player_id, gamemode, internal_tier, score')
      .in('player_id', playerIds);

    // Group tier assignments by player ID
    const tierAssignmentsByPlayer = new Map<string, {gamemode: GameMode; tier: TierLevel; score: number}[]>();
    
    if (allTierData) {
      allTierData.forEach(tier => {
        if (!tierAssignmentsByPlayer.has(tier.player_id)) {
          tierAssignmentsByPlayer.set(tier.player_id, []);
        }
        tierAssignmentsByPlayer.get(tier.player_id)!.push({
          gamemode: tier.gamemode as GameMode,
          tier: tier.internal_tier as TierLevel,
          score: tier.score || calculateTierPoints(tier.internal_tier as TierLevel)
        });
      });
    }

    data.forEach((item: any) => {
      const player: Player = {
        id: item.players.id,
        ign: item.players.ign,
        region: item.players.region || 'NA',
        device: item.players.device || 'PC',
        global_points: calculateTierPoints(item.internal_tier as TierLevel),
        overall_rank: 0,
        tier: item.internal_tier,
        java_username: item.players.java_username,
        avatar_url: item.players.avatar_url,
        banned: item.players.banned || false,
        created_at: item.players.created_at || '',
        updated_at: item.players.updated_at || '',
        ban_reason: item.players.ban_reason,
        user_id: item.players.user_id,
        uuid: item.players.uuid,
        tierAssignments: tierAssignmentsByPlayer.get(item.players.id) || [],
        gamemode_points: {
          [gamemode]: calculateTierPoints(item.internal_tier as TierLevel)
        }
      };

      const tier = item.internal_tier as TierLevel;
      if (tierData[tier]) {
        tierData[tier]!.push(player);
      }
    });

    return tierData;
  } catch (error) {
    console.error('Error in getPlayersByTierAndGamemode:', error);
    throw error;
  }
}
