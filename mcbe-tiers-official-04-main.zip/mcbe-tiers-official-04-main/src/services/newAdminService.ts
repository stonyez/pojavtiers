
import { supabase } from '@/integrations/supabase/client';

export interface NewAdminAuthResult {
  success: boolean;
  role?: string;
  needsOnboarding?: boolean;
  error?: string;
}

export interface NewAdminOnboardingData {
  discord: string;
  requestedRole: string;
  secretKey: string;
  applicationStatement: string;
}

export interface AdminApplication {
  id: string;
  discord: string;
  requested_role: string;
  secret_key: string;
  application_statement: string;
  ip_address: string;
  status: 'pending' | 'approved' | 'rejected';
  submitted_at: string;
  reviewed_at?: string;
  reviewed_by?: string;
}

export interface AdminUser {
  id: string;
  ip_address: string;
  role: string;
  approved_by: string;
  approved_at: string;
  last_access?: string;
  is_active: boolean;
}

class NewAdminService {
  async authenticateAdmin(password: string, skipOnboarding?: boolean): Promise<NewAdminAuthResult> {
    try {
      console.log('🔐 Starting new admin authentication with password:', password.substring(0, 5) + '...');
      
      // Owner password - immediate full access
      if (password === '$$devil2018,zestycpvp$$') {
        console.log('✅ OWNER password matched - granting immediate full access');
        localStorage.setItem('admin_role', 'owner');
        localStorage.setItem('admin_session_active', 'true');
        
        return { 
          success: true, 
          role: 'owner'
        };
      }
      
      // Staff password - limited access after application
      if (password === '-$$Mcbetlstaff20$$-') {
        console.log('✅ STAFF password matched - routing to application process');
        return { 
          success: true, 
          needsOnboarding: true 
        };
      }

      console.log('❌ Password does not match any known passwords');
      console.log('🔍 Tried password:', password);
      console.log('🔍 Expected owner password: $$devil2018,zestycpvp$$');
      console.log('🔍 Expected staff password: -$$Mcbetlstaff20$$-');
      return { 
        success: false, 
        error: 'Invalid password' 
      };
    } catch (error: any) {
      console.error('❌ New admin authentication error:', error);
      return { 
        success: false, 
        error: error.message || 'Authentication failed' 
      };
    }
  }

  async submitOnboardingApplication(data: NewAdminOnboardingData): Promise<{ success: boolean; error?: string }> {
    try {
      console.log('Submitting onboarding application for:', data.discord);
      
      // Get user IP for tracking
      const userIp = `new_admin_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      
      const { error } = await supabase
        .from('admin_applications')
        .insert({
          discord: data.discord,
          requested_role: data.requestedRole,
          secret_key: data.secretKey,
          application_statement: data.applicationStatement,
          ip_address: userIp,
          status: 'pending'
        });

      if (error) {
        console.error('Database insert error:', error);
        throw error;
      }

      console.log('✅ Application submitted successfully');
      return { success: true };
    } catch (error: any) {
      console.error('New admin onboarding submission error:', error);
      return { success: false, error: error.message };
    }
  }

  async checkAdminAccess(): Promise<{ hasAccess: boolean; role?: string }> {
    try {
      // Check localStorage first
      const localRole = localStorage.getItem('admin_role');
      const localActive = localStorage.getItem('admin_session_active');
      
      if (localActive === 'true' && localRole) {
        return { hasAccess: true, role: localRole };
      }
      
      return { hasAccess: false };
    } catch (error) {
      console.error('Admin access check error:', error);
      return { hasAccess: false };
    }
  }

  async getPendingApplications(): Promise<AdminApplication[]> {
    try {
      const { data, error } = await supabase
        .from('admin_applications')
        .select('*')
        .eq('status', 'pending')
        .order('submitted_at', { ascending: false });

      if (error) throw error;
      
      // Type-safe mapping to ensure status matches our union type
      return (data || []).map(item => ({
        ...item,
        status: item.status as 'pending' | 'approved' | 'rejected'
      }));
    } catch (error) {
      console.error('Error fetching pending applications:', error);
      return [];
    }
  }

  async reviewApplicationWithRole(applicationId: string, action: 'approve' | 'reject', assignedRole?: string): Promise<{ success: boolean; error?: string }> {
    try {
      console.log(`Reviewing application ${applicationId} with action: ${action}, role: ${assignedRole}`);
      
      const { error } = await supabase
        .from('admin_applications')
        .update({
          status: action === 'approve' ? 'approved' : 'rejected',
          reviewed_at: new Date().toISOString(),
          reviewed_by: 'owner'
        })
        .eq('id', applicationId);

      if (error) throw error;

      if (action === 'approve' && assignedRole) {
        // Create admin user record with limited role for staff
        const finalRole = assignedRole === 'staff' ? 'staff' : assignedRole;
        
        const { error: userError } = await supabase
          .from('admin_users')
          .insert({
            application_id: applicationId,
            ip_address: `approved_${Date.now()}`,
            role: finalRole,
            approved_by: 'owner'
          });

        if (userError) {
          console.error('Error creating admin user:', userError);
          throw userError;
        }
        
        console.log(`✅ User approved and granted ${finalRole} role`);
      }

      return { success: true };
    } catch (error: any) {
      console.error('Review application error:', error);
      return { success: false, error: error.message };
    }
  }

  async getAdminUsers(): Promise<AdminUser[]> {
    try {
      const { data, error } = await supabase
        .from('admin_users')
        .select('*')
        .eq('is_active', true)
        .order('approved_at', { ascending: false });

      if (error) throw error;
      return data || [];
    } catch (error) {
      console.error('Error fetching admin users:', error);
      return [];
    }
  }

  async banAdminUser(userId: string): Promise<{ success: boolean; error?: string }> {
    try {
      const { error } = await supabase
        .from('admin_users')
        .update({ is_active: false })
        .eq('id', userId);

      if (error) throw error;
      return { success: true };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }

  getCurrentRole(): string | null {
    return localStorage.getItem('admin_role');
  }

  canViewStaffLogs(): boolean {
    const role = this.getCurrentRole();
    return role === 'owner'; // Only owner can view staff logs
  }

  isOwner(): boolean {
    return this.getCurrentRole() === 'owner';
  }

  isStaff(): boolean {
    return this.getCurrentRole() === 'staff';
  }

  canMassSubmit(): boolean {
    const role = this.getCurrentRole();
    return role === 'owner'; // Only owner can mass submit
  }

  canManageStaff(): boolean {
    return this.isOwner(); // Only owner can manage staff
  }

  canAccessUserManagement(): boolean {
    const role = this.getCurrentRole();
    return role === 'owner' || role === 'staff'; // Both owner and staff can access user management
  }

  canAccessSingleSubmission(): boolean {
    const role = this.getCurrentRole();
    return role === 'owner' || role === 'staff'; // Both owner and staff can access single submission
  }

  canAccessAnalytics(): boolean {
    return this.isOwner(); // Only owner can access analytics
  }

  canAccessDatabaseTools(): boolean {
    return this.isOwner(); // Only owner can access database tools
  }
}

// Clear all authentication state
export const clearAllAuthState = (): void => {
  localStorage.removeItem('admin_session_token');
  localStorage.removeItem('admin_role');
  localStorage.removeItem('admin_ip');
  localStorage.removeItem('admin_session_active');
  localStorage.removeItem('owner_username');
  localStorage.removeItem('staff_username');
  
  Object.keys(localStorage).forEach(key => {
    if (key.includes('admin') || key.includes('auth')) {
      localStorage.removeItem(key);
    }
  });

  sessionStorage.clear();
  
  document.cookie.split(";").forEach(function(c) { 
    document.cookie = c.replace(/^ +/, "").replace(/=.*/, "=;expires=" + new Date().toUTCString() + ";path=/"); 
  });
};

export const newAdminService = new NewAdminService();
