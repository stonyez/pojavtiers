
import { supabase } from '@/integrations/supabase/client';

interface BackupResult {
  success: boolean;
  backup_name?: string;
  data?: any;
  error?: string;
}

class BackupService {
  private lastBackupDate: string | null = null;

  async createDailyBackup(): Promise<{ success: boolean; error?: string }> {
    try {
      const today = new Date().toISOString().split('T')[0];
      
      // Check if backup already exists for today
      if (this.lastBackupDate === today) {
        console.log('Backup already created today');
        return { success: true };
      }

      console.log('Creating daily backup...');
      
      // Call the database function to create backup data
      const { data: backupResult, error: backupError } = await supabase
        .rpc('create_daily_backup');

      if (backupError) {
        console.error('Error creating backup:', backupError);
        return { success: false, error: backupError.message };
      }

      // Type guard to check if the result has the expected structure
      if (!backupResult || typeof backupResult !== 'object' || !('success' in backupResult)) {
        return { success: false, error: 'Invalid backup result format' };
      }

      // Properly convert the generic JSON to our interface
      const result = backupResult as unknown as BackupResult;
      if (!result.success) {
        return { success: false, error: 'Failed to generate backup data' };
      }

      // Delete old backup if exists
      await this.deleteOldBackups();

      // Upload new backup to Supabase Storage
      const backupName = 'latest-backup.json';
      const backupData = JSON.stringify(result.data, null, 2);
      
      const { error: uploadError } = await supabase.storage
        .from('backups')
        .upload(backupName, new Blob([backupData], { type: 'application/json' }), {
          cacheControl: '3600',
          upsert: true
        });

      if (uploadError) {
        console.error('Error uploading backup:', uploadError);
        return { success: false, error: uploadError.message };
      }

      this.lastBackupDate = today;
      console.log('Daily backup created successfully:', backupName);
      
      return { success: true };
    } catch (error: any) {
      console.error('Backup service error:', error);
      return { success: false, error: error.message };
    }
  }

  private async deleteOldBackups(): Promise<void> {
    try {
      // Delete the existing latest backup file to ensure only one exists
      const { error } = await supabase.storage
        .from('backups')
        .remove(['latest-backup.json']);

      if (error && !error.message.includes('not found')) {
        console.error('Error deleting old backup:', error);
      } else {
        console.log('Deleted old backup file');
      }
    } catch (error) {
      console.error('Error deleting old backups:', error);
    }
  }

  async downloadLatestBackup(): Promise<{ success: boolean; data?: Blob; error?: string }> {
    try {
      const { data, error } = await supabase.storage
        .from('backups')
        .download('latest-backup.json');

      if (error) {
        return { success: false, error: error.message };
      }

      return { success: true, data };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }

  // Check if backup is needed and create it
  async checkAndCreateBackup(): Promise<void> {
    const today = new Date().toISOString().split('T')[0];
    const lastBackup = localStorage.getItem('last-backup-date');
    
    if (lastBackup !== today) {
      const result = await this.createDailyBackup();
      if (result.success) {
        localStorage.setItem('last-backup-date', today);
      }
    }
  }
}

export const backupService = new BackupService();
