
import { supabase } from '@/integrations/supabase/client';

export interface AuthResult {
  success: boolean;
  role?: string;
  needsOnboarding?: boolean;
  error?: string;
}

export interface OnboardingData {
  discord: string;
  requestedRole: string;
  secretKey: string;
  applicationStatement: string;
}

class AuthService {
  private sessionToken: string | null = null;
  private userRole: string | null = null;

  constructor() {
    // Load session from localStorage
    this.sessionToken = localStorage.getItem('admin_session_token');
    this.userRole = localStorage.getItem('admin_role');
  }

  async authenticate(password: string): Promise<AuthResult> {
    try {
      console.log('Starting authentication process...');
      
      // Fetch auth config from database
      const { data: configs, error } = await supabase
        .from('auth_config')
        .select('config_key, config_value');

      if (error) {
        console.error('Error fetching auth config:', error);
        throw error;
      }

      const ownerPassword = configs?.find(c => c.config_key === 'owner_password')?.config_value;
      const staffPassword = configs?.find(c => c.config_key === 'staff_password')?.config_value;

      console.log('Password validation starting...');

      if (password === ownerPassword) {
        console.log('Owner password matched - granting immediate access');
        // Owner gets immediate access
        const sessionToken = `owner_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        this.sessionToken = sessionToken;
        this.userRole = 'owner';
        
        localStorage.setItem('admin_session_token', sessionToken);
        localStorage.setItem('admin_role', 'owner');
        localStorage.setItem('admin_session_active', 'true');
        
        return { 
          success: true, 
          role: 'owner'
        };
      } else if (password === staffPassword) {
        console.log('Staff password matched - needs onboarding application');
        // Staff password unlocks onboarding form
        return { 
          success: true, 
          needsOnboarding: true 
        };
      } else {
        console.log('Invalid password provided');
        return { 
          success: false, 
          error: 'Invalid password' 
        };
      }
    } catch (error: any) {
      console.error('Authentication error:', error);
      return { 
        success: false, 
        error: error.message || 'Authentication failed' 
      };
    }
  }

  async submitOnboardingApplication(data: OnboardingData): Promise<{ success: boolean; error?: string }> {
    try {
      // Get user IP for tracking
      const userIp = `user_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      
      const { error } = await supabase
        .from('admin_applications')
        .insert({
          discord: data.discord,
          requested_role: data.requestedRole as 'admin' | 'moderator' | 'tester',
          secret_key: data.secretKey,
          application_statement: data.applicationStatement,
          ip_address: userIp,
          status: 'pending'
        });

      if (error) throw error;

      return { success: true };
    } catch (error: any) {
      console.error('Onboarding submission error:', error);
      return { success: false, error: error.message };
    }
  }

  isAuthenticated(): boolean {
    return this.sessionToken !== null && this.userRole !== null;
  }

  getRole(): string | null {
    return this.userRole;
  }

  isOwner(): boolean {
    return this.userRole === 'owner';
  }

  hasPermission(permission: string): boolean {
    // For now, only owner has all permissions
    return this.isOwner();
  }

  logout(): void {
    this.sessionToken = null;
    this.userRole = null;
    localStorage.removeItem('admin_session_token');
    localStorage.removeItem('admin_role');
    localStorage.removeItem('admin_session_active');
  }
}

export const authService = new AuthService();
