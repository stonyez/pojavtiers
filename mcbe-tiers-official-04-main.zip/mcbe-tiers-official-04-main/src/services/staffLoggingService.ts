
import { supabase } from '@/integrations/supabase/client';

export interface StaffLogEntry {
  log_id: string;
  staff_id: string;
  device_id: string;
  username: string;
  operation_type: string;
  operation_details: any;
  timestamp: string;
  status: 'pending' | 'approved' | 'denied' | 'error';
  executed_at?: string;
  owner_remarks?: string;
  error_flag?: boolean;
}

class StaffLoggingService {
  async logStaffOperation(
    staffId: string,
    deviceId: string,
    username: string,
    operationType: string,
    operationDetails: any
  ): Promise<{ success: boolean; logId?: string; error?: string }> {
    try {
      console.log('Logging staff operation:', { staffId, operationType });
      
      const { data, error } = await supabase
        .from('staff_logs')
        .insert({
          staff_id: staffId,
          device_id: deviceId,
          username: username,
          operation_type: operationType,
          operation_details: operationDetails,
          status: 'pending'
        })
        .select('log_id')
        .single();

      if (error) {
        console.error('Error logging staff operation:', error);
        return { success: false, error: error.message };
      }

      return { success: true, logId: data.log_id };
    } catch (error: any) {
      console.error('Staff logging error:', error);
      return { success: false, error: error.message };
    }
  }

  async getAllStaffLogs(): Promise<StaffLogEntry[]> {
    try {
      console.log('Fetching all staff logs...');
      
      const { data, error } = await supabase
        .from('staff_logs')
        .select('*')
        .not('staff_id', 'is', null) // Only get logs with actual staff IDs
        .order('timestamp', { ascending: false })
        .limit(100);

      if (error) {
        console.error('Error fetching staff logs:', error);
        return [];
      }

      const logs = (data || []).map(log => ({
        log_id: log.log_id,
        staff_id: log.staff_id,
        device_id: log.device_id,
        username: log.username,
        operation_type: log.operation_type,
        operation_details: log.operation_details,
        timestamp: log.timestamp,
        status: log.status as 'pending' | 'approved' | 'denied' | 'error',
        executed_at: log.executed_at,
        owner_remarks: log.owner_remarks,
        error_flag: log.error_flag
      }));

      console.log('Staff logs fetched successfully:', logs.length);
      return logs;
    } catch (error) {
      console.error('Staff logs service error:', error);
      return [];
    }
  }

  async getPendingApprovals(): Promise<StaffLogEntry[]> {
    try {
      console.log('Fetching pending approvals...');
      
      const { data, error } = await supabase
        .from('staff_logs')
        .select('*')
        .eq('status', 'pending')
        .not('staff_id', 'is', null) // Only get logs with actual staff IDs
        .order('timestamp', { ascending: false });

      if (error) {
        console.error('Error fetching pending approvals:', error);
        return [];
      }

      const pendingApprovals = (data || []).map(log => ({
        log_id: log.log_id,
        staff_id: log.staff_id,
        device_id: log.device_id,
        username: log.username,
        operation_type: log.operation_type,
        operation_details: log.operation_details,
        timestamp: log.timestamp,
        status: log.status as 'pending' | 'approved' | 'denied' | 'error',
        executed_at: log.executed_at,
        owner_remarks: log.owner_remarks,
        error_flag: log.error_flag
      }));

      console.log('Pending approvals fetched successfully:', pendingApprovals.length);
      return pendingApprovals;
    } catch (error) {
      console.error('Pending approvals service error:', error);
      return [];
    }
  }

  async approveOperation(logId: string, ownerRemarks?: string): Promise<{ success: boolean; error?: string }> {
    try {
      // First approve the log
      const { error: updateError } = await supabase
        .from('staff_logs')
        .update({
          status: 'approved',
          executed_at: new Date().toISOString(),
          owner_remarks: ownerRemarks
        })
        .eq('log_id', logId);

      if (updateError) {
        console.error('Error approving operation:', updateError);
        return { success: false, error: updateError.message };
      }

      // Execute the approved operation
      const { data: executeResult, error: executeError } = await supabase
        .rpc('execute_approved_staff_operation', { log_id_param: logId });

      if (executeError) {
        console.error('Error executing approved operation:', executeError);
        // Mark as error but don't fail the approval
        await supabase
          .from('staff_logs')
          .update({ error_flag: true })
          .eq('log_id', logId);
      }

      return { success: true };
    } catch (error: any) {
      console.error('Approve operation error:', error);
      return { success: false, error: error.message };
    }
  }

  async denyOperation(logId: string, ownerRemarks?: string): Promise<{ success: boolean; error?: string }> {
    try {
      const { error } = await supabase
        .from('staff_logs')
        .update({
          status: 'denied',
          owner_remarks: ownerRemarks
        })
        .eq('log_id', logId);

      if (error) {
        console.error('Error denying operation:', error);
        return { success: false, error: error.message };
      }

      return { success: true };
    } catch (error: any) {
      console.error('Deny operation error:', error);
      return { success: false, error: error.message };
    }
  }
}

export const staffLoggingService = new StaffLoggingService();
