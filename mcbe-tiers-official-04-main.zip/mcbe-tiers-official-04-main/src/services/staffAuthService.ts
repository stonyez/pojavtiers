
import { supabase } from '@/integrations/supabase/client';

export interface StaffUser {
  id: string;
  username: string;
  email: string;
  role: string;
  permissions: Record<string, boolean>;
  lastLogin?: string;
  isActive: boolean;
}

export interface StaffSession {
  success: boolean;
  sessionToken?: string;
  staffData?: StaffUser;
  errorMessage?: string;
}

export interface StaffLoginCredentials {
  username: string;
  password: string;
}

// Helper function to safely convert Json to permissions object
function convertToPermissions(permissionsJson: any): Record<string, boolean> {
  if (!permissionsJson || typeof permissionsJson !== 'object') {
    return {};
  }
  
  const permissions: Record<string, boolean> = {};
  for (const [key, value] of Object.entries(permissionsJson)) {
    permissions[key] = Boolean(value);
  }
  
  return permissions;
}

class StaffAuthService {
  private sessionToken: string | null = null;
  private staffData: StaffUser | null = null;

  constructor() {
    // Load session from localStorage on initialization
    this.sessionToken = localStorage.getItem('staff_session_token');
    const storedStaffData = localStorage.getItem('staff_data');
    if (storedStaffData) {
      try {
        this.staffData = JSON.parse(storedStaffData);
      } catch (error) {
        console.error('Error parsing stored staff data:', error);
        this.clearSession();
      }
    }
  }

  async login(credentials: StaffLoginCredentials): Promise<StaffSession> {
    try {
      // Check if staff table exists before attempting login
      const { data: tableExists, error: tableError } = await supabase
        .from('staff')
        .select('username')
        .limit(1);

      if (tableError && tableError.code === '42P01') {
        // Table doesn't exist, fallback to simple auth
        console.log('Staff table does not exist, using fallback auth');
        return this.fallbackLogin(credentials);
      }

      const { data, error } = await supabase.rpc('create_staff_session', {
        p_username: credentials.username,
        p_password: credentials.password
      });

      if (error) {
        console.error('Login error:', error);
        return this.fallbackLogin(credentials);
      }

      if (data && data.length > 0) {
        const result = data[0];
        
        if (result.success) {
          this.sessionToken = result.session_token;
          const staffDataRaw = result.staff_data as any;
          if (staffDataRaw && typeof staffDataRaw === 'object') {
            this.staffData = {
              id: staffDataRaw.id || '',
              username: staffDataRaw.username || '',
              email: staffDataRaw.email || '',
              role: staffDataRaw.role || '',
              permissions: convertToPermissions(staffDataRaw.permissions),
              isActive: true
            };
          } else {
            return { success: false, errorMessage: 'Invalid staff data format' };
          }
          
          // Store in localStorage
          localStorage.setItem('staff_session_token', this.sessionToken);
          localStorage.setItem('staff_data', JSON.stringify(this.staffData));
          
          return {
            success: true,
            sessionToken: this.sessionToken,
            staffData: this.staffData
          };
        } else {
          return { success: false, errorMessage: result.error_message };
        }
      }

      return { success: false, errorMessage: 'Invalid response from server' };
    } catch (error: any) {
      console.error('Login error:', error);
      return this.fallbackLogin(credentials);
    }
  }

  private fallbackLogin(credentials: StaffLoginCredentials): Promise<StaffSession> {
    // Simple fallback authentication for when staff table doesn't exist
    if (credentials.username === 'admin' && credentials.password === 'admin123') {
      const fallbackStaff: StaffUser = {
        id: 'fallback-admin',
        username: 'admin',
        email: 'admin@example.com',
        role: 'admin',
        permissions: {
          can_manage_staff: true,
          can_manage_users: true,
          can_mass_submit: true,
          can_view_audit: true
        },
        isActive: true
      };

      const token = `fallback_${Date.now()}`;
      this.sessionToken = token;
      this.staffData = fallbackStaff;
      
      localStorage.setItem('staff_session_token', token);
      localStorage.setItem('staff_data', JSON.stringify(fallbackStaff));
      
      return Promise.resolve({
        success: true,
        sessionToken: token,
        staffData: fallbackStaff
      });
    }

    return Promise.resolve({
      success: false,
      errorMessage: 'Invalid credentials'
    });
  }

  async validateSession(): Promise<boolean> {
    if (!this.sessionToken) return false;

    // If using fallback session, just check if it exists
    if (this.sessionToken.startsWith('fallback_')) {
      return this.staffData !== null;
    }

    try {
      const { data, error } = await supabase.rpc('validate_staff_session', {
        session_token: this.sessionToken
      });

      if (error || !data || data.length === 0) {
        this.clearSession();
        return false;
      }

      const sessionData = data[0];
      if (sessionData && typeof sessionData === 'object') {
        this.staffData = {
          id: sessionData.staff_id || '',
          username: sessionData.username || '',
          email: this.staffData?.email || '',
          role: sessionData.role || '',
          permissions: convertToPermissions(sessionData.permissions),
          isActive: true
        };

        localStorage.setItem('staff_data', JSON.stringify(this.staffData));
      }
      
      return true;
    } catch (error) {
      console.error('Session validation error:', error);
      // Don't clear session on network errors
      return this.staffData !== null;
    }
  }

  logout(): void {
    this.clearSession();
  }

  clearSession(): void {
    this.sessionToken = null;
    this.staffData = null;
    localStorage.removeItem('staff_session_token');
    localStorage.removeItem('staff_data');
  }

  getCurrentUser(): StaffUser | null {
    return this.staffData;
  }

  getSessionToken(): string | null {
    return this.sessionToken;
  }

  hasPermission(permission: string): boolean {
    return this.staffData?.permissions?.[permission] === true;
  }

  hasRole(role: string): boolean {
    return this.staffData?.role === role;
  }

  canManageStaff(): boolean {
    return this.hasRole('admin') || this.hasPermission('can_manage_staff');
  }

  canManageUsers(): boolean {
    return this.hasRole('admin') || this.hasRole('moderator') || this.hasPermission('can_manage_users');
  }

  canMassSubmit(): boolean {
    return this.hasRole('admin') || this.hasRole('moderator') || this.hasPermission('can_mass_submit');
  }

  async logAction(action: string, targetType?: string, targetId?: string, details?: any): Promise<void> {
    console.log('Action logged:', { action, targetType, targetId, details, staff: this.staffData?.username });
  }
}

export const staffAuthService = new StaffAuthService();
