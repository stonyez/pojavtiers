
import { supabase } from '@/integrations/supabase/client';

export interface MCBEWebhookConfig {
  id: string;
  webhook_type: 'tier' | 'logbox';
  webhook_url: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
  last_tested_at?: string;
  test_status?: string;
}

export interface MCBEWebhookLog {
  id: string;
  webhook_type: 'tier' | 'logbox';
  payload_preview: string;
  success: boolean;
  http_status?: number;
  response_message?: string;
  delivery_time_ms?: number;
  sent_at: string;
}

class MCBEWebhookService {
  // Trigger a tier log webhook (called automatically by database trigger)
  async triggerTierLog(
    playerIgn: string,
    gamemode: string,
    tier: string,
    javaUsername?: string,
    playerUuid?: string,
    actionType: string = 'Result Posted'
  ): Promise<boolean> {
    try {
      console.log('Triggering tier webhook:', { playerIgn, gamemode, tier, javaUsername, playerUuid, actionType });
      
      const { error } = await supabase.rpc('queue_tier_log_webhook', {
        player_ign: playerIgn,
        gamemode: gamemode,
        tier: tier,
        java_username: javaUsername,
        player_uuid: playerUuid,
        action_type: actionType,
        event_timestamp: new Date().toISOString()
      });

      if (error) {
        console.error('Error triggering tier log webhook:', error);
        return false;
      }

      console.log('Tier log webhook queued successfully');
      
      // Immediately trigger processing
      this.processQueue();
      
      return true;
    } catch (error) {
      console.error('Failed to trigger tier log webhook:', error);
      return false;
    }
  }

  // Trigger a logbox log webhook
  async triggerLogboxLog(
    logMessage: string,
    logLevel: string = 'info'
  ): Promise<boolean> {
    try {
      console.log('Triggering logbox webhook:', { logMessage, logLevel });
      
      const { error } = await supabase.rpc('queue_logbox_log_webhook', {
        log_message: logMessage,
        log_level: logLevel
      });

      if (error) {
        console.error('Error triggering logbox log webhook:', error);
        return false;
      }

      console.log('Logbox log webhook queued successfully');
      
      // Immediately trigger processing
      this.processQueue();
      
      return true;
    } catch (error) {
      console.error('Failed to trigger logbox log webhook:', error);
      return false;
    }
  }

  // Get webhook configurations
  async getConfigs(): Promise<MCBEWebhookConfig[]> {
    try {
      const { data, error } = await supabase
        .from('mcbe_webhook_configs')
        .select('*')
        .order('webhook_type');

      if (error) throw error;
      return data || [];
    } catch (error) {
      console.error('Error fetching webhook configs:', error);
      return [];
    }
  }

  // Update webhook configuration
  async updateConfig(
    type: 'tier' | 'logbox',
    webhookUrl: string,
    isActive: boolean = true
  ): Promise<boolean> {
    try {
      const { error } = await supabase
        .from('mcbe_webhook_configs')
        .upsert({
          webhook_type: type,
          webhook_url: webhookUrl,
          is_active: isActive,
          updated_at: new Date().toISOString()
        });

      if (error) throw error;
      return true;
    } catch (error) {
      console.error('Error updating webhook config:', error);
      return false;
    }
  }

  // Get webhook logs
  async getLogs(limit: number = 50): Promise<MCBEWebhookLog[]> {
    try {
      const { data, error } = await supabase
        .from('mcbe_webhook_logs')
        .select('*')
        .order('sent_at', { ascending: false })
        .limit(limit);

      if (error) throw error;
      return data || [];
    } catch (error) {
      console.error('Error fetching webhook logs:', error);
      return [];
    }
  }

  // Test webhook
  async testWebhook(type: 'tier' | 'logbox', url: string): Promise<{ success: boolean; message: string }> {
    try {
      const { data, error } = await supabase.functions.invoke('webhook-management', {
        body: {
          action: 'test_webhook',
          data: { type, url }
        }
      });

      if (error) throw error;

      return {
        success: data.success,
        message: data.message || (data.success ? 'Test successful' : 'Test failed')
      };
    } catch (error: any) {
      console.error('Error testing webhook:', error);
      return {
        success: false,
        message: error.message || 'Failed to test webhook'
      };
    }
  }

  // Process webhook queue (called by background service)
  async processQueue(): Promise<{ processed: number; successful: number }> {
    try {
      console.log('Processing webhook queue...');
      
      const { data, error } = await supabase.functions.invoke('webhook-management', {
        body: {
          action: 'process_queue'
        }
      });

      if (error) {
        console.error('Error invoking webhook processor:', error);
        throw error;
      }

      const result = {
        processed: data?.processed || 0,
        successful: data?.successful || 0
      };
      
      console.log('Webhook processing result:', result);
      return result;
    } catch (error) {
      console.error('Error processing webhook queue:', error);
      return { processed: 0, successful: 0 };
    }
  }
}

export const mcbeWebhookService = new MCBEWebhookService();
