
// Webhook service disabled - functionality removed but structure maintained
export interface WebhookTriggerData {
  type: 'results' | 'logs' | 'monitoring' | 'updates' | 'actions';
  data: any;
  playerData?: {
    ign: string;
    device?: string;
    region?: string;
    gamemode?: string;
    previousTier?: string;
    newTier?: string;
    avatarUrl?: string;
  };
  adminUser?: string;
}

// All webhook functions disabled
export const triggerWebhook = async (payload: WebhookTriggerData): Promise<boolean> => {
  console.log('Webhook functionality disabled:', payload.type);
  return false;
};

export const triggerResultsWebhook = async (playerData: any, adminUser?: string) => {
  console.log('Results webhook disabled');
  return false;
};

export const triggerLogsWebhook = async (logData: any, adminUser?: string) => {
  console.log('Logs webhook disabled');
  return false;
};

export const triggerMonitoringWebhook = async (alertData: any) => {
  console.log('Monitoring webhook disabled');
  return false;
};

export const triggerUpdatesWebhook = async (updateData: any, adminUser: string) => {
  console.log('Updates webhook disabled');
  return false;
};

export const triggerActionsWebhook = async (actionData: any, adminUser: string) => {
  console.log('Actions webhook disabled');
  return false;
};
