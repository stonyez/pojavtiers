
import { supabase } from '@/integrations/supabase/client';

export interface MCBEAuthResult {
  success: boolean;
  role?: string;
  needsOnboarding?: boolean;
  error?: string;
}

export interface MCBEOnboardingData {
  discord: string;
  requestedRole: 'admin' | 'publisher';
  secretKey: string;
  applicationStatement: string;
}

export interface AdminApplication {
  id: string;
  discord: string;
  requested_role: 'admin' | 'publisher';
  secret_key: string;
  application_statement: string;
  ip_address: string;
  status: 'pending' | 'approved' | 'rejected';
  submitted_at: string;
  reviewed_at?: string;
  reviewed_by?: string;
}

export interface LockboxTask {
  id: string;
  task_type: string;
  submitter_ip: string;
  submitter_role: string;
  task_data: any;
  status: 'pending' | 'approved' | 'rejected';
  submitted_at: string;
  reviewed_at?: string;
  reviewed_by?: string;
}

class MCBEAdminService {
  private sessionToken: string | null = null;
  private currentRole: string | null = null;

  constructor() {
    // Load session from localStorage
    this.sessionToken = localStorage.getItem('mcbe_admin_session_token');
    this.currentRole = localStorage.getItem('mcbe_admin_role');
  }

  async authenticateAdmin(password: string): Promise<MCBEAuthResult> {
    try {
      console.log('🔐 Starting MCBE admin authentication...');
      
      // Owner password - immediate access
      if (password === '$$devil2018,zestycpvp$$') {
        console.log('✅ OWNER password matched - granting immediate admin access');
        const sessionToken = `mcbe_owner_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        this.sessionToken = sessionToken;
        this.currentRole = 'admin';
        
        localStorage.setItem('mcbe_admin_session_token', sessionToken);
        localStorage.setItem('mcbe_admin_role', 'admin');
        localStorage.setItem('mcbe_admin_session_active', 'true');
        
        return { 
          success: true, 
          role: 'admin'
        };
      }
      
      // Staff password variations - ALL should work for onboarding
      const staffPasswordVariations = [
        '$$Mcbetlstaff20$$',
        '-$$Mcbetlstaff20$$-',
        'Mcbetlstaff20',
        '$$mcbetlstaff20$$',
        'MCBETLSTAFF20'
      ];
      
      if (staffPasswordVariations.includes(password)) {
        console.log('✅ STAFF password matched - needs onboarding application');
        console.log('🎯 Password matched variant:', password);
        return { 
          success: true, 
          needsOnboarding: true 
        };
      }

      // Fallback to database check for compatibility
      try {
        const { data: configs, error } = await supabase
          .from('auth_config')
          .select('config_key, config_value');

        if (error) {
          console.error('Error fetching auth config:', error);
        } else {
          const ownerPassword = configs?.find(c => c.config_key === 'owner_password')?.config_value;
          const staffPassword = configs?.find(c => c.config_key === 'staff_password')?.config_value;

          console.log('🔍 Database fallback check...');

          if (password === ownerPassword) {
            console.log('✅ Owner password matched via database - granting immediate admin access');
            const sessionToken = `mcbe_owner_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
            this.sessionToken = sessionToken;
            this.currentRole = 'admin';
            
            localStorage.setItem('mcbe_admin_session_token', sessionToken);
            localStorage.setItem('mcbe_admin_role', 'admin');
            localStorage.setItem('mcbe_admin_session_active', 'true');
            
            return { 
              success: true, 
              role: 'admin'
            };
          } else if (password === staffPassword || staffPasswordVariations.includes(staffPassword || '')) {
            console.log('✅ Staff password matched via database - needs onboarding application');
            return { 
              success: true, 
              needsOnboarding: true 
            };
          }
        }
      } catch (dbError) {
        console.error('Database check failed:', dbError);
      }

      console.log('❌ Invalid password provided');
      console.log('🔍 Tried password:', password);
      console.log('🔍 Expected staff variations:', staffPasswordVariations);
      return { 
        success: false, 
        error: 'Invalid password' 
      };
    } catch (error: any) {
      console.error('❌ MCBE authentication error:', error);
      return { 
        success: false, 
        error: error.message || 'Authentication failed' 
      };
    }
  }

  async submitApplication(data: MCBEOnboardingData): Promise<{ success: boolean; error?: string }> {
    try {
      // Get user IP for tracking
      const userIp = `mcbe_user_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      
      const { error } = await supabase
        .from('admin_applications')
        .insert({
          discord: data.discord,
          requested_role: data.requestedRole,
          secret_key: data.secretKey,
          application_statement: data.applicationStatement,
          ip_address: userIp,
          status: 'pending'
        });

      if (error) throw error;

      return { success: true };
    } catch (error: any) {
      console.error('MCBE onboarding submission error:', error);
      return { success: false, error: error.message };
    }
  }

  async getPendingApplications(): Promise<AdminApplication[]> {
    try {
      const { data, error } = await supabase
        .from('admin_applications')
        .select('*')
        .eq('status', 'pending')
        .order('submitted_at', { ascending: false });

      if (error) throw error;
      
      // Type-safe mapping to ensure requested_role matches our union type
      return (data || []).map(item => ({
        ...item,
        requested_role: item.requested_role as 'admin' | 'publisher',
        status: item.status as 'pending' | 'approved' | 'rejected'
      }));
    } catch (error) {
      console.error('Error fetching pending applications:', error);
      return [];
    }
  }

  async reviewApplication(applicationId: string, action: 'approve' | 'reject', assignedRole?: 'admin' | 'publisher'): Promise<{ success: boolean; error?: string }> {
    try {
      const { error } = await supabase
        .from('admin_applications')
        .update({
          status: action === 'approve' ? 'approved' : 'rejected',
          reviewed_at: new Date().toISOString(),
          reviewed_by: 'owner'
        })
        .eq('id', applicationId);

      if (error) throw error;

      if (action === 'approve' && assignedRole) {
        // Create admin user record
        const { error: userError } = await supabase
          .from('admin_users')
          .insert({
            application_id: applicationId,
            ip_address: `mcbe_approved_${Date.now()}`,
            role: assignedRole,
            approved_by: 'owner'
          });

        if (userError) throw userError;
      }

      return { success: true };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }

  async getLockboxTasks(): Promise<LockboxTask[]> {
    try {
      const { data, error } = await supabase
        .from('lockbox_queue')
        .select('*')
        .order('submitted_at', { ascending: false });

      if (error) throw error;
      
      // Type-safe mapping to ensure status matches our union type
      return (data || []).map(item => ({
        ...item,
        status: item.status as 'pending' | 'approved' | 'rejected'
      }));
    } catch (error) {
      console.error('Error fetching lockbox tasks:', error);
      return [];
    }
  }

  async reviewLockboxTask(taskId: string, action: 'approve' | 'reject'): Promise<{ success: boolean; error?: string }> {
    try {
      const { error } = await supabase
        .from('lockbox_queue')
        .update({
          status: action === 'approve' ? 'approved' : 'rejected',
          reviewed_at: new Date().toISOString(),
          reviewed_by: 'owner'
        })
        .eq('id', taskId);

      if (error) throw error;
      return { success: true };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }

  isAuthenticated(): boolean {
    return this.sessionToken !== null && this.currentRole !== null;
  }

  getCurrentRole(): string | null {
    return this.currentRole;
  }

  logout(): void {
    this.sessionToken = null;
    this.currentRole = null;
    localStorage.removeItem('mcbe_admin_session_token');
    localStorage.removeItem('mcbe_admin_role');
    localStorage.removeItem('mcbe_admin_session_active');
  }
}

export const mcbeAdminService = new MCBEAdminService();
