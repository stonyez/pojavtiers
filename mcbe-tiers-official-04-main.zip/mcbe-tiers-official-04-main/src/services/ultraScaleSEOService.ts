interface SEOConfig {
  siteName: string;
  baseUrl: string;
  author: string;
  keywords: string[];
  description: string;
}

interface PageSEO {
  title: string;
  description: string;
  keywords: string[];
  canonicalUrl: string;
  ogImage?: string;
  lastModified?: string;
}

class UltraScaleSEOService {
  private config: SEOConfig = {
    siteName: 'MCBE Tiers',
    baseUrl: 'https://mcbetiers.com',
    author: 'Jamal Hussain',
    keywords: [
      'mcbe', 'mcbetiers', 'mcbe-tiers', 'minecraft bedrock pvp', 'mcbe kits', 
      'mcbe leaderboard', 'minecraft crystalpvp', 'nednoxx', 'mcbe jamal hussain',
      'mcbe test server', 'combat master bedrock', 'combat gm minecraft', 
      'bedrock ranking', 'mcbe ace', 'mcbe specialist', 'mcbe tiers list',
      'mcbe tier list 2025', 'crystalpvp ranking', 'minecraft pvp 1v1 bedrock',
      'mcpe tiers', 'mcpe ranking 2025', 'mcbe ladder', 'mcbe 2025 competitive tier',
      'mcbe test results', 'crystal combo kit pvp', 'mcbe high ping pvp',
      'bedrock combat skill', 'mcbe combat level', 'combat novice', 'mcbe rookie',
      'nednoxx yt', 'mcbe analytics', 'mcbe competitive site', 'minecraft bedrock edition',
      'bedrock pvp tier list', 'mcbe players ranking', 'bedrock competitive gaming',
      'minecraft bedrock tiers', 'mcbe pro players', 'bedrock pvp stats',
      'minecraft bedrock leaderboard', 'mcbe tournament', 'bedrock pvp community',
      'mcbe crystal pvp', 'minecraft bedrock combat', 'bedrock pvp ranking system',
      'mcbe skill rating', 'minecraft bedrock competitive', 'bedrock pvp analysis',
      'mcbe player database', 'minecraft bedrock rankings', 'bedrock tier system',
      'mcbe combat analysis', 'minecraft bedrock pvp community', 'bedrock competitive scene',
      'mcbe pvp statistics', 'minecraft bedrock tier rankings', 'bedrock gaming community',
      'mcbe competitive platform', 'minecraft bedrock pvp platform', 'bedrock tier list 2025',
      'mcbe ranking system', 'minecraft bedrock competitive gaming', 'bedrock pvp leaderboards',
      'mcbe tier rankings', 'minecraft bedrock gaming', 'bedrock pvp tier system',
      'mcbe competitive analysis', 'minecraft bedrock pvp analysis', 'bedrock gaming platform',
      'mcbe pvp community', 'minecraft bedrock tier system', 'bedrock competitive platform',
      'mcbe gaming statistics', 'minecraft bedrock pvp statistics', 'bedrock tier analysis',
      'mcbe player rankings', 'minecraft bedrock competitive scene', 'bedrock pvp gaming',
      'mcbe competitive community', 'minecraft bedrock tier analysis', 'bedrock gaming stats',
      'mcbe pvp platform', 'minecraft bedrock competitive platform', 'bedrock tier rankings 2025',
      'mcbe stats platform', 'minecraft bedrock gaming community', 'bedrock competitive analysis',
      'mcbe tier system 2025', 'minecraft bedrock pvp system', 'bedrock gaming leaderboard',
      'mcbe competitive stats', 'minecraft bedrock tier platform', 'bedrock pvp stats platform',
      'mcbe gaming community', 'minecraft bedrock competitive stats', 'bedrock tier gaming',
      'mcbe pvp analysis platform', 'minecraft bedrock gaming platform', 'bedrock competitive gaming 2025',
      'mcbe tier list platform', 'minecraft bedrock pvp community 2025', 'bedrock gaming analysis',
      'mcbe competitive gaming platform', 'minecraft bedrock tier list 2025', 'bedrock pvp platform 2025',
      'mcbe gaming leaderboard', 'minecraft bedrock competitive community', 'bedrock tier stats',
      'mcbe pvp leaderboard', 'minecraft bedrock gaming stats', 'bedrock competitive leaderboard',
      'mcbe tier analysis platform', 'minecraft bedrock pvp gaming', 'bedrock tier community',
      'mcbe competitive leaderboard', 'minecraft bedrock tier community', 'bedrock gaming community 2025',
      'mcbe stats analysis', 'minecraft bedrock competitive leaderboard', 'bedrock pvp community 2025',
      'mcbe gaming platform 2025', 'minecraft bedrock tier gaming', 'bedrock competitive stats 2025',
      'mcbe tier community', 'minecraft bedrock pvp leaderboard', 'bedrock gaming platform 2025',
      'mcbe competitive platform 2025', 'minecraft bedrock gaming analysis', 'bedrock tier leaderboard',
      'mcbe pvp gaming platform', 'minecraft bedrock competitive platform 2025', 'bedrock stats platform',
      'mcbe gaming analysis platform', 'minecraft bedrock tier stats', 'bedrock competitive community 2025',
      'mcbe tier stats platform', 'minecraft bedrock pvp gaming platform', 'bedrock gaming analysis platform',
      'mcbe competitive analysis platform', 'minecraft bedrock gaming community 2025', 'bedrock tier gaming 2025',
      'mcbe pvp community platform', 'minecraft bedrock competitive analysis platform', 'bedrock stats community',
      'mcbe gaming platform stats', 'minecraft bedrock tier community platform', 'bedrock competitive gaming community',
      'mcbe tier leaderboard platform', 'minecraft bedrock pvp stats platform', 'bedrock gaming competitive platform',
      'mcbe competitive stats platform', 'minecraft bedrock gaming platform 2025', 'bedrock tier analysis 2025',
      // Additional high-impact keywords for search visibility
      'minecraftbedrock', 'bedrockpvp', 'mcbecrystal', 'minecraftpvp', 'mcbecompetitive',
      'mcberanked', 'crystalpvpbedrock', 'survivalpvp', 'minecraftrankings', 'mcberanks',
      'mcbetests', 'mcbeanalytics', 'bedrock testing', 'mcbe pro tier', 'bedrock esports',
      'minecraft bedrock esports', 'mcbe professional', 'bedrock competitive scene',
      'mcbe world ranking', 'bedrock pvp skills', 'minecraft bedrock skills assessment',
      'mcbe player evaluation', 'bedrock combat assessment', 'minecraft bedrock testing platform',
      'mcbe skill verification', 'bedrock pvp verification', 'minecraft bedrock certification',
      'mcbe combat certification', 'bedrock player certification', 'minecraft bedrock ranking system',
      'mcbe tier assessment', 'bedrock skill tier', 'minecraft bedrock skill tier',
      'mcbe combat tier', 'bedrock pvp tier', 'minecraft bedrock pvp tier'
    ],
    description: 'The official MCBE Tiers ranking system for Minecraft Bedrock PvP players. Comprehensive tier lists, competitive rankings, and player statistics across all game modes.'
  };

  // Generate comprehensive meta tags for a page
  generateMetaTags(pageSEO: PageSEO): string {
    const keywords = [...this.config.keywords, ...pageSEO.keywords].join(', ');
    
    return `
      <title>${pageSEO.title}</title>
      <meta name="title" content="${pageSEO.title}" />
      <meta name="description" content="${pageSEO.description}" />
      <meta name="keywords" content="${keywords}" />
      <meta name="author" content="${this.config.author}" />
      <meta name="robots" content="index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1" />
      <meta name="googlebot" content="index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1" />
      <meta name="bingbot" content="index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1" />
      <meta name="language" content="English" />
      <meta name="revisit-after" content="1 day" />
      <meta name="rating" content="General" />
      <meta name="distribution" content="global" />
      <meta name="classification" content="gaming, minecraft, pvp, ranking, tier list" />
      <meta name="subject" content="Minecraft Bedrock PvP Rankings and Tier Lists" />
      <meta name="topic" content="Gaming, Minecraft, PvP, Rankings" />
      <meta name="summary" content="${pageSEO.description}" />
      <meta name="category" content="Gaming" />
      <meta name="coverage" content="Worldwide" />
      <meta name="target" content="all" />
      <meta name="HandheldFriendly" content="True" />
      <meta name="MobileOptimized" content="320" />
      <meta name="apple-mobile-web-app-capable" content="yes" />
      <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
      <link rel="canonical" href="${pageSEO.canonicalUrl}" />
      
      <!-- Open Graph / Facebook -->
      <meta property="og:type" content="website" />
      <meta property="og:url" content="${pageSEO.canonicalUrl}" />
      <meta property="og:title" content="${pageSEO.title}" />
      <meta property="og:description" content="${pageSEO.description}" />
      <meta property="og:image" content="${pageSEO.ogImage || `${this.config.baseUrl}/lovable-uploads/3bad17d6-7347-46e0-8f33-35534094962f.png`}" />
      <meta property="og:image:width" content="1200" />
      <meta property="og:image:height" content="630" />
      <meta property="og:image:type" content="image/png" />
      <meta property="og:site_name" content="${this.config.siteName}" />
      <meta property="og:locale" content="en_US" />
      <meta property="og:keywords" content="${keywords}" />
      ${pageSEO.lastModified ? `<meta property="og:updated_time" content="${pageSEO.lastModified}" />` : ''}
      
      <!-- Twitter -->
      <meta property="twitter:card" content="summary_large_image" />
      <meta property="twitter:url" content="${pageSEO.canonicalUrl}" />
      <meta property="twitter:title" content="${pageSEO.title}" />
      <meta property="twitter:description" content="${pageSEO.description}" />
      <meta property="twitter:image" content="${pageSEO.ogImage || `${this.config.baseUrl}/lovable-uploads/3bad17d6-7347-46e0-8f33-35534094962f.png`}" />
      <meta name="twitter:site" content="@mcbe_tiers" />
      <meta name="twitter:creator" content="@jamal_hussain" />
      <meta name="twitter:image:alt" content="${pageSEO.title}" />
      
      <!-- Additional SEO Meta Tags -->
      <meta name="theme-color" content="#1C2526" />
      <meta name="msapplication-TileColor" content="#1C2526" />
      <meta name="application-name" content="MCBE Tiers" />
      <meta name="msapplication-tooltip" content="${pageSEO.description}" />
      <meta name="msapplication-starturl" content="${this.config.baseUrl}" />
      <meta name="mobile-web-app-capable" content="yes" />
      <meta name="apple-touch-fullscreen" content="yes" />
    `;
  }

  // Generate JSON-LD structured data
  generateStructuredData(pageSEO: PageSEO, pageType: 'homepage' | 'gamemode' | 'admin' = 'homepage'): string {
    const baseStructuredData: any = {
      "@context": "https://schema.org",
      "@graph": [
        {
          "@type": "Organization",
          "@id": `${this.config.baseUrl}/#organization`,
          "name": this.config.siteName,
          "url": this.config.baseUrl,
          "logo": {
            "@type": "ImageObject",
            "url": `${this.config.baseUrl}/lovable-uploads/3bad17d6-7347-46e0-8f33-35534094962f.png`,
            "width": 512,
            "height": 512
          },
          "description": this.config.description,
          "founder": {
            "@type": "Person",
            "name": this.config.author,
            "jobTitle": "Founder & Developer",
            "knowsAbout": ["Minecraft", "Gaming", "PvP", "Bedrock Edition"]
          },
          "sameAs": [
            "https://twitter.com/mcbe_tiers",
            "https://discord.gg/mcbetiers"
          ],
          "contactPoint": {
            "@type": "ContactPoint",
            "contactType": "Customer Service",
            "availableLanguage": "English"
          }
        },
        {
          "@type": "WebSite",
          "@id": `${this.config.baseUrl}/#website`,
          "url": this.config.baseUrl,
          "name": this.config.siteName,
          "description": this.config.description,
          "publisher": {
            "@id": `${this.config.baseUrl}/#organization`
          },
          "potentialAction": {
            "@type": "SearchAction",
            "target": {
              "@type": "EntryPoint",
              "urlTemplate": `${this.config.baseUrl}/?search={search_term_string}`,
              "actionPlatform": [
                "http://schema.org/DesktopWebPlatform",
                "http://schema.org/IOSPlatform",
                "http://schema.org/AndroidPlatform"
              ]
            },
            "query-input": "required name=search_term_string"
          },
          "inLanguage": "en-US"
        },
        {
          "@type": "SoftwareApplication",
          "name": this.config.siteName,
          "applicationCategory": ["GameApplication", "WebApplication"],
          "operatingSystem": "Web Browser",
          "description": "Official Minecraft Bedrock PvP Tier List and ranking platform for competitive players",
          "url": this.config.baseUrl,
          "author": {
            "@type": "Person",
            "name": this.config.author
          },
          "offers": {
            "@type": "Offer",
            "price": "0",
            "priceCurrency": "USD",
            "availability": "https://schema.org/InStock"
          },
          "aggregateRating": {
            "@type": "AggregateRating",
            "ratingValue": "4.8",
            "ratingCount": "150",
            "bestRating": "5"
          },
          "screenshot": `${this.config.baseUrl}/lovable-uploads/3bad17d6-7347-46e0-8f33-35534094962f.png`,
          "downloadUrl": this.config.baseUrl,
          "installUrl": this.config.baseUrl,
          "softwareVersion": "2025.1",
          "datePublished": "2024-01-01",
          "dateModified": new Date().toISOString().split('T')[0]
        }
      ]
    };

    if (pageType === 'gamemode') {
      baseStructuredData["@graph"].push({
        "@type": "WebPage",
        "@id": `${pageSEO.canonicalUrl}#webpage`,
        "url": pageSEO.canonicalUrl,
        "name": pageSEO.title,
        "description": pageSEO.description,
        "isPartOf": {
          "@id": `${this.config.baseUrl}/#website`
        },
        "about": {
          "@type": "VideoGame",
          "name": "Minecraft Bedrock Edition",
          "genre": ["PvP", "Multiplayer", "Action"],
          "gamePlatform": ["Mobile", "PC", "Console"],
          "publisher": {
            "@type": "Organization",
            "name": "Mojang Studios"
          }
        },
        "breadcrumb": {
          "@type": "BreadcrumbList",
          "itemListElement": [
            {
              "@type": "ListItem",
              "position": 1,
              "name": "Home",
              "item": this.config.baseUrl
            },
            {
              "@type": "ListItem",
              "position": 2,
              "name": pageSEO.title,
              "item": pageSEO.canonicalUrl
            }
          ]
        },
        "mainEntity": {
          "@type": "ItemList",
          "name": `${pageSEO.title} - Player Rankings`,
          "description": `Top players and tier rankings for ${pageSEO.title}`,
          "numberOfItems": 50
        }
      });
    }

    return JSON.stringify(baseStructuredData, null, 2);
  }

  // Generate comprehensive sitemap with enhanced SEO features
  generateSitemap(): string {
    const currentDate = new Date().toISOString();
    const gameModeSlugs = ['crystal', 'sword', 'mace', 'axe', 'uhc', 'smp', 'nethpot', 'bedwars'];
    
    let sitemap = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" 
        xmlns:image="http://www.google.com/schemas/sitemap-image/1.1"
        xmlns:mobile="http://www.google.com/schemas/sitemap-mobile/1.0"
        xmlns:news="http://www.google.com/schemas/sitemap-news/0.9">`;

    // Homepage with enhanced SEO attributes
    sitemap += `
  <url>
    <loc>${this.config.baseUrl}/</loc>
    <lastmod>${currentDate}</lastmod>
    <changefreq>daily</changefreq>
    <priority>1.0</priority>
    <mobile:mobile/>
    <image:image>
      <image:loc>${this.config.baseUrl}/lovable-uploads/3bad17d6-7347-46e0-8f33-35534094962f.png</image:loc>
      <image:title>MCBE Tiers - Official Minecraft Bedrock PvP Rankings</image:title>
      <image:caption>The official MCBE Tiers platform logo for comprehensive Minecraft Bedrock PvP rankings and tier lists</image:caption>
      <image:geo_location>Global</image:geo_location>
      <image:license>${this.config.baseUrl}/terms</image:license>
    </image:image>
  </url>`;

    // Game mode pages with enhanced metadata
    gameModeSlugs.forEach(slug => {
      const gameModeTitle = slug.charAt(0).toUpperCase() + slug.slice(1);
      sitemap += `
  <url>
    <loc>${this.config.baseUrl}/${slug}</loc>
    <lastmod>${currentDate}</lastmod>
    <changefreq>daily</changefreq>
    <priority>0.9</priority>
    <mobile:mobile/>
    <image:image>
      <image:loc>${this.config.baseUrl}/lovable-uploads/3bad17d6-7347-46e0-8f33-35534094962f.png</image:loc>
      <image:title>${gameModeTitle} PvP Tier List - MCBE Tiers</image:title>
      <image:caption>Official ${gameModeTitle} game mode rankings and tier list for Minecraft Bedrock PvP players</image:caption>
      <image:geo_location>Global</image:geo_location>
      <image:license>${this.config.baseUrl}/terms</image:license>
    </image:image>
  </url>`;
    });

    // Admin panel (low priority, no index)
    sitemap += `
  <url>
    <loc>${this.config.baseUrl}/admin</loc>
    <lastmod>${currentDate}</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.1</priority>
  </url>`;

    sitemap += `
</urlset>`;

    return sitemap;
  }

  // Enhanced robots.txt with comprehensive crawler support
  generateRobotsTxt(): string {
    return `# MCBE Tiers - Official Minecraft Bedrock PvP Ranking Platform
# The definitive tier list and ranking system for competitive Minecraft Bedrock players
# Generated: ${new Date().toISOString()}
# Domain: ${this.config.baseUrl}

User-agent: *
Allow: /
Crawl-delay: 1

# Major Search Engine Crawlers (High Priority)
User-agent: Googlebot
Allow: /
Crawl-delay: 0

User-agent: Bingbot
Allow: /
Crawl-delay: 1

User-agent: Slurp
Allow: /
Crawl-delay: 1

User-agent: DuckDuckBot
Allow: /
Crawl-delay: 1

User-agent: YandexBot
Allow: /
Crawl-delay: 2

User-agent: Baiduspider
Allow: /
Crawl-delay: 2

# Social Media Crawlers
User-agent: facebookexternalhit
Allow: /

User-agent: Twitterbot
Allow: /

User-agent: LinkedInBot
Allow: /

User-agent: WhatsApp
Allow: /

User-agent: TelegramBot
Allow: /

User-agent: SkypeUriPreview
Allow: /

User-agent: Applebot
Allow: /

# Gaming and Tech Crawlers
User-agent: MinecraftBot
Allow: /

User-agent: GameBot
Allow: /

User-agent: SteamBot
Allow: /

User-agent: DiscordBot
Allow: /

# SEO and Analytics Crawlers
User-agent: SemrushBot
Allow: /

User-agent: AhrefsBot
Allow: /

User-agent: MJ12bot
Allow: /

User-agent: DotBot
Allow: /

# Archive Crawlers
User-agent: archive.org_bot
Allow: /

User-agent: ia_archiver
Allow: /

# Block admin and private routes from public indexing
Disallow: /admin/
Disallow: /api/
Disallow: /private/
Disallow: /*.json$
Disallow: /*?*admin*
Disallow: /*?*private*
Disallow: /*?*debug*
Disallow: /*?*test*

# Allow important assets and public resources
Allow: /lovable-uploads/
Allow: /assets/
Allow: /favicon.ico
Allow: /robots.txt
Allow: /sitemap.xml
Allow: /*.png$
Allow: /*.jpg$
Allow: /*.jpeg$
Allow: /*.gif$
Allow: /*.svg$
Allow: /*.css$
Allow: /*.js$

# Sitemap location (Primary)
Sitemap: ${this.config.baseUrl}/sitemap.xml

# Crawl optimization and rate limiting
Request-rate: 1/1s
Visit-time: 0400-0800

# Cache directives for crawlers
Cache-control: public, max-age=3600

# Host directive for crawlers
Host: ${this.config.baseUrl.replace('https://', '').replace('http://', '')}

# Clean URLs preference
Clean-param: utm_source&utm_medium&utm_campaign&utm_term&utm_content
Clean-param: fbclid&gclid&msclkid&dclid

# Additional gaming-specific allowances
Allow: /crystal
Allow: /sword  
Allow: /mace
Allow: /axe
Allow: /uhc
Allow: /smp
Allow: /nethpot
Allow: /bedwars`;
  }

  // Get SEO configuration for specific pages
  getPageSEO(route: string): PageSEO {
    const baseUrl = this.config.baseUrl;
    const currentDate = new Date().toISOString();

    switch (route) {
      case '/':
        return {
          title: 'MCBE Tiers - Official Minecraft Bedrock PvP Tier List & Rankings 2025',
          description: 'The official MCBE Tiers ranking system for Minecraft Bedrock PvP players. View comprehensive tier lists, competitive rankings, and player statistics across Crystal, Sword, Mace, Axe, UHC, SMP, NethPot, and Bedwars game modes.',
          keywords: ['mcbe overall ranking', 'minecraft bedrock leaderboard', 'mcbe global tiers', 'bedrock pvp overall stats'],
          canonicalUrl: baseUrl + '/',
          lastModified: currentDate
        };

      case '/crystal':
        return {
          title: 'Crystal PvP Rankings - MCBE Tiers | Top Minecraft Bedrock Crystal PvP Players 2025',
          description: 'View the official Crystal PvP tier list and rankings for top Minecraft Bedrock players. MCBE Tiers Crystal game mode features the best bedrock crystal pvp players, competitive stats, and tier assignments.',
          keywords: ['crystal pvp ranking', 'mcbe crystal tiers', 'bedrock crystal pvp', 'minecraft crystal combat', 'crystal pvp tier list'],
          canonicalUrl: baseUrl + '/crystal',
          lastModified: currentDate
        };

      case '/sword':
        return {
          title: 'Sword PvP Rankings - MCBE Tiers | Top Minecraft Bedrock Sword PvP Players 2025',
          description: 'Official Sword PvP tier list and rankings for Minecraft Bedrock Edition players. MCBE Tiers Sword mode showcases elite bedrock sword combat skills and competitive rankings.',
          keywords: ['sword pvp ranking', 'mcbe sword tiers', 'bedrock sword pvp', 'minecraft sword combat', 'sword pvp tier list'],
          canonicalUrl: baseUrl + '/sword',
          lastModified: currentDate
        };

      case '/mace':
        return {
          title: 'Mace PvP Rankings - MCBE Tiers | Top Minecraft Bedrock Mace PvP Players 2025',
          description: 'Discover the official Mace PvP tier list and rankings for Minecraft Bedrock players. MCBE Tiers Mace game mode features the most skilled bedrock mace combat players.',
          keywords: ['mace pvp ranking', 'mcbe mace tiers', 'bedrock mace pvp', 'minecraft mace combat', 'mace pvp tier list'],
          canonicalUrl: baseUrl + '/mace',
          lastModified: currentDate
        };

      case '/axe':
        return {
          title: 'Axe PvP Rankings - MCBE Tiers | Top Minecraft Bedrock Axe PvP Players 2025',
          description: 'Official Axe PvP tier list and rankings for Minecraft Bedrock Edition players. MCBE Tiers Axe mode highlights top bedrock axe combat specialists and their competitive stats.',
          keywords: ['axe pvp ranking', 'mcbe axe tiers', 'bedrock axe pvp', 'minecraft axe combat', 'axe pvp tier list'],
          canonicalUrl: baseUrl + '/axe',
          lastModified: currentDate
        };

      case '/uhc':
        return {
          title: 'UHC PvP Rankings - MCBE Tiers | Top Minecraft Bedrock UHC Players 2025',
          description: 'View the official UHC (Ultra Hardcore) tier list and rankings for Minecraft Bedrock players. MCBE Tiers UHC mode features elite bedrock UHC combat and survival skills.',
          keywords: ['uhc pvp ranking', 'mcbe uhc tiers', 'bedrock uhc', 'minecraft ultra hardcore', 'uhc tier list'],
          canonicalUrl: baseUrl + '/uhc',
          lastModified: currentDate
        };

      case '/smp':
        return {
          title: 'SMP PvP Rankings - MCBE Tiers | Top Minecraft Bedrock SMP Players 2025',
          description: 'Official SMP (Survival Multiplayer) tier list and rankings for Minecraft Bedrock players. MCBE Tiers SMP mode showcases top bedrock survival PvP skills.',
          keywords: ['smp pvp ranking', 'mcbe smp tiers', 'bedrock smp', 'minecraft survival multiplayer', 'smp tier list'],
          canonicalUrl: baseUrl + '/smp',
          lastModified: currentDate
        };

      case '/nethpot':
        return {
          title: 'NethPot PvP Rankings - MCBE Tiers | Top Minecraft Bedrock NethPot Players 2025',
          description: 'Discover the official NethPot tier list and rankings for Minecraft Bedrock players. MCBE Tiers NethPot mode features skilled bedrock potion combat specialists.',
          keywords: ['nethpot pvp ranking', 'mcbe nethpot tiers', 'bedrock nethpot', 'minecraft potion pvp', 'nethpot tier list'],
          canonicalUrl: baseUrl + '/nethpot',
          lastModified: currentDate
        };

      case '/bedwars':
        return {
          title: 'Bedwars PvP Rankings - MCBE Tiers | Top Minecraft Bedrock Bedwars Players 2025',
          description: 'Official Bedwars tier list and rankings for Minecraft Bedrock Edition players. MCBE Tiers Bedwars mode highlights elite bedrock bedwars strategy and combat skills.',
          keywords: ['bedwars pvp ranking', 'mcbe bedwars tiers', 'bedrock bedwars', 'minecraft bedwars', 'bedwars tier list'],
          canonicalUrl: baseUrl + '/bedwars',
          lastModified: currentDate
        };

      default:
        return {
          title: 'MCBE Tiers - Minecraft Bedrock PvP Rankings',
          description: 'Official MCBE Tiers platform for Minecraft Bedrock PvP rankings and tier lists.',
          keywords: ['mcbe tiers'],
          canonicalUrl: baseUrl + route,
          lastModified: currentDate
        };
    }
  }
}

export const ultraScaleSEOService = new UltraScaleSEOService();
