
import { supabase } from '@/integrations/supabase/client';
import { staffLoggingService } from './staffLoggingService';

export interface StaffMember {
  id: string;
  username: string;
  role: string;
  is_active: boolean;
  last_login?: string;
  created_at: string;
}

export interface StaffApplication {
  id: string;
  discord: string;
  requested_role: string;
  status: string;
  submitted_at: string;
  application_statement?: string;
}

export interface StaffLog {
  id: string;
  action: string;
  timestamp: string;
  staff_member: string;
  details?: string;
}

class StaffService {
  private cache = {
    staff: null as StaffMember[] | null,
    applications: null as StaffApplication[] | null,
    logs: null as StaffLog[] | null,
    lastFetch: {
      staff: 0,
      applications: 0,
      logs: 0
    }
  };

  private CACHE_DURATION = 30000; // 30 seconds
  private fetchingStates = {
    staff: false,
    applications: false,
    logs: false
  };

  private isCacheValid(type: keyof typeof this.cache.lastFetch): boolean {
    return Date.now() - this.cache.lastFetch[type] < this.CACHE_DURATION;
  }

  async getStaffMembers(): Promise<StaffMember[]> {
    if (this.cache.staff && this.isCacheValid('staff')) {
      return this.cache.staff;
    }

    if (this.fetchingStates.staff) {
      return this.cache.staff || [];
    }

    this.fetchingStates.staff = true;

    try {
      console.log('Fetching staff members from staff_device_bindings...');
      
      const { data, error } = await supabase
        .from('staff_device_bindings')
        .select('*')
        .order('created_at', { ascending: false });
      
      if (error) {
        console.error('Error fetching staff members:', error);
        return [];
      }

      const staffMembers = (data || []).map(staff => ({
        id: staff.id,
        username: staff.custom_username,
        role: staff.staff_role,
        is_active: true,
        created_at: staff.created_at,
        last_login: staff.updated_at
      }));

      this.cache.staff = staffMembers;
      this.cache.lastFetch.staff = Date.now();
      
      console.log('Staff members fetched successfully:', staffMembers.length);
      return staffMembers;
    } catch (error) {
      console.error('Staff service error:', error);
      return [];
    } finally {
      this.fetchingStates.staff = false;
    }
  }

  async getStaffApplications(): Promise<StaffApplication[]> {
    if (this.cache.applications && this.isCacheValid('applications')) {
      return this.cache.applications;
    }

    if (this.fetchingStates.applications) {
      return this.cache.applications || [];
    }

    this.fetchingStates.applications = true;

    try {
      console.log('Fetching staff applications...');
      
      const { data, error } = await supabase
        .from('admin_applications')
        .select('*')
        .eq('status', 'pending')
        .order('submitted_at', { ascending: false });

      if (error) {
        console.error('Error fetching applications:', error);
        return [];
      }

      const applications = (data || []).map(app => ({
        id: app.id,
        discord: app.discord,
        requested_role: app.requested_role,
        status: app.status,
        submitted_at: app.submitted_at,
        application_statement: app.application_statement
      }));

      this.cache.applications = applications;
      this.cache.lastFetch.applications = Date.now();
      
      console.log('Applications fetched successfully:', applications.length);
      return applications;
    } catch (error) {
      console.error('Applications service error:', error);
      return [];
    } finally {
      this.fetchingStates.applications = false;
    }
  }

  async getStaffLogs(): Promise<StaffLog[]> {
    if (this.cache.logs && this.isCacheValid('logs')) {
      return this.cache.logs;
    }

    if (this.fetchingStates.logs) {
      return this.cache.logs || [];
    }

    this.fetchingStates.logs = true;

    try {
      console.log('Fetching real staff logs...');
      
      const staffLogs = await staffLoggingService.getAllStaffLogs();
      
      const logs: StaffLog[] = staffLogs.map(log => ({
        id: log.log_id,
        action: log.operation_type,
        timestamp: log.timestamp,
        staff_member: log.username,
        details: JSON.stringify(log.operation_details)
      }));

      this.cache.logs = logs;
      this.cache.lastFetch.logs = Date.now();
      
      console.log('Real staff logs fetched successfully:', logs.length);
      return logs;
    } catch (error) {
      console.error('Logs service error:', error);
      return [];
    } finally {
      this.fetchingStates.logs = false;
    }
  }

  clearCache(): void {
    this.cache.staff = null;
    this.cache.applications = null;
    this.cache.logs = null;
    this.cache.lastFetch = {
      staff: 0,
      applications: 0,
      logs: 0
    };
    this.fetchingStates = {
      staff: false,
      applications: false,
      logs: false
    };
  }

  async reviewApplication(applicationId: string, action: 'approve' | 'deny', reviewerRole: string): Promise<{ success: boolean; error?: string }> {
    try {
      const { error } = await supabase
        .from('admin_applications')
        .update({ 
          status: action === 'approve' ? 'approved' : 'denied',
          reviewed_at: new Date().toISOString(),
          reviewed_by: reviewerRole
        })
        .eq('id', applicationId);

      if (error) {
        console.error('Error reviewing application:', error);
        return { success: false, error: error.message };
      }

      this.clearCache();
      return { success: true };
    } catch (error: any) {
      console.error('Review application error:', error);
      return { success: false, error: error.message };
    }
  }
}

export const staffService = new StaffService();
