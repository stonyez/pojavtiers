
interface StaffOnboardingData {
  username: string;
  role: string;
  onboardingComplete: boolean;
  firstLoginDate: string;
  lastActiveDate: string;
}

interface DeviceBinding {
  custom_username: string;
  staff_role: string;
  device_fingerprint: string;
  created_at: string;
  last_active: string;
}

class StaffOnboardingService {
  private readonly STORAGE_KEYS = {
    ONBOARDING_COMPLETE: 'staff_onboarding_complete',
    USERNAME: 'staff_username',
    ROLE: 'staff_role',
    FIRST_LOGIN: 'staff_first_login',
    LAST_ACTIVE: 'staff_last_active',
    DEVICE_FINGERPRINT: 'staff_device_fingerprint'
  };

  constructor() {
    this.ensureDeviceFingerprint();
  }

  private ensureDeviceFingerprint(): string {
    let fingerprint = localStorage.getItem(this.STORAGE_KEYS.DEVICE_FINGERPRINT);
    if (!fingerprint) {
      fingerprint = this.generateDeviceFingerprint();
      localStorage.setItem(this.STORAGE_KEYS.DEVICE_FINGERPRINT, fingerprint);
    }
    return fingerprint;
  }

  private generateDeviceFingerprint(): string {
    const userAgent = navigator.userAgent;
    const screen = `${window.screen.width}x${window.screen.height}`;
    const timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
    const language = navigator.language;
    const platform = navigator.platform;
    
    const fingerprint = btoa(`${userAgent}-${screen}-${timezone}-${language}-${platform}-${Date.now()}`);
    return fingerprint.slice(0, 32);
  }

  isOnboardingComplete(): boolean {
    const completed = localStorage.getItem(this.STORAGE_KEYS.ONBOARDING_COMPLETE);
    const username = localStorage.getItem(this.STORAGE_KEYS.USERNAME);
    return completed === 'true' && !!username;
  }

  getStaffData(): StaffOnboardingData | null {
    const username = localStorage.getItem(this.STORAGE_KEYS.USERNAME);
    const role = localStorage.getItem(this.STORAGE_KEYS.ROLE);
    const onboardingComplete = this.isOnboardingComplete();
    const firstLoginDate = localStorage.getItem(this.STORAGE_KEYS.FIRST_LOGIN) || '';
    const lastActiveDate = localStorage.getItem(this.STORAGE_KEYS.LAST_ACTIVE) || '';

    if (!username || !role || !onboardingComplete) return null;

    return {
      username,
      role,
      onboardingComplete,
      firstLoginDate,
      lastActiveDate
    };
  }

  async completeOnboarding(username: string, role: string): Promise<{ success: boolean; error?: string }> {
    try {
      const now = new Date().toISOString();
      
      localStorage.setItem(this.STORAGE_KEYS.USERNAME, username);
      localStorage.setItem(this.STORAGE_KEYS.ROLE, role);
      localStorage.setItem(this.STORAGE_KEYS.ONBOARDING_COMPLETE, 'true');
      localStorage.setItem(this.STORAGE_KEYS.FIRST_LOGIN, now);
      localStorage.setItem(this.STORAGE_KEYS.LAST_ACTIVE, now);

      return { success: true };
    } catch (error) {
      return { success: false, error: 'Failed to complete onboarding' };
    }
  }

  updateLastActive(): void {
    if (this.isOnboardingComplete()) {
      localStorage.setItem(this.STORAGE_KEYS.LAST_ACTIVE, new Date().toISOString());
    }
  }

  resetAllSessions(): void {
    Object.values(this.STORAGE_KEYS).forEach(key => {
      localStorage.removeItem(key);
    });
    
    localStorage.removeItem('admin_role');
    localStorage.removeItem('admin_session_active');
    localStorage.removeItem('staff_session_token');
    localStorage.removeItem('staff_data');
    localStorage.removeItem('device_binding');
  }

  getDeviceFingerprint(): string {
    return this.ensureDeviceFingerprint();
  }

  formatStaffUsername(username: string): string {
    return `${username}#MCBETIERS.com`;
  }

  async createDeviceBinding(data: { customUsername: string; staffRole: string }): Promise<{ success: boolean; error?: string }> {
    try {
      const deviceFingerprint = this.getDeviceFingerprint();
      const binding: DeviceBinding = {
        custom_username: data.customUsername,
        staff_role: data.staffRole,
        device_fingerprint: deviceFingerprint,
        created_at: new Date().toISOString(),
        last_active: new Date().toISOString()
      };

      localStorage.setItem('device_binding', JSON.stringify(binding));
      
      return await this.completeOnboarding(data.customUsername, data.staffRole);
    } catch (error) {
      return { success: false, error: 'Failed to create device binding' };
    }
  }

  async checkExistingBinding(): Promise<DeviceBinding | null> {
    try {
      const bindingStr = localStorage.getItem('device_binding');
      if (!bindingStr) return null;

      const binding = JSON.parse(bindingStr) as DeviceBinding;
      const currentFingerprint = this.getDeviceFingerprint();
      
      if (binding.device_fingerprint === currentFingerprint && this.isOnboardingComplete()) {
        binding.last_active = new Date().toISOString();
        localStorage.setItem('device_binding', JSON.stringify(binding));
        return binding;
      }
      
      return null;
    } catch (error) {
      return null;
    }
  }

  needsOnboarding(role: string): boolean {
    return !this.isOnboardingComplete();
  }
}

export const staffOnboardingService = new StaffOnboardingService();
