
interface GoogleDriveFile {
  id: string;
  name: string;
  mimeType: string;
  size?: string;
  createdTime?: string;
}

class GoogleDriveService {
  private isInitialized = false;

  async initialize(): Promise<boolean> {
    console.log('Google Drive service initialized (no OAuth required)');
    this.isInitialized = true;
    return true;
  }

  async validateFileLink(fileUrl: string): Promise<boolean> {
    try {
      // Extract file ID from Google Drive URL
      const fileIdMatch = fileUrl.match(/\/d\/([a-zA-Z0-9-_]+)/);
      if (!fileIdMatch) {
        console.error('Invalid Google Drive URL format');
        return false;
      }

      const fileId = fileIdMatch[1];
      
      // Try to access the file via public link
      const publicUrl = `https://drive.google.com/file/d/${fileId}/view`;
      
      try {
        const response = await fetch(publicUrl, { method: 'HEAD', mode: 'no-cors' });
        console.log('File accessibility check completed');
        return true;
      } catch (error) {
        // no-cors mode doesn't give us status, so assume accessible if no network error
        console.log('File link appears valid (no-cors check)');
        return true;
      }
    } catch (error) {
      console.error('Error validating file link:', error);
      return false;
    }
  }

  async createBackupLink(data: any, filename: string): Promise<string | null> {
    try {
      // Create a data blob and generate a download link
      const dataBlob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(dataBlob);
      
      // Create a temporary download link
      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      
      // Clean up the object URL
      setTimeout(() => URL.revokeObjectURL(url), 1000);
      
      console.log('Backup file created and downloaded:', filename);
      return url;
    } catch (error) {
      console.error('Error creating backup:', error);
      return null;
    }
  }

  async uploadBackup(data: any, filename: string): Promise<boolean> {
    try {
      const backupLink = await this.createBackupLink(data, filename);
      return backupLink !== null;
    } catch (error) {
      console.error('Backup upload failed:', error);
      return false;
    }
  }

  isAuthenticated(): boolean {
    return true; // Always return true since we don't need OAuth
  }

  async signIn(): Promise<boolean> {
    console.log('No sign-in required for file link validation');
    return true;
  }

  async signOut(): Promise<void> {
    console.log('No sign-out required');
  }

  getConfigurationInstructions(): string {
    return `
Google Drive Integration (No OAuth Required):
1. Share your Google Drive files with "Anyone with the link can view"
2. Copy the shareable link from Google Drive
3. Use the link validation feature to verify accessibility
4. Backup files will be downloaded directly to your device
`;
  }
}

export const googleDriveService = new GoogleDriveService();
