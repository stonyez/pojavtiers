
import { supabase } from '@/integrations/supabase/client';

export interface AdminAccessResult {
  hasAccess: boolean;
  role?: string;
  error?: string;
}

class AdminAccessService {
  async checkOwnerAccess(): Promise<AdminAccessResult> {
    try {
      // Check if user has owner role in admin_users table
      const { data, error } = await supabase.rpc('check_admin_access');
      
      if (error) {
        console.error('Admin access check error:', error);
        return { hasAccess: false, error: error.message };
      }

      if (data && data.length > 0) {
        const result = data[0];
        if (result.has_access && result.user_role === 'owner') {
          return { hasAccess: true, role: 'owner' };
        }
      }

      // Fallback to local storage check for owner override
      const storedRole = localStorage.getItem('admin_role');
      if (storedRole === 'owner') {
        return { hasAccess: true, role: 'owner' };
      }

      return { hasAccess: false };
    } catch (error: any) {
      console.error('Owner access check failed:', error);
      return { hasAccess: false, error: error.message };
    }
  }

  async verifyDatabaseAccess(): Promise<boolean> {
    try {
      // Test basic database connectivity
      const { data, error } = await supabase
        .from('admin_users')
        .select('count')
        .limit(1);
      
      return !error;
    } catch (error) {
      console.error('Database access verification failed:', error);
      return false;
    }
  }

  async getAdminApplications() {
    try {
      const { data, error } = await supabase
        .from('admin_applications')
        .select('*')
        .order('submitted_at', { ascending: false });

      if (error) throw error;
      return data || [];
    } catch (error: any) {
      console.error('Error fetching applications:', error);
      throw new Error(`Failed to fetch applications: ${error.message}`);
    }
  }

  async getStaffUsers() {
    try {
      const { data, error } = await supabase
        .from('staff')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      return data || [];
    } catch (error: any) {
      console.error('Error fetching staff users:', error);
      throw new Error(`Failed to fetch staff users: ${error.message}`);
    }
  }
}

export const adminAccessService = new AdminAccessService();
